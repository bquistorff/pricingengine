#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import math
import msecore.verify as verify
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from scipy.sparse import csc_matrix

class NpArrayEx:
 
    @staticmethod
    def to_nx1_mtx(array):
        """
        Convert the given 1-d array to a matrix containing N rows and 1 column

        :param array: a 1-d array [x₀, x₁, ... xₙ]
        :return: An N x 1 matrix [[x₀], [x₁], ... [xₙ]]
        """
        return np.column_stack(np.array([array]))
