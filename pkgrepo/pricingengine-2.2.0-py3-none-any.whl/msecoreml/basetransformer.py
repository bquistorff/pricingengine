#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from abc import ABCMeta, abstractmethod

class BaseTransformer(metaclass=ABCMeta):
    '''
    Abstract class to formalized the fit-transform paradigm
    '''
    @abstractmethod
    def fit(self, data):
        '''
        Fit a model to the given dataset
        '''
        pass

    @abstractmethod
    def fit_transform(self, data):
        '''
        Fit a model to the given dataset, transform the given dataset using the
        previously fit model and return the results.
        '''
        pass

    @abstractmethod
    def transform(self, data):
        '''
        Tranform the given dataset using the previously fit model and return the results.
        An exception is thrown if 

        - The model has not yet been fit using either fit() or fit_transform() 
        - The given data is not compatible with the data used for fitting
        '''
        pass
