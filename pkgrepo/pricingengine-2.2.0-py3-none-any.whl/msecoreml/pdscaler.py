#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import math
import warnings
import msecore.verify as verify
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.exceptions import DataConversionWarning
from scipy.sparse import csc_matrix
from .basetransformer import BaseTransformer
from .pdseriesex import PdSeriesEx

class PdScaler(BaseTransformer):
    '''
    Wrapper for pandas.Series scalers
    '''

    def __init__(self, scale_type=MinMaxScaler):
        self.__scaler = scale_type()
        self.__fit = False

    @property
    def is_fit(self):
        return self.__fit
    
    @property
    def scale(self):
        return self.__scaler.scale_

    def fit(self, series):
        '''
        Fit the scaler to the given series

        :param pd.Series series: The series to use for fitting the scaler
        '''
        verify.not_none_or_empty(series, "series")
        indicator = ~PdSeriesEx.get_nan_inf_indicator(series)

        # Check that there are rows to be transformed. 
        verify.true(any(indicator), "Cannot fit an empty series")

        selected = series[indicator]
        self.__scaler.fit(selected.values.reshape(-1, 1))
        self.__fit = True

    def fit_transform(self, series):
        '''
        Fit the scaler to the given series and return the resulting
        scaled series

        :param pd.Series series: The series to use for fitting the scaler and to be scaled
        '''
        verify.not_none_or_empty(series, "series")
        ret = series.copy()
        indicator = ~PdSeriesEx.get_nan_inf_indicator(series)

        # Check that there are rows to be transformed. 
        verify.true(any(indicator), "Cannot fit an empty series")

        selected = series[indicator]
        
        #reshape, otherwise get:
        #DeprecationWarning: Passing 1d arrays as data is deprecated in 0.17 and will raise ValueError in 0.19. 
        #Reshape your data either using X.reshape(-1, 1) if your data has a single feature or X.reshape(1, -1) 
        #if it contains a single sample.
        with warnings.catch_warnings(): #Data with input dtype int64 was converted to float64 by StandardScaler.
            warnings.simplefilter(action='ignore', category=DataConversionWarning)
            new = self.__scaler.fit_transform(selected.values.reshape(-1, 1))
        if int(pd.__version__.split('.')[1]) <= 19:
            #Flatten otherwise:
            #DeprecationWarning: assignment will raise an error in the future, most likely because your 
            #index result shape does not match the value array shape. You can use `arr.flat[index] = values` 
            #to keep the old behaviour.
            new = new.flatten()
        ret[indicator] = new
        self.__fit = True
        return ret

    def transform(self, series):
        '''
        Transform the given series using the previosly fit scaler
        An exception is thrown if
         
        - The scaler has not yet been fit using either fit() or fit_transform() 
        - The given data is not compatible with the data used for fitting

        :param pd.Series series: The series to be scaled
        '''
        verify.not_none_or_empty(series, "series")
        verify.true(self.__fit, "Not yet fit")
        ret = series.copy()
        indicator = ~PdSeriesEx.get_nan_inf_indicator(series)

        # Check that there are rows to be transformed. 
        if not any(indicator):
            return series

        selected = series[indicator]
        #reshape, otherwise get:
        #DeprecationWarning: Passing 1d arrays as data is deprecated in 0.17 and will raise ValueError in 0.19. 
        #Reshape your data either using X.reshape(-1, 1) if your data has a single feature or X.reshape(1, -1) 
        #if it contains a single sample.
        with warnings.catch_warnings(): #Data with input dtype int64 was converted to float64 by StandardScaler.
            warnings.simplefilter(action='ignore', category=DataConversionWarning)
            new = self.__scaler.transform(selected.values.reshape(-1, 1))
        if int(pd.__version__.split('.')[1]) <= 19:
            #Flatten otherwise:
            #DeprecationWarning: assignment will raise an error in the future, most likely because your 
            #index result shape does not match the value array shape. You can use `arr.flat[index] = values` 
            #to keep the old behaviour.
            new = new.flatten()
        ret[indicator] = new
        return ret
