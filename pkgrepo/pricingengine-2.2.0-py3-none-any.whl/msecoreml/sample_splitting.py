#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import numpy as np

class SingleFoldFullOverlap:
    '''
    Looks like a KFold-type object, but returns a single fold with all (non-label) indexes in both train, test
    Used for NO_SPLIT option in :class:`~pricingengine.estimation.double_ml.DoubleML` or 
    :class:`~pricingengine.estimation.dynamic_dml.DynamicDML`
    ''' 
    def split(self, X, y=None): #pylint: disable=invalid-name, unused-argument
        return [(range(len(X)), range(len(X)))]

    def get_n_splits(self, X): #pylint: disable=invalid-name, unused-argument
        return 1

    @property
    def n_splits(self):
        return 1

class SampleSplitting:
    '''
    Classes for dealing with fold info
    '''
    @staticmethod
    def filter_index_list(row_selector_bool, index_list):
        #Could modify to use the series-type manipulations below
        nrows = len(row_selector_bool)
        
        #convert fold indexes to 0/1 array
        arr = np.zeros(nrows)
        arr[index_list] = 1
        arr_sub = arr[row_selector_bool]
        return np.where(arr_sub)[0]
    
    @staticmethod
    def filter_folds(row_selector, folds=None):
        '''
        :param row_selector:1/0 array
        :param folds:folds
        '''
        if folds is None:
            return None

        new_fold_fit_info = []
        row_selector_bool = np.array(row_selector, dtype=np.bool)
        for train, test in folds:
            new_train = SampleSplitting.filter_index_list(row_selector_bool, train)
            new_test = SampleSplitting.filter_index_list(row_selector_bool, test)

            new_fold_fit_info.append((new_train, new_test))
        return new_fold_fit_info
