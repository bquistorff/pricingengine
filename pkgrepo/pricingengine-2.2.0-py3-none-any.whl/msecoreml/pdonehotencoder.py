#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import math
import msecore.verify as verify
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.nparrayex import NpArrayEx
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from scipy.sparse import csc_matrix
from .basetransformer import BaseTransformer
#pylint: disable=attribute-defined-outside-init

class PdOneHotEncoder(BaseTransformer):
    '''
    Wrapper for pandas.Series One-Hot encoder

    The transformed values will adhere to the following:

        - The row index of the returned dataframe will equal that of the given series (the series to be transformed)
        - The column index of the returned dataframe will contain a single index with name equal to the name of the
          series and the level of each column corresponding the value of the item that column encodes. 

        Note: 

        - The empty string is encoded like any other string. 
        - None is treated as missing and is not encoded.

        ======  ======  =============
        Letter  Number  ValueToEncode
        ======  ======  =============
        A       1       "Coke"         
        A       2       "Pepsi"        
        B       1       "Tab"          
        B       2       "Pepsi"        
        C       1       ""
        C       2       None
        ======  ======  =============

        The following dataframe is returned, where the column multi-index contains a single index ValueToEncode with 
        levels [Coke, Pepsi, Tab]

        ============ ============ ====== ======= ===== ===
        Value Letter Value Number "Coke" "Pepsi" "Tab" "" 
        ============ ============ ====== ======= ===== ===
        A            1            1      0       0     0
        A            2            0      1       0     0
        B            1            0      0       1     0
        B            2            0      1       0     0
        C            1            0      0       0     1
        C            2            0      0       0     0
        ============ ============ ====== ======= ===== ===

    '''
    BASE_FREQ = 'freq'
    def __init__(self, drop_base=True, base_criteria=BASE_FREQ):
        '''
        :param drop_base: When returning the transformation, do we include one-hots for all, or all-minus-one
            The latter is sometime called "dummy variables" in contrast to "normal" one-hot-encoding which does all.
        :param base_criteria: How to determine base. Options:
            freq - String. Modal value. This works better with penalization.
            <number> - Number as String. Value to be the base. 
        '''
        self.__initialized = False
        self.__label_encoder = None
        self.__onehot_encoder = None
        self.__known_labels = None
        self.__drop_base = drop_base

        
        self.base_criteria = base_criteria 

    @property
    def base_criteria(self):
        return self._base_criteria
    
    @base_criteria.setter
    def base_criteria(self, base_criteria):
        verify.false(self.__initialized, "Can't change base criteria after initialized.")
        if base_criteria == PdOneHotEncoder.BASE_FREQ:
            self._base_value = None
        else: 
            self._base_value = int(base_criteria)
        self._base_criteria = base_criteria

    @property
    def drop_base(self):
        return self.__drop_base
    
    @drop_base.setter
    def drop_base(self, drop_base):
        verify.false(self.__initialized, "Can't change drop_base after initialized.")
        self.__drop_base = drop_base

    def fit(self, series):
        '''
        Fit the the encoder to the given series

        :param series: The series to which to fit an encoding
        '''
        self.__fit(series)

    def fit_transform(self, series):
        '''
        Fit an encoder to the given series and return the encoded values of the series

        :param series: The series to which to fit an encoding and then transform. 
        :return: The dataframe resulting from encoding the given series
        '''
        self.__fit(series)
        return self.__transform(series)

    def transform(self, series):
        '''
        Encode the given series using the previously fit encoding 

        :param series: The series to encode
        :return: The dataframe resulting from encoding the given series

        If a new value is encountered in the series (i.e., a value that was not present in the series
        used to fit the encoder), the resulting encoding for that value will be all zeroes. For example, 

        
        Fit:
        
        =============  ===== ============= ==== =====
        ValueToEncode  ==>   ValueToEncode Coke Pepsi 
        =============  ===== ============= ==== =====
        Coke                               1    0     
        Pepsi                              0    1     
        Pepsi                              0    1
        =============  ===== ============= ==== =====

        
        Transform:
        
        =============  ===== ============= ==== =====
        ValueToEncode   ==>  ValueToEncode Coke Pepsi 
        =============  ===== ============= ==== =====
        Coke                               1    0     
        Tab                                0    0     
        =============  ===== ============= ==== =====
        '''                                        

        return self.__transform(series)

    @property
    def labels(self):
        return self.__known_labels

    def __fit(self, series):
        '''
        Convert series values to tightly packed integers using a label encoder
        Initialize the OneHotEncoder to have the corresponding number of values
        '''
        verify.not_none(series, "series")
        
        include_idx = series.notnull()

        # Check that there are rows to be transformed. 
        verify.true(any(include_idx), "Cannot fit an empty series")

        # Convert string series to numeric series
        self.__label_encoder = LabelEncoder()
        numeric_series = self.__label_encoder.fit_transform(series[include_idx])
        self.__known_labels = self.__label_encoder.classes_

        # Initialize OneHot encoder for the specified number of densely packed labels
        num_labels = self.__label_encoder.classes_.size
        self.__onehot_encoder = OneHotEncoder(n_values=num_labels, sparse=False)
        self.__onehot_encoder.fit_transform(NpArrayEx.to_nx1_mtx(numeric_series))
        self.__initialized = True
        if self._base_criteria == PdOneHotEncoder.BASE_FREQ:
            #Even if we set the seeds, ties for value_counts() may be random!
            counts = series.value_counts()
            counts = counts[counts == counts.iloc[0]] #filter by highest
            counts.sort_index(inplace=True)
            self._base_value = counts.index.values[0]

    def __transform(self, series):
        verify.true(self.__initialized, "Not fit")
        n_cols = self.__label_encoder.classes_.size
        include_idx = series.notnull() & series.isin(self.__label_encoder.classes_)

        # Check that there are rows to be transformed. 
        verify.true(any(include_idx), "Cannot transform an empty series")

        numeric_series = self.__label_encoder.transform(series.loc[include_idx])
        onehot_series = self.__onehot_encoder.transform(NpArrayEx.to_nx1_mtx(numeric_series))
        onehot_matrix = onehot_series.reshape(len(numeric_series), n_cols)

        classes = self.__label_encoder.classes_
        name_prefix = "" if series.name is None else series.name + "."
        try:
            col_names = name_prefix + classes #doesn't work for datetimes
        except:
            col_names = name_prefix + np.array([str(i) for i in classes], dtype=object)
        ret = pd.DataFrame(np.zeros((len(series), n_cols)), columns=col_names, index=series.index)
        ret.loc[include_idx] = onehot_matrix

        # Set index name to series name
        ret.columns.rename(series.name, inplace=True)
        
        #Filter out modal value
        if self.__drop_base:
            try:
                base_name = name_prefix + self._base_value
            except:
                base_name = name_prefix + str(self._base_value)
            ret = ret.loc[:, ret.columns.values != base_name]
            #ret = ret.iloc[:, ::-1]
        
        
        return  ret
