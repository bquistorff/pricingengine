#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import math
import msecore.verify as verify
from . import pdseriesex

class PdGroupByEx:
    LAG_COL_NAME = "{0} lag{1}"
    LEAD_COL_NAME = "{0} lead{1}"
    LAG_DIFF_COL_NAME = "{0} lag_diff{1}"
    LEAD_DIFF_COL_NAME = "{0} lead_diff{1}"

    @staticmethod
    def get_shift_name(name_pattern, col_name, shift):
        return name_pattern.format(col_name, shift)

    @staticmethod
    def exp_moving_avg(groupby, halflife, min_periods):
        """
            Compute the Exponential Weighted Moving Average for each instance (x) using the following weights (w):
            wᵢ := (exp(log(0.5) / halflife))ⁱ
            exp_rolling_avg = (wₜ·xₜ + wₜ₋₁·xₜ₋₁ + .... w₀·x₀) / (wₜ + wₜ₋₁ + ... + w₀)

        :param groupby:
        :param halflife: The period of time for the exponential weight to reduce to one half
        :param min_periods: The minimum number of non-missing values in the window, including current value, 
            required (NaN returned otherwise)
        :return: A single series where each instance is the Exponential Weighted Moving Average of the series up to
                and including that instance
        """
        verify.not_none(groupby, "groupby")
        verify.greaterthanzero(halflife, "halflife")
        verify.greaterthanzero(min_periods, "min_periods")
        verify.istype(groupby, pd.core.groupby.SeriesGroupBy)
        verify.series_groupby_is_numeric(groupby, "groupby")
        return groupby.apply(lambda x: pdseriesex.PdSeriesEx.exp_moving_avg(x, halflife=halflife, 
                                                                            min_periods=min_periods))

    @staticmethod
    def get_selection_name(groupby):
        if hasattr(groupby, '_selection_name'): #appears in pandas 0.20
            return groupby._selection_name  # pylint: disable=protected-access
        else:
            #copied from SeriesGroupBy:_selection_name
            if groupby._selection is None: # pylint: disable=protected-access
                return groupby.obj.name
            else:
                return groupby._selection # pylint: disable=protected-access

    @staticmethod
    def gen_lags(groupby, lag):
        """
        Create a dataframe of where each column corresponds to an offset series of the given series

        :param groupby: 
        :param lag: The maximum number of values by which to shift the series
        :return: A list of #lag columns where column i is a right shift of size (lag - i) of the given series:

        if n = 3 and lag = 2
        series = [x₀, x₁, x₂]
        col₀ = [NA, NA, x₀]
        col₁ = [NA, x₀, x₁]
        In general for a given lag = l and a series of length n,
        colₖ = [NA, NA,..., x₀, ..., xₙ₋ₗ₋₁₊ₖ]
        """
        verify.not_none(groupby, "groupby")
        verify.istype(groupby, pd.core.groupby.SeriesGroupBy)
        verify.series_groupby_is_numeric(groupby, "groupby")
        selection_name = PdGroupByEx.get_selection_name(groupby)
        if isinstance(lag, (list, range)):
            return [groupby.shift(x).rename(PdGroupByEx.LAG_COL_NAME.format(selection_name, x))
                    for x in lag]

        else:
            verify.greaterthanzero(lag, "lag")
            return [groupby.shift(x).rename(PdGroupByEx.LAG_COL_NAME.format(selection_name, x))
                    for x in range(1, lag+1)[::-1]]

    @staticmethod
    def gen_leads(groupby, leads):
        """
        Create a dataframe of where each column corresponds to an offset series of the given series

        :param groupby: 
        :param leads: The numbers of values by which to shift the series
        :return: A list of #lead columns where column i is a left shift of size (lead - i) of the given series:

        if n = 3 and lead = 2
        series = [x₀, x₁, x₂]
        col₀ = [x₁, x₂, NA]
        col₁ = [x₂, NA, NA]
        In general for a given lean = l and a series of length n,
        colₖ = [xₖ₊₁, xₖ₊₂, ... xₙ, NA,..., NA]
        """
        verify.not_none(groupby, "groupby")
        for lead in leads:
            verify.greaterthanzero(lead, "leads")
        verify.istype(groupby, pd.core.groupby.SeriesGroupBy)
        #verify.series_groupby_is_numeric(groupby, "groupby")
        selection_name = PdGroupByEx.get_selection_name(groupby)
        return [groupby.shift(-x).rename(PdGroupByEx.LEAD_COL_NAME.format(selection_name, x)) for x in leads]

    @staticmethod
    def gen_lag_diffs(groupby, lags):
        """
        Create a dataframe of where each column corresponds to the difference of a given series and an offset series=

        :param groupby: 
        :param lags: The maximum number of values by which to shift the series
        :return: A list of #lag columns where column i is the difference of the series and 
            a right shift of size (lag - i) of the given series:

        if n = 3 and lag = 2
        series = [x₀, x₁, x₂]
        col₀ = [NA, NA, x₂-x₀]
        col₁ = [NA, x₁-x₀, x₂-x₁]
        In general for a given lag = l and a series of length n,
        colₖ = [NA, NA,..., xₖ-x₀, ..., xₖ-xₙ₋ₗ₋₁₊ₖ]
        """
        verify.not_none(groupby, "groupby")
        #verify.greaterthanzero(lag, "lag")
        verify.istype(groupby, pd.core.groupby.SeriesGroupBy)
        verify.series_groupby_is_numeric(groupby, "groupby")
        selection_name = PdGroupByEx.get_selection_name(groupby)
        return [groupby.diff(x).rename(PdGroupByEx.LAG_DIFF_COL_NAME.format(selection_name, x))
                for x in lags]

    @staticmethod
    def gen_fore_diffs(groupby, leads):
        """
        Create a dataframe of where each column corresponds to the difference of an offset series with the given series 

        :param groupby: 
        :param leads: The values by which to shift the series
        :return: A list of #fore columns where column i is the differnece of the 
            left shift series (lag - i) and the given series

        if n = 3 and lag = 2
        series = [x₀, x₁, x₂]
        col₀ = [x₂-x₀, NA, NA]
        col₁ = [x₁-x₀, x₂-x₁, NA]
        In general for a given fore = l and a series of length n,
        colₖ = [xₗ-x₀, xₗ₊₁-x₁,..., NA]
        """
        verify.not_none(groupby, "groupby")
        for lead in leads:
            verify.greaterthanzero(lead, "leads")
        verify.istype(groupby, pd.core.groupby.SeriesGroupBy)
        verify.series_groupby_is_numeric(groupby, "groupby")
        offsets = leads
        selection_name = PdGroupByEx.get_selection_name(groupby)
        return [-groupby.diff(-x).rename(PdGroupByEx.LEAD_DIFF_COL_NAME.format(selection_name, x))
                for x in offsets]

