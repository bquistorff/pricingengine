#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import itertools
import functools
import timeit
import math
from enum import Enum
import pandas as pd
try: #0.20
    from pandas.core.reshape.util import cartesian_product
except: #0.19
    from pandas.tools.util import cartesian_product #pylint: disable=no-name-in-module
import numpy as np
from sklearn import linear_model
import msecore.verify as verify
from .mlexception import MLException, MLErrorCode
from msecoreml.pdmultiindexex import PdMultiIndexEx

#Error with pylint and enums: https://stackoverflow.com/questions/34661423/
# pylint: disable=redefined-variable-type, too-many-locals


class UnitTimeDFType(Enum):
    CROSS_SECTION = 1
    TIME_SERIES = 2
    PANEL = 3 #non-degenerate panel

class PdDataframeEx:
    """
    A collection of static utility methods that wrap common commands
    """

    @staticmethod
    def drop_rows_index_vals(df, vals, level=None):
        '''
        Like the opposite of pd.xs (except I can't yet take in tuples for vals and level

        :param df:
        :param vals: vals or tuple of vals
        :param level: level name (or int) or list of levels
        :returns: modified df
        '''
        if not isinstance(vals, tuple):
            vals = (vals,)
        if level is None:
            level = list(range(len(vals)))
        if not isinstance(level, list):
            level = [level]
        verify.true(len(vals) == len(level), "drop_rows_index_vals(): vals and level must be same length")

        to_drop = df.index.isin(vals[0], level=level[0])
        for i in range(1, len(vals)):
            to_drop = to_drop & df.index.isin(vals[i], level=level[i])
        return df[~to_drop]
    
    @staticmethod
    def select_and_drop(df, colname, val):
        '''
        Selects on a variable and then drops it. 
        (Like how xs selects on a value of an index-level and then drops the level.)
        '''
        return df.loc[df[colname] == val, :].drop(colname, axis=1)
    
    @staticmethod
    def groupbynot(df, not_list):
        yes_list = [l for l in df.index.names if l not in not_list]
        groupby = df.groupby(level=yes_list)
        return groupby


    #Simple exmaples that failes
    #left = pd.DataFrame({'L': ['L0', 'L1', 'L2', 'L3']}, 
    #                   index = pd.MultiIndex.from_tuples([('K0', 'Y0'), ('K0', 'Y1'), ('K1', 'Y0'), ('K1', 'Y1')], 
    #                                                     names=['key', 'Y']))
    #right = pd.DataFrame({'R': ['R0', 'R1']}, index = pd.MultiIndex.from_arrays([['K0', 'K1']], names=['key']))
    #left.merge(right, on=['key']) #produces error "KeyError: 'key'"
    #cf. https://stackoverflow.com/questions/13576164/how-to-keep-multiindex-when-using-pandas-merge
    # other things tried:
    #pf3.merge(pf2, how='left', left_index=True, right_index=True)
    # error: merging with more than one level overlap on a multi-index is not implemented
    #pf3.merge(pf2, how='left', on=pf2.index.names, left_index=True, right_index=True)
    # error: 'Retailer'
    @staticmethod
    def multiindex_merge_m1_full(dfl, dfr):
        '''
        Does a m:1 merge from l to r assuming dfr.index.names is a subset of those in dfl. Pandas utils don't work.
        '''
        lnames = dfl.index.names
        rnames = dfr.index.names
        dfl = dfl.reset_index()
        dfr = dfr.reset_index()
        dfl = dfl.merge(dfr, how='left', on=rnames)
        dfl = dfl.set_index(lnames)
        return dfl
    
    @staticmethod
    def keep_index_level_unlabelled(df, levels=0, droplevel=True):
        '''
        Returns the modified df where rows are dropped where the index levels have values
        that aren't in the label list. These end up being printed as nan
        If you extract the index as idx=mi.remove_levels([<other levels>]) then
        math.isnan(idx.values)==True for some values
        '''
        if not isinstance(levels, list):
            levels = [levels]
        for level in levels:
            df = df.iloc[df.index.labels[level] == -1]
        if droplevel:
            df.index = df.index.droplevel(levels)
        return df
    
    @staticmethod
    def drop_index_level_unlabelled(df, levels=0, droplevel=True):
        '''
        Opposite version of keep_index_level_unlabelled(). See there for help
        '''
        if not isinstance(levels, list):
            levels = [levels]
        for level in levels:
            df = df.iloc[df.index.labels[level] != -1]
        if droplevel:
            df.index = df.index.droplevel(levels)
        return df

    @staticmethod
    def gen_df_diff(df, var):
        (df_type, _, p_levels) = PdDataframeEx.panel_type(df)
        if df_type == UnitTimeDFType.PANEL:
            df.sort_index(inplace=True)
            return df.groupby(level=p_levels)[var].diff()


    @staticmethod
    def panel_type(df):
        time_level = None
        p_levels_i = []
        if isinstance(df.index, pd.MultiIndex):
            for i, elem in enumerate(df.index.levels):
                if isinstance(elem, (pd.DatetimeIndex, pd.PeriodIndex)):
                    time_level = i
                else:
                    p_levels_i.append(i)
        else: #pd.Index
            if isinstance(df.index, pd.DatetimeIndex):
                time_level = 0            
            else:
                p_levels_i.append(0)
                
        if time_level is None:
            df_type = UnitTimeDFType.CROSS_SECTION
        elif len(p_levels_i) == 0:
            df_type = UnitTimeDFType.TIME_SERIES
        else:
            df_type = UnitTimeDFType.PANEL

        return (df_type, time_level, p_levels_i)
    
    @staticmethod
    def append_cols_inplace(dest_df, source_df):
        if isinstance(source_df, pd.Series):
            col = source_df.name
            dest_df[col] = source_df
        else:
            for col in source_df.columns:
                dest_df[col] = source_df[col]

    @staticmethod
    def assign_inplace(dest_df, source_df):
        '''
        Hard to modify a dataframe in place (like for modifying func parameters)

        :param dest_df: Currently, this needs to be an empty df
        :param source_df:
        '''
        if len(dest_df.columns) > 0:
            dest_df.drop(dest_df.columns, axis=1, inplace=True)
        PdDataframeEx.append_cols_inplace(dest_df, source_df)
        
    @staticmethod
    def append_rows_inplace(dest_df, source_df, simple_index=True):
        '''
        May change the storage type to floating-point precision
        Works row-by-row so may be slow

        :param dest_df:
        :param source_df:
        :param simple_index: We handle two types of indexing. simple_index=T (default) assumes that
            dest_df has a simple numerically increasing index and we just extend that (so
            we don't look at the index values of source_df). simple_index=F looks at source_df and
            uses those index values to add to dest_df (which could result in overwritting if 
            the index values are duplicated).

        '''
        if simple_index:
            for sindex, srow in source_df.iterrows():
                dest_df.loc[dest_df.index.max() + 1, :] = srow
        else:
            for sindex, srow in source_df.iterrows():
                dest_df.loc[sindex, :] = srow


    @staticmethod
    def gen_pct_change(dframe, colname, offset=1):
        """
            Generate a series representing the percentage changes in a column's value.

            :param dframe:
            :type dframe: pd.DataFrame
            :param colname:
            :param int offset: 
                How many intervals back should we compare to?
            :return: Pct changes for all rows in the dataframe
        """
        verify.not_none(dframe, "dframe")
        verify.greaterthanzero(offset, "offset")
                
        rows = dframe[colname]
        return ((rows - rows.shift(offset))/rows).fillna(0)

    @staticmethod
    def gen_labels(dframe, cond):
        """
            For ML - generates "labels" of 0 and 1. 
            Applies the given condition to each row in the dframe and produce a 0 or 1 label

            :param dframe:
            :type dframe: pd.DataFrame 
            :param cond:
        """
        verify.not_none(dframe, "dframe")
        return dframe.where(cond, 1, 0)

    @staticmethod
    def add_pct_change_cols(dframe, src_colname, change_colname, startoffset=1, maxoffset=1):
        """
            Compute the percentage changes in a column's value for multiple intervals.
            Add the changes for each interval as a new column to the data frame. 
            E.g. compute the percent change relative to the last 5 measurements

            :param dframe:
            :type dframe: pd.DataFrame
            :param src_colname:
            :param change_colname:
            :param startoffset:
            :param maxoffset:
        """
        verify.not_none(dframe, "dframe")
        verify.greaterthanequals(maxoffset, startoffset, "offset range")
        if startoffset < maxoffset:
            for i in range(startoffset, maxoffset + 1):
                dframe[change_colname + str(i)] = PdDataframeEx.gen_pct_change(dframe, src_colname, i)
        else:
            dframe[change_colname] = PdDataframeEx.gen_pct_change(dframe, src_colname, startoffset)
    
    @staticmethod
    def interact_series_with_dataframe(dataframe, scales, col_name_format=None):
        """
        Create a dataframe by multiplying each column in the dataframe by a corresponding series of scale values

        :param dataframe: A dataframe with k columns and n rows 
        :param scales: A 1-dimensional pandas series [s₀, s₁, ... sₙ]
        :param col_name_format:
        :return: A dataframe where each column is the pairwise product of the original column with the scale values
                [x₀, x₁, ... xₙ] -> [x₀s₀, x₁s₁, ..., xₙsₙ]
        """
        verify.not_none(dataframe, "series")
        verify.not_none(scales, "scales")
        verify.dataframe_is_numeric(dataframe, "dataframe")
        verify.series_is_numeric(scales, "scales")
        ret = dataframe.multiply(scales, axis=0)
        dummy_names = dataframe.columns.values
        new_names = dummy_names if col_name_format is None \
            else [col_name_format.format(dummy_name) for dummy_name in dummy_names]
        old_to_new_name = {dummy_name : new_name for (dummy_name, new_name) in zip(dummy_names, new_names)}
        ret.rename(columns=old_to_new_name, inplace=True)
        return ret

    @staticmethod
    def __get_values_as_tuple(index):
        return index.values if isinstance(index, pd.MultiIndex) else [(x,) for x in index.values]

    @staticmethod
    def __interact_df_with_df(scales_df, target_df):
        '''
        scales_df                             
        == ====          
        S1 X Y              
        == ====              
           x₀  y₀             
           x₁  y₁         
           ... ...        
           xₙ  yₙ          
        == ==== 
        
        target_df
        == =====
        T2 A   B   
        == =====
        T1 M   N   
        == =====
           m₀ n₀  
           m₁ n₁ 
           .. ...   
           mₙ nₙ  
        == =====

        return dataframe
        +----+-----------------------------+
        | S1 | X      X      Y       Y     |
        +----+-----------------------------+
        | T2 | A      B      A       B     |
        +----+-----------------------------+
        | T1 | M      N      M       N     |
        +----+-----------------------------+
        |    | m₀*x₀  n₀*x₀  m₀*y₀   n₀*y₀ |
        +----+-----------------------------+
        |    | m₁*x₁  n₁*x₁  m₁*y₁   n₁*y₁ |
        +----+-----------------------------+
        |    | ...    ...    ...     ...   |
        +----+-----------------------------+
        |    | mₙ*xₙ   nₙ*xₙ   mₙ*yₙ    nₙ*yₙ |
        +----+-----------------------------+
        '''
        
        # Ensure that there are not overlapping column indexes (don't know how to join in this case)
        scales_index_names = scales_df.columns.names
        target_index_names = target_df.columns.names
        verify.length_equals(set(scales_index_names).intersection(set(target_index_names)), 0, 
                             "overlapping index names")
        interaction_dfs = [PdDataframeEx.interact_series_with_dataframe(target_df, scales_df.iloc[:, i]) 
                           for i in range(0, len(scales_df.columns))]
        interactions = PdDataframeEx.concat_along_rows(interaction_dfs)
        scales_index_values = PdDataframeEx.__get_values_as_tuple(scales_df.columns)
        target_index_values = PdDataframeEx.__get_values_as_tuple(target_df.columns)
        ret_index_values = [a + b for (a, b) in itertools.product(scales_index_values, target_index_values)]
        interactions.columns = pd.MultiIndex.from_tuples(ret_index_values, 
                                                         names=scales_index_names + target_index_names)
        return interactions

    @staticmethod
    def interact_dataframes(dataframe_list):
        verify.not_none_or_empty(dataframe_list, "dataframe_list")

        if len(dataframe_list) == 1:
            return dataframe_list[0]

        if len(dataframe_list) == 2:
            return PdDataframeEx.__interact_df_with_df(dataframe_list[0], dataframe_list[1])

        return functools.reduce(PdDataframeEx.__interact_df_with_df, dataframe_list)

    @staticmethod
    def append_series_to_dataframe(series, dataframe):
        """
        Create a dataframe by appending the given series as a new column to the end of the dataframe

        :param series: The new column to append
        :param dataframe: A dataframe with a single column index to which to append the column
        :return: A single dataframe containing the dataframe with the new column appended
        """
        verify.not_none(dataframe, "dataframe")
        verify.not_none(series, "series")
        verify.istype(dataframe.columns, pd.Index)
        verify.true(not isinstance(dataframe.columns, pd.MultiIndex), "Cannot concat series with multiindex dataframe")
        verify.true(dataframe.columns.name is None, "Dataframe column index name must be None")
        return pd.concat([dataframe, series], axis=1)

    @staticmethod
    def prepend_series_to_dataframe(series, dataframe):
        """
        Create a dataframe by prepending the given series as a new column at the start of the dataframe

        :param series: The new column to append
        :param dataframe: A dataframe with a single column index to which to prepend the column
        :return: A single dataframe containing the dataframe with the new column prepended
        """
        verify.not_none(dataframe, "dataframe")
        verify.not_none(series, "series")
        verify.istype(dataframe.columns, pd.Index)
        verify.true(not isinstance(dataframe.columns, pd.MultiIndex), "Cannot concat series with multiindex dataframe")
        verify.true(dataframe.columns.name is None, "Dataframe column index name must be None")
        return pd.concat([series, dataframe], axis=1)

    @staticmethod
    def concat_along_rows(dataframes, levels=None, name=None):
        """
        Create a dataframe combining all the given dataframes

        :param dataframes: List of dataframes and series, all with the same number of rows and the same index
        :param levels:
        :param name:
        :return: A single dataframe containing all the given columns
        """
        verify.not_none_or_empty(dataframes, "cols")
        verify.true(all([isinstance(x, pd.DataFrame) for x in dataframes]), "All input must be dataframes")
        verify.true(all([x.columns.names == dataframes[0].columns.names for x in dataframes[1:]]), 
                    "All dataframes must have matching column index")

        # If no new levels are specified, simply return the pandas implementation
        if levels is None:
            return pd.concat(dataframes, axis=1)  

        verify.length_equals(levels, len(dataframes), "levels")
        existing_names = dataframes[0].columns.names
        ret = pd.concat(dataframes, keys=levels, names=[name] + existing_names, axis=1)
        return ret

    @staticmethod
    def drop_col_inplace(dataframe, col):
        verify.not_none(dataframe, "dataframe")
        verify.not_none(col, "col")
        if col is str:
            col = PdDataframeEx.get_col_by_name(dataframe, col)
        dataframe.drop(col, axis=1, inplace=True)
        return dataframe

    @staticmethod
    def prepend_col_names(dataframe, prefix):
        """
        Prepend each column name in the given dataframe with the specified prefix

        :param dataframe: The dataframe in which to prepend the columns
        :param prefix: The string to pre-pend to the column names
        """
        new_names = {name:prefix + name for name in list(dataframe)}
        return dataframe.rename(columns=new_names, copy=False)

    @staticmethod
    def get_column_or_index(dataframe, name):
        verify.not_none(dataframe, "dataframe")
        verify.not_none_or_empty(name, "name")
        verify.dataframe_contains_col_index(dataframe, name, "dataframe")
        if name in dataframe.index.names:
            dataframe[name] = dataframe.index.get_level_values(name)
            ret = dataframe[name]
            dataframe.drop(name, axis=1, inplace=True)
            return ret
        else:
            return dataframe[name]

    @staticmethod    
    def get_col_by_multiindex(dataframe, level_value_by_name, as_series=True):
        '''
        Get a single column as specified by the given multiindex level values. 

        :param dataframe: The dataframe from which to get the column.
        :type dataframe: pd.DataFrame
        :param dictionary level_value_by_name: dictionary mapping index name to level value, specifying a 
            level value for each index in the multiindex
        :param bool as_series: If True, return the column as a pd.Series, thereby dropping any column multiindex 
            information. If False, return a pd.Dataframe consisting of a single column.
        :return: The specified column, as either a pd.Series or pd.DataFrame. 
        :raises: Exception raised if no such column can be found or if multiple such columns are found.
        '''
        verify.not_none(dataframe, "dataframe")
        verify.not_none(level_value_by_name, "level_value_by_name")
        indicator = PdMultiIndexEx.get_nlevel_singleton_indicator(dataframe.columns, level_value_by_name)
        return dataframe.loc[:, indicator].iloc[:, 0] if as_series else dataframe.loc[:, indicator]

    @staticmethod    
    def get_cell_by_multiindex(dataframe, row_level_value_by_name, col_level_value_by_name):
        '''
        Get a single column as specified by the given multiindex level values. 

        :param dataframe: The dataframe from which to get the value
        :type dataframe: pd.DataFrame
        :param dictionary row_level_value_by_name: dictionary mapping index name to level value, specifying a level 
            value for each index in the row multiindex
        :param dictionary col_level_value_by_name: dictionary mapping index name to level value, specifying a level 
            value for each index in the col multiindex
        :return: The specified value
        :raises: Exception raised if no such cell can be found or if multiple such cellss are found.
        '''
        verify.not_none(dataframe, "dataframe")
        verify.not_none(row_level_value_by_name, "row_level_value_by_name")
        verify.not_none(col_level_value_by_name, "col_level_value_by_name")
        row_indicator = PdMultiIndexEx.get_nlevel_singleton_indicator(dataframe.index, row_level_value_by_name)
        col_indicator = PdMultiIndexEx.get_nlevel_singleton_indicator(dataframe.columns, col_level_value_by_name)
        return dataframe.loc[row_indicator, col_indicator].iloc[0, 0]

    @staticmethod
    def get_col_by_name(dataframe, col_name):
        verify.not_none(dataframe, "dataframe")
        col = dataframe.columns.get_loc(col_name)
        if col is None:
            return None
        return dataframe[dataframe.columns[col]]

    @staticmethod
    def using_default_index(dataframe):
        verify.not_none(dataframe, "dataframe")
        return len(dataframe.index.names) == 1 and dataframe.index.names[0] is None

    @staticmethod
    def get_nan_inf_indicator(df):
        return (~np.isfinite(df)).any(axis=1)

    @staticmethod
    def broadcast_scale(dataframe, scales):
        '''
        Given a dataframe M of columns [c₀, c₁, ..., cₘ] and series of scales [s₀, s₁, ..., sₙ], return the 
        dataframe consisting of each column scaled by each scale (m * n columns)
        => [s₀*c₀, s₀*c₁, ..., s₀*cₘ, s₁*c₀, s₁*c₁, ..., sₙ*cₘ, sₙ*c₀, sₙ*c₁, ..., sₙ*cₘ]
        => [M*s₀, M*s₁, ..., M*sₙ]
        '''

        scaled_dfs = [PdDataframeEx.interact_series_with_dataframe(dataframe, s) for s in scales]
        ret = PdDataframeEx.concat_along_rows(scaled_dfs)
        return ret

    @staticmethod
    def add_series_to_each_col(series, dataframe):
        '''
        Given a dataframe M of columns [a, b, c, ...] and series of summands [s₀, s₁, ..., sₙ], return the 
        dataframe consisting of the summand added to each column [a', b', c', ...]
        => a' = [s₀ + a₀, s₁ + a₁, ..., sₙ + aₙ]
        => b' = [s₀ + b₀, s₁ + b₁, ..., sₙ + bₙ]
        => c' = [s₀ + c₀, s₁ + c₁, ..., sₙ + cₙ]
        '''
        if not dataframe.index.equals(series.index):
            raise MLException(MLErrorCode.RowIndexMismatch, "summands")

        ret = pd.DataFrame(dataframe.values + series.values[:, np.newaxis], index=dataframe.index, 
                           columns=dataframe.columns)
        return ret

    @staticmethod
    def append_to_col_multiindex(dataframe, new_name, new_values):
        verify.length_equals(new_values, len(dataframe.columns.values), "index_values")

        cur_names = dataframe.columns.names
        names = cur_names + [new_name]

        new_labels, new_levels = PdDataframeEx.__list_to_labels_and_levels(new_values)
        if isinstance(dataframe.columns, pd.MultiIndex):
            cur_levels = dataframe.columns.levels
            cur_labels = dataframe.columns.labels
            levels = cur_levels + [new_levels]
            labels = cur_labels + [new_labels]
            
        else:
            cur_labels, cur_levels = PdDataframeEx.__list_to_labels_and_levels(dataframe.columns.values)
            levels = [cur_levels] + [new_levels]
            labels = [cur_labels] + [new_labels]
            
        index = pd.MultiIndex(levels=levels, labels=labels, names=names)
        ret = pd.DataFrame(dataframe.values, dataframe.index, columns=index)        
        return ret

    @staticmethod
    def __list_to_labels_and_levels(values):
        levels = list(set(values))
        level_to_label = {v:i for i, v in enumerate(levels)}
        labels = [level_to_label[x] for x in values]
        return labels, levels


    @staticmethod
    def gen_cartesian_product(series_list, series_names):
        """
        Do cartesian product
        But built-in forgets type so convert back
        """
        #Could see if there is a built=in way to do this type mapping
        type_conversion = {type(1):'int32', type(1.1):'float64', type(np.datetime64('2010-01-01')):'datetime64[ns]'}
        pd_type_dict = {}
        for i, name in enumerate(series_names):
            thetype = type(series_list[i][0])
            pd_type_dict[name] = type_conversion.get(thetype) or 'object'

        df = pd.DataFrame(cartesian_product(series_list), index=series_names).transpose()
        df = df.astype(pd_type_dict, copy=False)
        return df

    @staticmethod
    def reset_row_index(df, inplace=False):
        return df.reset_index(drop=True, inplace=inplace)

    @staticmethod
    def append_to_row_index(df, col_names):
        verify.not_none(col_names, "col_names")
        for name in col_names:
            verify.list_contains_value(df.columns.values, name, "df.columns.values")
        return df.set_index(col_names, append=True, drop=False)

    @staticmethod
    def set_row_index(df, col_names):
        verify.not_none(col_names, "col_names")

        for name in col_names:
            verify.list_contains_value(df.columns.values, name, "df.columns.values")
        return df.set_index(col_names, append=False, drop=False)

    @staticmethod
    def get_row_index_values(df, index_name):
        verify.list_contains_value(df.index.names, index_name, "multiindex.names")
        return pd.Series(df.index.get_level_values(index_name).values, name=index_name)

    @staticmethod
    def get_col_index_values(df, index_name):
        verify.list_contains_value(df.columns.names, index_name, "multiindex.names")
        return pd.Series(df.columns.get_level_values(index_name).values, name=index_name)

    @staticmethod
    def get_col_from_indicator(df, indicator):
        verify.true(sum(indicator) == 1, "more than one column indicated")
        return df.loc[:, indicator].iloc[:, 0]

    #
    # Casting extensions
    #
    @staticmethod
    def cast_col_inplace(dataframe, colname, dtype):
        """
            Cast a column in a dataframe to a new type - INPLACE
        """
        verify.not_none(dataframe, "dataframe")
        verify.not_none_or_empty(colname, "colname")
        return dataframe.astype({colname : dtype}, copy=False)

    #
    # Extensions for Text Columns
    #
    @staticmethod
    def str_cat(dataframe, col_names, sep=None):
        """
            String concatenate the given columns (names)
            Returns a new series with the concatenated text
        """
        verify.not_none(dataframe, "dataframe")
        verify.not_none_or_empty(col_names, "column_names")
        verify.greaterthanone(len(col_names), "column_names")

        others = [dataframe[col_names[i]] for i in range(1, len(col_names))]
        return dataframe[col_names[0]].str.cat(others, sep)

    @staticmethod
    def str_split_paths(dataframe, colname, sep='/'):
        """
            If Column Data is a 'path' into a hierarchy, this method
            will split the paths and return a data frame with each level
            in the path represented by its own column
        """
        verify.not_none(dataframe, "dataframe")
        verify.not_none_or_empty(colname, "colname")
        return dataframe[colname].str.split(sep, expand=True)

    @staticmethod
    def impute_panel_column(dataframe, index_name, fill_value=0):
        '''
        For a given dataframe consisting of one or more panels, fill rows such that for the given row
        index, each panel has a row for each known level. 

        For example, in the following table, there is no entry for apples on Tuesday. Therefore, that row is added 
        with the specified fill value (here, 0.0).

        NOTE: The same fill value is used across all columns, regardless of column type.

        ==== ========  ===== =======  
        day  item      price quality
        ==== ========  ===== =======  
        Mon  oranges   1.0   'good'  
        Tue  oranges   1.1   'good'   
        Mon  apples    2.0   'okay'   
        Mon  bananas   3.0   'okay'  
        Tue  bananas   3.1   'good'   
        ==== ========  ===== ======= 
                                                 
        ==== ========  ===== =======  
        day  item      price  quality
        ==== ========  ===== =======  
        Mon  oranges   1.0    'good'  
        Tue  oranges   1.1    'good'  
        Mon  apples    2.0    'okay'  
        Tue  apples    0.0     0.0    
        Mon  bananas   3.0    'okay'  
        Tue  bananas   3.1    'good'  
        ==== ========  ===== =======  

        :param dataframe: The dataframe into which to insert rows. 
        :param index_name: The name of the index level for which to fill in missing items
        :param fill_value: The value to use for filling in missing entries
        :return: A copy of the original dataframe with missing rows inserted.
        '''
        # Impute missing rows with zero by pivoting and unpivoting
        unstacked = dataframe.unstack(level=index_name, fill_value=fill_value)
        filled = unstacked.stack(level=index_name)

        return filled

    #@staticmethod
    #def extract_repeat_panel_column(dataframe, index_name, column_name, fill_value=0):
    #    '''
    #    For a given dataframe consisting of one or more panels, create a column for each level in a the
    #    specified index and for each panel, fill its section of the column with its particular value in the
    #    specified column. Currently only works in pandas 0.20 and higher (uses pd.MultiIndex:remove_unused_levels()).
        
    #    ==== ========  ===== =======           
    #    day  item      price  quality
    #    ==== ========  ===== =======                      
    #    Mon  oranges   1.0    'good'                    
    #    Mon  apples    2.0    'okay'                    
    #    Mon  bananas   3.0    'okay'                 
    #    Tue  oranges   1.1    'good'  
    #    Tue  bananas   3.1    'good'  
    #    ==== ========  ===== =======  

    #    ==>

    #    ==== ========  ======= ====== ======  
    #    day  item      oranges apples bananans 
    #    ==== ========  ======= ====== ======  
    #    Mon  oranges   1.0     2.0    3.0      
    #    Mon  apples    1.0     2.0    3.0      
    #    Mon  bananas   1.0     2.0    3.0      
    #    Tue  oranges   1.1     0.0    3.1      
    #    Tue  bananas   1.1     0.0    3.1      
    #    ==== ========  ======= ====== ======  


    #    :param dataframe: The a dataframe, sorted by row index, into which to insert rows. 
    #    :param index_name: The name of the index level from which to build columns
    #    :param column_name: The name of the column from which to get values to fill the new columns
    #    :param fill_value: The value to use for filling in missing entries
    #    :return: The columns constructed, as a dataframe, with the row index of the input dataframe.
    #    '''
    #    # Ensure groups (panels) are contiguous
    #    verify.true(dataframe.index.is_lexsorted(), "df not sorted")

    #    # Get the dataframe with missing rows filled with 0
    #    filled = PdDataframeEx.impute_panel_column(dataframe, index_name, fill_value=fill_value)

    #    # Get the levels used. Be sure to get these AFTER unstack as unused levels may be in the original index
    #    levels = PdMultiIndexEx.get_levelvalues_by_name(filled.index.remove_unused_levels(), index_name)
    #    num_levels = len(levels)

    #    # Generate the columns
    #    repeats = {levels[i] : np.repeat(filled[column_name][i::num_levels], num_levels).values 
    #               for i in range(0, num_levels)}

    #    # Return a dataframe of the generated columms, removing rows that were not in the input dataframe. 
    #    ret = pd.DataFrame(repeats, index=filled.index, columns=pd.Index(levels, name=index_name))
    #    return ret.reorder_levels(dataframe.index.names).loc[dataframe.index, :]

    #@staticmethod
    #def align_to_col_index(dataframe, target_col_index):
    #    '''
    #    For a given dataframe, add/drop columns as-needed so that its column index matches the specified target index. 
    #    Columns added are filled with zeroes. 
    #        Currently only works in pandas 0.20 or greater (uses pd.MultiIndex:contains())

    #    :param dataframe: The base dataframe for which to add/drop columns
    #    :param target_col_index: The column index to which to match for the returned dataframe
    #    :return: A dataframe with a column index matching the specified column index
    #    '''
    #    zero_col = np.zeros(dataframe.shape[0])
    #    get_col = lambda k: dataframe.loc[:, k].values if dataframe.columns.contains(k) else zero_col
    #    col_list = [get_col(k) for k in target_col_index.values]
    #    ret = pd.DataFrame(np.vstack(tuple(col_list)).transpose(), index=dataframe.index, columns=target_col_index)
    #    return ret
        
    @staticmethod
    def stack_as_block_diagonal(dataframe, index_name):
        '''
        For a given dataframe, add/drop columns as-needed so that its column index matches the specified target index. 
        Columns added are filled with zeroes. 

        :param dataframe: The base dataframe for to pivot to a block diagonal
        :param index_name: The name of the index on which to block rows
        :return: A dataframe where the rows have been pivoted such that each level in the index is a block
                 in a block diagonal. 

        +------+-------------------------+                  
        | site | 1       2       3       | 
        +------+-------------------------+ 
        | item | A   B   A   B   A   B   |  
        +------+-------------------------+
        |      | 1   2   10  20  100 200 |  
        +------+-------------------------+
        |      | 3   4   30  40  300 400 |
        +------+-------------------------+
                                        
             
        =>     
        (index_name = site)

        +------+------+--------+-------+
        | site | 1    |  2     | 3     |
        +------+------+--------+-------+
        | item | A   B|  A   B | A   B |
        +------+------+--------+-------+  
        |  1   | 1  2 |        |       |
        +------+------+--------+-------+
        |      | 3  4 |        |       |
        +------+------+--------+-------+
        |  2   |      |10  20  |       |
        +------+------+--------+-------+
        |      |      |30  40  |       |
        +------+------+--------+-------+
        |  3   |      |        |100 200|
        +------+------+--------+-------+
        |      |      |        |300 400|
        +------+------+--------+-------+  
                                        
                                        
        =>                                            
        (index_name = item)

        +-----+------------+-----------+
        |site | 1   2   3  |1   2   3  |
        +-----+------------+-----------+
        |item | A   A   A  |B   B   B  | 
        +-----+------------+-----------+
        |   A | 1   10  100|           |
        +-----+------------+-----------+
        |     | 3   30  300|           |
        +-----+------------+-----------+
        |   B |            |2   20  200|
        +-----+------------+-----------+
        |     |            |4   40  400|
        +-----+------------+-----------+
        '''
        verify.not_none(dataframe, "dataframe")
        verify.istype(dataframe.columns, pd.MultiIndex)
        verify.list_contains_value(dataframe.columns.names, index_name, "index_name")

        # Get the position of the named index in the multiindex
        multiindex = dataframe.columns
        index_position = multiindex.names.index(index_name)
        new_index = pd.MultiIndex(levels=multiindex.levels + [multiindex.levels[index_position]], 
                                  labels=multiindex.labels + [multiindex.labels[index_position]], 
                                  names=multiindex.names + [None])

        # Make a dataframe with the new index
        tmp_dataframe = pd.DataFrame(dataframe.values, index=dataframe.index, columns=new_index)

        # Unstack the newly added index level to create the block diagonal. 
        block = tmp_dataframe.transpose().unstack(level=-1, fill_value=0.0).transpose()
        block.index = block.index.rename(block.index.names[:-1] + [index_name])

        # Ensure both multindexes are sorted the same way on shared indexes (the stack() sorts)
        block.sort_index(axis=0, level=index_name, inplace=True)
        block.sort_index(axis=1, level=index_name, inplace=True)

        return block

    @staticmethod
    def append_uniform_col_index(dataframe, index_value, index_name):
        ret = pd.concat([dataframe], keys=[index_value], names=[index_name], axis=1)
        return ret
    
    @staticmethod
    def concat_frames(frames):
        """
            :param An iterable of DataFrame frames:
            :return: Single concatenated data frame
        """
        combined = None
        for frame in frames:
            if combined is None:
                combined = frame
            else:
                combined = combined.append(frame)
        return combined

    @staticmethod
    def agg_duplicates(data, identifiers, unit_cols, price_cols):
        '''
        Transforms df in order to eliminate duplicate observations using logic that would correspond with 
            common pricing problems

        :param data: DataFrame of raw data that may have duplicates
        :param identifiers: list of columns that identify unique entries in the data set
        :param unit_cols: list of DataFrame columns for which duplicates should be summed
        :param price_cols: list of  DataFrame columns for which duplicates should be resolved by taking a min
        '''
        aggregator = {col : np.sum for col in unit_cols}
        aggregator.update({col : ['min', 'max'] for col in price_cols})
        aggregator.update({j : 'first' for j in data.columns if j not in identifiers + unit_cols + price_cols})
        new_data = data.groupby(by=identifiers).agg(aggregator)
        new_data = new_data.reset_index()
        new_data.columns = new_data.columns.get_level_values(0) + new_data.columns.get_level_values(1)

        for col in price_cols:
            tmp = (new_data[col + 'min']-new_data[col + 'max']).values
            if np.std(tmp) > 0:
                print('Check your raw data. There are this many non unique price values: ' + \
                    str(sum([j != 0 for j in tmp])))
            del new_data[col + 'max']

        renamer = {col + 'min': col for col in price_cols}
        renamer.update({col + 'sum' : col for col in unit_cols})
        renamer.update({j : j[:j.find('first')] for j in new_data.columns if 'first' in j})
        new_data = new_data.rename(columns=renamer)
        return new_data


    @staticmethod
    def fill_missing(data, panel_cols, date_col, day_interval, fill_nan=None, fill_zero=None):
        '''
        Fills in missing observations between the first and last available date at the cadence specified. 
            Newly created values for all columns default to their last available value (unless specified otherwise)
    
        :param data: Dataframe containing raw data
        :param panel_cols: list of columns that serve as panel identifiers
        :param date_col: Column which indicates the date. Must be poppulated by datetime
        :param fill_nan: list of  DataFrame columns which are set to nan for all missing obs
        :param fill_zero: list of  DataFrame columns which are set to zero for all missing obs
        :param day_interval: Number of days between consecutive observations
        '''
        if fill_nan is None:
            fill_nan = []
        if fill_zero is None:
            fill_zero = []

        start_time = timeit.default_timer()
        
        all_cols = set(data.columns.values) - set(panel_cols + [date_col])
        fill_last = list(all_cols - set(fill_nan + fill_zero))
        all_cols = list(all_cols)

        grouper = data.groupby(panel_cols).agg({date_col : [np.min, np.max]})
        if 'int' in str(data[date_col].dtype):
            index_tuples = [index + (date,) for (index, row) in grouper.iterrows() for date
                            in range(row[date_col, 'amin'], row[date_col, 'amax'] + 1, day_interval)]
        else:
            index_tuples = [index + (date,) for (index, row) in grouper.iterrows() for date
                            in pd.date_range(row[date_col, 'amin'], row[date_col, 'amax'],
                                             freq=str(day_interval) + 'D')]

        new_index = pd.MultiIndex.from_tuples(index_tuples, names=panel_cols + [date_col])
    
        indexed_data = data.set_index(panel_cols + [date_col])
        new_data = indexed_data.reindex(new_index, fill_value=np.nan)

        missing = (new_data[all_cols[0]].isnull())
        missing_ct = sum(missing)

        new_data.loc[missing, fill_zero] = 0

        if len(fill_last) > 0:
            #Slow iterative algorithm here to find most recent available price. There is probably something faster
            while sum(missing) > 0:
                miss_shift = missing.shift(-1).replace(np.nan, False)
                new_data.loc[missing, fill_last] = new_data.loc[miss_shift, fill_last].values
                missing = (new_data[fill_last[0]].isnull())
                    

        print('Replacing ' + str(missing_ct) + ' records takes: ' + str(timeit.default_timer() - start_time))
    
        return new_data.reset_index()
    
    @staticmethod
    def drop_dates(data, date_col, ratio_dates_to_drop):
        '''
        Provides a subsample of the data where whole dates either kept or dropped.
        Does so in a way that kept dates have equal spacing

        :param data:
        :param date_col:
        :param ratio_dates_to_drop: For every kept date, how many to drop. 0 means don't drop any
        '''
        if ratio_dates_to_drop > 0:
            t_ind = pd.factorize(data[date_col])[0]
            return data.iloc[np.mod(t_ind, ratio_dates_to_drop + 1) == 0, :]
        else:
            return data
