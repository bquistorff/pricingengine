#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import enum
from msecore.mseexception import MseException

class MLErrorCode(enum.Enum):
    NoError = 0
    InvalidDType = 1
    ModelNotYetInitialized = 2
    ModelPreviouslyInitialized = 3
    RowIndexMismatch = 4
    ColumnIndexMismatch = 5
    EmptyTrainingData = 6

class MLException(MseException):
    def __init__(self, mlerror, message=None):
        super().__init__(mlerror, MLException._tostring(message, mlerror))

