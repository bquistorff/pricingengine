#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import math
import msecore.verify as verify
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from scipy.sparse import csc_matrix

class PdSeriesEx:
 
    @staticmethod
    def exp_moving_avg(series, halflife, min_periods):
        """
        Compute the Exponential Weighted Moving Average for each instance (x) using the following weights (w):
        wᵢ := (exp(log(0.5) / halflife))ⁱ
        exp_rolling_avg = (wₜ·xₜ + wₜ₋₁·xₜ₋₁ + .... w₀·x₀) / (wₜ + wₜ₋₁ + ... + w₀)

        :param series: data
        :param halflife: The period of time for the exponential weight to reduce to one half
        :param min_periods: The minimum number of non-missing values in the window required (NaN returned otherwise)
        :return: A single series where each instance is the Exponential Weighted Moving Average of the series up to
                and including that instance
        """
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        return series.ewm(halflife=halflife, min_periods=min_periods).mean()

    @staticmethod
    def gen_lags(series, lag):
        """
        Create a dataframe of where each column corresponds to an offset series of the given series

        :param series: A 1-dimensional pandas series [x₀, x₁, ... xₙ]
        :param lag: The maximum number of values by which to shift the series
        :return: A dataframe with #lag columns where column i is a right shift of size (lag - i) of the given series:

        if n = 3 and lag = 2
        series = [x₀, x₁, x₂]
        col₀ = [NA, NA, x₀]
        col₁ = [NA, x₀, x₁]
        In general for a given lag = l and a series of length n,
        colₖ = [NA, NA,..., x₀, ..., xₙ₋ₗ₋₁₊ₖ]
        """
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        verify.greaterthanzero(lag, "lag")
        return [series.shift(x) for x in range(1, lag+1)[::-1]]

    @staticmethod
    def gen_leads(series, lead):
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        verify.greaterthanzero(lead, "lead")
        offsets = range(1, lead+1)
        return [series.shift(-x) for x in offsets]

    @staticmethod
    def gen_lag_diffs(series, lag):
        """
        Create a dataframe of where each column corresponds to the difference of a given series and an offset series=

        :param series: A 1-dimensional pandas series [x₀, x₁, ... xₙ]
        :param lag: The maximum number of values by which to shift the series
        :return: A dataframe with #lag columns where column i is the differnece of the series and 
            a right shift of size (lag - i) of the given series:

        if n = 3 and lag = 2
        series = [x₀, x₁, x₂]
        col₀ = [NA, NA, x₂-x₀]
        col₁ = [NA, x₁-x₀, x₂-x₁]
        In general for a given lag = l and a series of length n,
        colₖ = [NA, NA,..., xₖ-x₀, ..., xₖ-xₙ₋ₗ₋₁₊ₖ]
        """
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        verify.greaterthanzero(lag, "lag")
        return [series - series.shift(x) for x in range(1, lag+1)[::-1]]

    @staticmethod
    def gen_fore_diffs(series, fore):
        """
        Create a dataframe of where each column corresponds to the difference of an offset series with the given series 

        :param series: A 1-dimensional pandas series [x₀, x₁, ... xₙ]
        :param fore: The maximum number of values by which to shift the series
        :return: A dataframe with #fore columns where column i is the differnece of the 
            left shift series (lag - i) and the given series

        if n = 3 and lag = 2
        series = [x₀, x₁, x₂]
        col₀   = [x₂-x₀, NA, NA]
        col₁   = [x₁-x₀, x₂-x₁, NA]
        In general for a given fore = l and a series of length n,
        colₖ = [xₗ-x₀, xₗ₊₁-x₁,..., NA]
        """
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        verify.greaterthanzero(fore, "fore")
        offsets = range(1, fore+1)
        return [series.shift(-x) - series for x in offsets]

    @staticmethod
    def gen_log_series(series):
        """
        Create a series by taking the log of each instance in the given series. 

        :param series: A 1-dimensional pandas series [x₀, x₁, ... xₙ]
        :return: A series the log values of the given series [log(x₀), log(x₁), ..., log(xₙ)]
        """
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        return np.log(series)

    @staticmethod
    def gen_scaled_series(series, scales):
        """
        Create a series by multiplying a given series by a corresponding series of scale values

        :param series: A 1-dimensional pandas series [x₀, x₁, ... xₙ]
        :param scales: A 1-dimensional pandas series [s₀, s₁, ... sₙ]
        :return: The pairwise product of the two series [x₀s₀, x₁s₁, ..., xₙsₙ]
        """
        verify.not_none(series, "series")
        verify.series_is_numeric(series, "series")
        return series.multiply(scales)

    @staticmethod
    def avg_across_series(series_collection):
        """
        Create a series by taking the average across the given set of series

        :param series_collection: A list of 1-dimensional pandas series 
            [[x1₀, x1₁, ... x1ₙ], [x2₀, x2₁, ... x2ₙ], ... [xK₀, xK₁, ... xKₙ]]
        :return: The elementwise avereage of the the series 
            [(x1₀ + x2₀ + .. + xK₀) / K, (x1₁ + x2₁ + .. + xK₁) / K,... ]
        """
        return pd.concat(series_collection, axis=1).mean(axis=1)

    @staticmethod
    def sum_across_series(series_collection):
        """
        Create a series by taking the average across the given set of series

        :param series_collection: A list of 1-dimensional pandas series 
            [[x1₀, x1₁, ... x1ₙ], [x2₀, x2₁, ... x2ₙ], ... [xK₀, xK₁, ... xKₙ]]
        :return: The elementwise sum of the the series [(x1₀ + x2₀ + .. + xK₀), (x1₁ + x2₁ + .. + xK₁),... ]
        """
        return pd.concat(series_collection, axis=1).sum(axis=1)

    @staticmethod
    def root_meansqr(series):
        verify.not_none(series, "series")
        return np.sqrt((series**2).mean())

    @staticmethod
    def get_nan_inf_indicator(series):
        return ~np.isfinite(series)

    @staticmethod
    def concat_along_rows(series, levels=None, name=None):
        """
        Create a dataframe combining all the given series

        :param series: List of series
        :param levels:
        :param name:
        :return: A single dataframe containing all the given columns
        """
        verify.not_none_or_empty(series, "series")
        verify.true(all([isinstance(x, pd.Series) for x in series]), "All inputs must be pands.Series")

        # If no new levels are specified, simply return the pandas implementation
        if levels is None:
            return pd.concat(series, axis=1)  

        verify.length_equals(levels, len(series), "levels")
        ret = pd.concat(series, axis=1)
        ret.columns = pd.MultiIndex.from_arrays([levels, [x.name for x in series]], names=[name, None])
        return ret
