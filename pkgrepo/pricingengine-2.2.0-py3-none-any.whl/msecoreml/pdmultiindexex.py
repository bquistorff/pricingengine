#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import math
import functools
import msecore.verify as verify
from sklearn import linear_model

class PdMultiIndexEx:
    '''
    A collection of utility methods for working with Pandas multi-indexes.
    '''

    @staticmethod
    def to_frame(midx, index=True):
        if hasattr(midx, 'to_frame'): #Included in 0.20
            return midx.to_frame() 
        else:
            result = pd.DataFrame({(name or level): midx.get_level_values(level)
                                   for name, level in
                                   zip(midx.names, range(len(midx.levels)))})
            if index:
                result.index = midx
            return result

    @staticmethod
    def get_levelvalues_by_name(multiindex, index_name):
        '''
        Return the list of level values for the index with the specified name

        :param multiindex: The multi-index containing the specified target index
        :param index_name: The name of the index for which to get the level values
        :returns: A list of level values for the index with the specified name

        +------+-------------------------+
        | site | 1   1   2   2   3   3   |
        +------+-------------------------+
        | item | A   B   A   B   A   B   |
        +------+-------------------------+
        |      | 1   2   10  20  100 200 |
        +------+-------------------------+
        |      | 3   4   30  40  300 400 |
        +------+-------------------------+ 

        index_name = site => [1, 2, 3]
        index_name = item => [A, B]
        '''
        verify.list_contains_value(multiindex.names, index_name, "multiindex.names")
        index_idx = multiindex.names.index(index_name)
        return multiindex.levels[index_idx]

    @staticmethod 
    def get_nlevel_singleton_indicator(multiindex, value_by_name):
        """Get an indicator array indicating the single position in the multiindex with the specified values

        :param multiindex: The multiindex for which to get an indicator
        :type multiindex: :class:`MultiIndex<pandas:pandas.MultiIndex>`
        :param value_by_name: A dictionary containg a mapping of index name to target value for each index in 
                    the multiindex
        :type value_by_name: dict(str, str or int)
        :returns: A boolean array corresponding to the values of the multiindex with a single True value
                    corresponding to the multiindex location with the specified values.
        :rtype: :class:`numpy.array<numpy:numpy.ndarray>` of bool

        For the following examples, let the mutliindex be the column index of the following dataframe
    
        +----+---+---+---+---+---+---+
        |site| 1 | 1 | 2 | 2 | 3 |Nan|
        +----+---+---+---+---+---+---+    
        |item| A | B | A | B | A | B |
        +====+===+===+===+===+===+===+
        |    | 1 | 2 | 10| 20|100|200|
        +----+---+---+---+---+---+---+    
        |    | 3 | 4 | 30| 40|300|400|
        +----+---+---+---+---+---+---+    

        :Example:

            Input:

                * value_by_name: {site:1, item:B}

            Output:

                [False, True, False, False, False, False]

        :Example:

            Input:

                * value_by_name: {site:Nan, item:B}

            Output:

                [False, False, False, False, False, True]

        """
        indicator = PdMultiIndexEx.get_nlevel_block_indicator(multiindex, value_by_name)
        verify.true(sum(indicator) == 1, "Incorrect number of columns found")
        return indicator

    @staticmethod 
    def get_nlevel_block_indicator(multiindex, index_value_byname):
        """Get an indicator array indicating the positions in the multiindex with the specified values

        :param multiindex: The multiindex for which to get an indicator
        :type multiindex: :class:`MultiIndex<pandas:pandas.MultiIndex>`
        :param index_value_byname: A dictionary containg a mapping of index name to target value for each
                                index in the multiindex.
        :type index_value_byname: dict(str, str or int)
        :returns: A boolean array corresponding to the values of the multiindex with a True values
                    corresponding to multiindex locations with the specified values.
        :rtype: :class:`numpy.array<numpy:numpy.ndarray>` of bool

        For the following examples, let the mutliindex be the column index of the following dataframe
    
        +----+---+---+---+---+---+---+
        |site| 1 | 1 | 2 |NaN| 3 |NaN|
        +----+---+---+---+---+---+---+    
        |item| A | B | A | B | A | B |
        +====+===+===+===+===+===+===+
        |    | 1 | 2 | 10| 20|100|200|
        +----+---+---+---+---+---+---+    
        |    | 3 | 4 | 30| 40|300|400|
        +----+---+---+---+---+---+---+    

        :Example:

            Input:

                * value_by_name: {site:1, item:B}

            Output:

                [False, True, False, False, False, False]

        :Example:

            Input:

                * value_by_name: {site:Nan, item:B}

            Output:

                [False, False, False, True, False, True]
        """
        verify.true(set(index_value_byname.keys()) == set(multiindex.names), "index_value_by_name")
        initial = [True] * multiindex.shape[0]
        index_indicators = [PdMultiIndexEx._get_indicator(multiindex, k, v) for k, v in index_value_byname.items()]
        indicator = functools.reduce(lambda x, y: x & y, index_indicators, initial)               
        return indicator

    #Probably should rename to same as get_some_nlevel_block_indicator 
    #  except for the set line has '<=' rather than '=='. Can we converge?
    @staticmethod 
    def get_some_levels_block_indicator(multiindex, index_value_byname):
        '''
        Get an indicator array indicating the positions in the multiindex with the specified values

        :param multiindex: The multiindex for which to get an indicator
        :param index_value_byname: A dictionary containg a mapping of index name to target value for 
            some (not nessecarily all) indices in the multiindex.
        :returns: A boolean array corresponding to the values of the multiindex with a True values
                  corresponding to multiindex locations with the specified values.

        +------+-------------------------+
        | site | 1   1   2   2   NaN Nan |
        +------+-------------------------+
        | item | A   B   A   B   A   B   |
        +------+-------------------------+
        |      | 1   2   10  20  100 200 |
        +------+-------------------------+
        |      | 3   4   30  40  300 400 |
        +------+-------------------------+

        {site:1, item:B} => [False, True, False, False, False, False]
        {site:Nan, item:B} => [False, False, False, False, True, True]
        '''
        verify.true(set(index_value_byname.keys()) <= set(multiindex.names), "index_value_by_name")
        initial = [True] * multiindex.shape[0]
        index_indicators = [PdMultiIndexEx.get_1level_block_indicator(multiindex, k, v) 
                            for k, v in index_value_byname.items()]
        indicator = functools.reduce(lambda x, y: x & y, index_indicators, initial)               
        return indicator


    @staticmethod
    def get_1level_block_indicator(multiindex, index_name, index_values):
        '''Get an indicator array indicating the positions in the multiindex with one of the specified values

        :param multiindex: The multiindex for which to get an indicator
        :type multiindex: :class:`MultiIndex<pandas:pandas.MultiIndex>`
        :param index_name: The name of the index for which to build an indicator for the specified values
        :type index_name: str
        :param index_values: A list of values for which the indicator should be True
        :type index_values: list(str or int)
        :returns: A boolean array corresponding to the values of the multiindex with a True values
                    corresponding to multiindex locations with the specified values.
        :rtype: :class:`numpy.array<numpy:numpy.ndarray>` of bool

        For the following examples, let the mutliindex be the column index of the following dataframe
    
        +----+---+---+---+---+---+---+
        |site| 1 | 1 | 2 | 2 | 3 |Nan|
        +----+---+---+---+---+---+---+    
        |item| A | B | A | B | A | B |
        +====+===+===+===+===+===+===+
        |    | 1 | 2 | 10| 20|100|200|
        +----+---+---+---+---+---+---+    
        |    | 3 | 4 | 30| 40|300|400|
        +----+---+---+---+---+---+---+    

        :Example:
        
            Input:

                * index_name: site
                * index_values: [1, 2]
            
            Output:

                [True, True, True, True, False, False]

        :Example:
    
            Input:

                * index_name: site
                * index_values: [NaN]
           
            Output:
                [False, False, False, False, True, True]
        '''
        # No constraint -> select all
        if not isinstance(index_values, list) and not isinstance(index_values, set):
            index_values = [index_values]

        if len(index_values) == 0:
            return np.array([True] * multiindex.shape[0])

        indicators = [PdMultiIndexEx._get_indicator(multiindex, index_name, x) for x in index_values]
        indicator = functools.reduce(lambda x, y: x | y, indicators)
        return indicator

    @staticmethod
    def get_aligned_index(source_index, target_index_names):

        # Determine the indexes that are missing
        existing_names = source_index.names
        missing_names = [x for x in target_index_names if not x in existing_names]

        # Create values for the missing indexes
        missing_levels = tuple([None] * len(missing_names))
        existing_levels = source_index.get_values()
        levels = [x + missing_levels for x in existing_levels]
        names = existing_names + missing_names
        aligned_index = pd.MultiIndex.from_tuples(levels, names=names).reorder_levels(target_index_names)
        return aligned_index

    @staticmethod
    def align_index(multiindex, index_names):
        '''Align given multiindex to specified index
    
        Get an updated version of the given multinindex with indexes ordered as specified by the set of index
        names where indexes not yet contained in the multiindex are added but have all missing values and names 
        in the multiindex but not in index_names are dropped

        :param multiindex: The multinindex to update
        :type multiindex: :class:`MultiIndex<pandas:pandas.MultiIndex>`
        :param index_names: An ordered list of index names for the new index
        :type index_names: list(str)
        :returns: An updated version of the given multiindex with indexes ordered as specified by the set of index
                    names where indexes not yet contained in the multiindex are added but have all missing values. 
        :rtype: :class:`MultiIndex<pandas:pandas.MultiIndex>`
                     

        For the following examples, let mutliindex be the following column multiindex 

        +-------+---+---+---+---+---+---+
        |letter | A | B | A | B | A | A |
        +-------+---+---+---+---+---+---+
        |number | 1 | 1 | 1 | 2 | 2 | 2 |
        +-------+---+---+---+---+---+---+
        |blah   | 0 | 0 | A | A | C | C |
        +-------+---+---+---+---+---+---+
                                                               
        :Example:

            Input:
            
                * index_names: [number, missing, blah, letter]
        
            Output: 

                +-------+----+----+----+----+----+----+
                |number | 1  | 1  | 1  | 2  | 2  | 2  |
                +-------+----+----+----+----+----+----+
                |missing|None|None|None|None|None|None|
                +-------+----+----+----+----+----+----+
                |letter | A  | B  | A  | B  | A  | A  |            
                +-------+----+----+----+----+----+----+
                |blah   | 0  | 0  | A  | A  | C  | C  |
                +-------+----+----+----+----+----+----+

        :Example:

            Input:
            
                * index_names: [number, missing]

            Output: 

                +-------+----+----+----+----+----+----+
                |number | 1  | 1  | 1  | 2  | 2  | 2  |
                +-------+----+----+----+----+----+----+
                |missing|None|None|None|None|None|None|
                +-------+----+----+----+----+----+----+
        '''

        # Get the names of the required indexes that are already defined in the index
        # Get the values of each such index
        existing_names = [x for x in index_names if x in multiindex.names]
        existing_levels = [multiindex.get_level_values(x) for x in existing_names]

        # Get the names of the required indexes that need to be added to the column index
        # Get the padding values for each such index
        num_cols = len(multiindex)
        missing_names = [x for x in index_names if not x in multiindex.names]
        missing_levels = [[None] * num_cols for x in missing_names]

        names = existing_names + missing_names
        levels = existing_levels + missing_levels
        columns = pd.MultiIndex.from_arrays(levels, names=names)

        if isinstance(columns, pd.MultiIndex):
            columns = columns.reorder_levels(index_names)
        return columns

    @staticmethod
    def _get_indicator(multiindex, index_name, value):
        # NOTE: index_name may be None, but value may not be (although it can be NaN)
        verify.not_none(value, "value")
        verify.list_contains_value(multiindex.names, index_name, "multiindex.names")
        if pd.isnull(value):
            return pd.isnull(multiindex.get_level_values(index_name))
        else:
            return multiindex.get_level_values(index_name) == value

    @staticmethod
    def fillna_multiindex(idx, value='', level_nums=None):
        '''
        Indexes sometimes a level l in a multi-index will have has nan's stored as -1 in the .labels[l] 
        for something not in .levels[l] ::

            .get_level_values(l) #will return things with math.nan
            .fillna()/.hasnans #aren't implemented
            df.index.set_levels([l.fillna(value) for l in df.index.levels], inplace=True) #Doesn't work
            index.get_level_values(l).fillna('') #returns some right
            df.index.set_levels([df.index.get_level_values(l).fillna('') for l in range(len(df.index.levels))], 
                                inplace=True) #Doesn't work
        '''
        if not isinstance(idx, pd.MultiIndex):
            return

        if level_nums is None:
            level_nums = range(idx.nlevels)
        for level_num in level_nums:
            lbls = idx.labels[level_num].values()
            if np.any(lbls == -1):
                orig_level_level_n = len(idx.levels[level_num].values)
                #Add the value as the next level
                idx.set_levels(list(idx.levels[level_num].values) + [value], level=level_num, inplace=True)
        
                np.place(lbls, lbls == -1, orig_level_level_n)
                idx.set_labels(lbls, level=level_num, inplace=True)
                
    
    @staticmethod
    def rename_mi_level_names(idx, level, dict_map):
        if isinstance(level, str):
            level = idx.names.index(level)
        lvl_names = idx.levels[level].values
        for key in dict_map:
            np.place(lvl_names, lvl_names == key, dict_map[key])
        idx.set_levels(lvl_names, level=level, inplace=True)

    @staticmethod
    def concat_index_levels(midx, sep='_', filter_blanks=True, name=None):
        '''
        Takes all the levels of a multiindex, turns to string and then concatenates into plain Index.
        :param midx:
        :param str sep: Separator
        :param filter_blanks: Do we only put sep between non-blank entries?
        :param name: final name for Index
        '''
        if not isinstance(midx, pd.MultiIndex):
            return midx #just a single-level index
        df = PdMultiIndexEx.to_frame(midx).reset_index(drop=True).astype(np.str).replace({'nan':''}) #Turn to df
        if filter_blanks:
            ser = df.apply(lambda x: sep.join(filter(None, x)), axis=1) #pylint: disable=bad-builtin
        else:
            ser = df.apply(lambda x: sep.join(), axis=1)
        idx = pd.Index(ser)
        if name is not None:
            idx.name = name
        return idx

    @staticmethod
    def midx_from_list_of_namedarray(na_list):
        '''
        Create a MultiIndex from a list of Index's or pd.Series's

        :param na_list: list of Index's, or pd.Series (needs .values and .name) for each
        '''
        arrays = [idx.values for idx in na_list]
        names = [idx.name for idx in na_list]
        return pd.MultiIndex.from_arrays(arrays=arrays, names=names)
