#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import abc
import os
import datetime
import time
import collections
from . import verify

def is_empty(value):
    return len(value) == 0

def is_none_or_empty(value):
    """True if the value is None or Empty"""
    return value is None or len(value) == 0

def is_list(value):
    return isinstance(value, list)

#
#
# Tools for logging analysis environments.
#
#
class InputInfo:
    '''
    This is used for storing info on non-versioned files.
    This can be outputed with the code checksum so that together we can perfectly identify the analysis
    '''
    def __init__(self, input_id, content_id, other):
        '''
        :param input_id: name of this resource
        :param content_id: something that uniquely identifies which version of the content it is (e.g. checksum)
        :param other: Other input that might helpful like a path, modification timestamp, and/or description.
        '''
        self.input_id = input_id
        self.content_id = content_id
        self.other = other

def input_info_from_path(path):
    '''
    This assumes the basename of a file is unique!
    '''
    import hashlib
    return InputInfo(input_id=os.path.basename(path), 
                     content_id=hashlib.md5(open(path, 'rb').read()).hexdigest(), 
                     other={"path":path, "mtime":os.path.getmtime(path)})

class AnalysisInfo:
    '''
    Hold all info that identifies an analysis
    '''
    def __init__(self, environment, code, inputs=None):
        '''
        :param environment: description of the environment, e.g., Processor, OS, runtime (e.g. python and packages)
        :param code: description of the current analysis code
        :param inputs: a list of InputInfos
        '''
        self.environment = environment
        self.code = code
        self.inputs = [] if inputs is None else inputs

#uname =system, node, release, version, machine, and processor
EnvInfo = collections.namedtuple('EnvInfo', ['uname', 'python_version', 'pip_info', 'win32_ver'])
def environment_info():
    import pip
    import sys
    pip_info = {pkg.key : pkg.version for pkg in pip.get_installed_distributions()
                if pkg.key in set(sys.modules) & set(globals())} #only the imported packages
    import platform
    win32_ver_info = platform.win32_ver if platform.system() == 'Windows' else None
    info = EnvInfo(platform.uname, platform.python_version, pip_info, win32_ver_info)

    return info

GitWDInfo = collections.namedtuple('GitWDInfo', ['head_name', 'head_id', 'head_short_id'])
def git_info(repo_path=None):
    import pygit2

    if not repo_path:
        repo_path = pygit2.discover_repository(os.getcwd())
    
    repo = pygit2.Repository(repo_path)
    return GitWDInfo(repo.head.shorthand, repo.head.target.hex, repo.head.target.hex[:8])

#
#
# Common types
#
#

class INamed(metaclass=abc.ABCMeta):
    """Objects with names"""
    @property
    @abc.abstractmethod
    def name(self):
        pass

class SrcDestTuple:
    __slots__ = ('src', 'dest')

    def __init__(self, src, dest):
        self.src = src
        self.dest = dest

class ValueRange(verify.IValidatable):
    __slots__ = ('minval', 'maxval', 'min_inclusive', 'max_inclusive')
    """
        ValueRange defined by min, max
    """
    def __init__(self, minval, maxval, min_inclusive=False, max_inclusive=False):
        self.minval = minval
        self.maxval = maxval
        self.min_inclusive = min_inclusive
        self.max_inclusive = max_inclusive
    
    def validate(self):
        verify.not_none(self.minval, "minval")
        verify.not_none(self.maxval, "maxval")
        verify.lessthanequals(self.minval, self.maxval, "min")

    def inrange(self, value):
        if self.min_inclusive:
            if value < self.minval:
                return False
        else:
            if value <= self.minval:
                return False
        if self.max_inclusive:
            if value > self.maxval:
                return False
        else:
            if value >= self.maxval:
                return False        
        return True

    def __str__(self):
        return "{0} : {1}".format(self.minval, self.maxval)

    def __hash__(self):
        return hash((self.minval, self.maxval, self.min_inclusive, self.max_inclusive))
    
    def __eq__(self, other):
        return self.minval == other.minval and \
               self.maxval == other.maxval and \
               self.min_inclusive == other.min_inclusive and \
               self.max_inclusive == other.max_inclusive
#
#
# Descriptors
#
#
class Lazy:
    def __init__(self, func):
        self._func = func
        self._value = None

    def __call__(self):
        return self.value

    @property
    def value(self):
        if self._value is None:
            self._value = self._func()
        return self._value
#
#
# EXCEPTIONS
#
#
class AppException(Exception):
    def __init__(self, errorcode, message):
        super().__init__(message, errorcode)
        self.errorcode = errorcode

class NotSupportedException(Exception):
    def __init__(self, message):
        super().__init__(message)

class InvalidOperationException(Exception):
    def __init__(self, message):
        super().__init__(message)

#
#
# EVENTING
#
#
class Observable:
    """
        Class for managing multiple subscribers to a pub-sub event
        Supports:
        - foo.on_change += handler
        - foo.on_change -= handler
    """
    def __init__(self):
        self._observers = None

    def subscribe(self, func):
        if self._observers is None:
            self._observers = []
        self._observers.append(func)
        return self

    def unsubscribe(self, func):
        if self._observers:
            self._observers.remove(func)
                                                                                       
    def notify(self, *args):
        for func in self._observers:
            func(*args) 

    def safenotify(self, *args):
        try:
            self.notify(*args)
        except:
            pass
    # +=
    def __iadd__(self, func):
        self.subscribe(func)
    # -=
    def __isub__(self, func):
        self.unsubscribe(func)

#
#
# INVOCATIONS
#
#

def transform(func, arg):
    """
        :param func:
        :param callable arg:
            Signature (object) --> object
    """
    if func:
        return func(arg)
    return arg

def safe_call(func, *args):
    """Call the func, eat all exceptions"""
    if func:
        try:
            func(*args)
        except:
            pass

class OperationPolicy(verify.IValidatable):
    __slots__ = ('timeoutseconds', 'maxattempts', 'retrypause', 'exceptionfilter')

    def __init__(self, maxattempts=3, retrypause=0, exceptionfilter=None):
        self.timeoutseconds = 0
        """Timeout the operation after these many secconds"""
        self.maxattempts = maxattempts
        """Number of times to retry this operation in case of failure."""
        self.retrypause = retrypause
        """How many seconds to pause for in between retries"""
        self.exceptionfilter = exceptionfilter
        """lambda exception: true or false. Return false to stop execution"""

    def validate(self):
        verify.greaterthanzero(self.maxattempts, "maxattempts")

    def execute(self, func, *args):
        """execute the given func with this policy."""
        verify.not_none(func, "func")

        for i in range(0, self.maxattempts):
            try:
                return func(*args)
            except Exception as ex:
                self.__handleexception(i + 1, ex)

            self.__pause()

    def __handleexception(self, attemptnumber, ex):
        if attemptnumber == self.maxattempts:
            raise ex

        if self.exceptionfilter and self.exceptionfilter(ex):
            raise ex

    def __pause(self):
        if self.retrypause > 0:
            time.sleep(self.retrypause)

class Stopwatch:
    """
        Stopwatch for timing.
    """
    def __init__(self, processtime=True):
        self.__processtime = processtime
        self.__starttime = None
        self.__elapsed = 0

    @property
    def elapsed_seconds(self):
        return self.__elapsed

    def start(self):
        if not self.__starttime:
            self.__starttime = self.__timestamp()

    def stop(self):
        stoptime = self.__timestamp()
        if self.__starttime:
            self.__elapsed += (stoptime - self.__starttime)
            if self.__elapsed < 0:
                self.__elapsed = 0
    
    def reset(self):
        self.__starttime = None
        self.__elapsed = 0

    def restart(self):
        self.reset()
        self.start()

    def __timestamp(self):
        if self.__processtime:
            return time.process_time()
        else:
            return time.perf_counter()
