#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import os
import urllib.request
import urllib.parse
import contextlib
from . import system
from . import verify
from . import filesystem
from . import path

class UriParts:    
    """A class to hold, access and manipulate the parts of a Url"""
 
    def __init__(self, url):
        verify.not_none(url, "url")
        self.scheme, self.host, self._path, self.params, self.query, self.fragment = urllib.parse.urlparse(url)
        self._segments = None
    
    @property
    def path(self):
        return self._path
    @path.setter
    def path(self, value):
        self._path = value
        self._segments = None

    @property
    def segments(self):
        if self._segments is None:
            fullpath = urllib.parse.unquote(self.path)
            if len(self.path) == 0:
                self._segments = []
            else:
                self._segments = fullpath.split('/')        
        return self._segments

    @property
    def filename(self):
        segs = self.segments
        return segs[-1] if (len(segs) > 0) else None

class HttpHeaders:
    """
        An accessor class for Http Headers returned by url.reponse
    """
    CONTENT_LENGTH = "Content-Length"
    CONTENT_TYPE = "Content-Type"
    IF_MODIFIED_SINCE = "if-modified-since"
    
    def __init__(self, headers): 
        verify.not_none(headers, "headers")
        self.headers = headers

    def contentlength(self):
        header = self.headers.get(HttpHeaders.CONTENT_LENGTH)
        return -1 if (header is None) else int(header)

class WebResource(verify.IValidatable):
    """
        A WebResource has a location url AND a name
    """
    __slots__ = ('url', 'name')
    def __init__(self, url=None, name=None):
        """
            :param str url:
                Source url for the data
            :param str canonicalname:
        """
        self.url = url
        self.name = name

    def validate(self):
        verify.validate_required(self.url, "url")
        verify.validate_required(self.name, "name")

    def __str__(self):
        return "[{0}] {1}".format(self.name, self.url)

class WebClient(verify.IValidatable):
    """
        The WebClient includes policy for retries and robustness.
        Currently wraps python core libraries. 
        We will also add support for checkpoints and the resumption of interrupted downloads
    """
    def __init__(self, policy=None):
        if policy is None: 
            policy = system.OperationPolicy()
        self.policy = policy

    def validate(self):
        verify.not_none_or_empty(self.policy, "policy")

    def download_to_path(self, url, destpath):
        verify.not_none_or_empty(url, "url")
        verify.not_none_or_empty(destpath, "destfilepath")

        self.policy.execute(lambda: self.__download(url, destpath))
    
    def download_stream(self, url, streamhandler):
        """
            :param url: URL
            :param streamhandler:
                Function Signature: (HttpHeaders, stream)
        """
        verify.not_none_or_empty(url, "url")
        verify.not_none(streamhandler, "streamhandler")

        self.policy.execute(lambda: self.__download_stream(url, streamhandler))

    def __download(self, url, destpath):
        destfilepath = self.__preparepath(url, destpath)
        return urllib.request.urlretrieve(url, destfilepath)[0]

    def __download_stream(self, url, streamhandler):
        with contextlib.closing(urllib.request.urlopen(url)) as response:
            headers = HttpHeaders(response.info())
            streamhandler(headers, response)

    def __preparepath(self, url, destfilepath):
        filesystem.ensuredir(os.path.dirname(destfilepath))
        if os.path.isdir(destfilepath) or system.is_empty(path.ext(destfilepath)):
            filename = filesystem.legalize_filename(UriParts(url).filename)
            destfilepath = os.path.join(destfilepath, filename)

        return destfilepath


def download_url_to_path(url, destfilepath):
    """
        Download a url with automatic retries
    """
    return WebClient().download_to_path(url, destfilepath)

def url_encode(value):
    """
        Url encode a string. This wrapper has a more readable name than the base Python lib
    """
    return urllib.parse.quote_plus(value)
