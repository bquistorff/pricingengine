#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import sys
import io
import csv
from . import (
    verify,
    stringex,
    system
)

def blobstream(buffer=None):
    """
    Create a new BytesIO stream and write the given bytes to it

    :param bytes buffer: The dataset for which to compute features
    :rtype: io.BytesIO
    """
    stream = io.BytesIO()
    if buffer:
        stream.write(buffer)
        stream.seek(0)
    return stream

def strstream(strbuffer=None):
    """
    Create a new StringIO stream and write the given string to it

    :param str strbuffer:
    :rtype: io.TextIOBase
    """
    stream = io.StringIO()
    if strbuffer:
        stream.write(strbuffer)
        stream.seek(0)
    return stream

def flush_and_reset(stream):
    """
        Flush the current stream and reset its position to the beginning
        of the stream
    """
    verify.not_none(stream, "stream")
    stream.flush()
    stream.seek(0)

def write_strstream(writerfunc):
    """
        Write to the given string stream

        :param writerfunc:
            Signature: (TextIOStream)
        :return: written text        
    """
    verify.not_none(writerfunc, "writerfunc")
    stream = io.StringIO()
    writerfunc(stream)
    stream.flush()
    stream.seek(0)
    return stream.read(-1)

def write_strcsv(writerfunc):
    """
        :param writerfunc:
            Write rows to the given csv writer
            Signature: (csv.writer)
        :return: written text        
    """
    verify.not_none(writerfunc, "writerfunc")
    return write_strstream(lambda stream: writerfunc(csv.writer(stream, dialect=csv.excel)))

def readlines(textstream):
    """
        A generator that yields lines from the given text stream. 
    """
    verify.not_none(textstream, "textstream")
    while True:
        line = textstream.readline()
        if len(line) == 0:
            break
        yield line

def writeline(textstream, text):
    """
        Write a line to the given stream
    """
    if text is not None:
        textstream.write(text)
    textstream.write('\n')

def copy_stream(src, dest, progress_callback=None, chunksize=1024*64):
    """
        :param src: readable stream.
        :type src: io.RawIOBase
        :param dest: writable stream.
        :type dest: io.RawIOBase
        :param progress_callback:
            Signature: (bytecount)
        :param chunksize: Default is 1024*64
    """
    if not src.readable():
        raise ValueError("srcStream")
    if not dest.writable():
        raise ValueError("destStream")

    buffer = bytearray(chunksize)
    totalcount = 0
    while True:
        countread = src.readinto(buffer)
        if not countread:
            break
        if countread < chunksize:
            del buffer[countread : chunksize]
        dest.write(buffer)
        totalcount += countread
        if progress_callback:
            progress_callback(totalcount)

def ensure_textstream(stream):
    """
        If the given stream is not a text stream, wraps it with a TextIOWrapper
    """
    verify.not_none(stream, "stream")
    if not isinstance(stream, io.TextIOBase):
        stream = io.TextIOWrapper(stream)
    return stream

def make_progress_message(total_byte_count, count_processed):
    """
        Makes a readable message string that indicates what % of the total_byte_count
        was processed. Large #s are automatically reduced to MB, GB, etc. 
    """
    str_totalbytes = stringex.bytecount_to_string(count_processed)
    if total_byte_count > 0: 
        percent = count_processed / total_byte_count
        str_length = stringex.bytecount_to_string(total_byte_count)
        msg = "[{0}], {1} ({2:.2%})".format(str_length, str_totalbytes, percent)
    else:
        msg = str_totalbytes
    return msg

#-----------------------
#
# STDIO functions
#
#------------------------
def stdin_readlines(func_preprocess):
    """
        A generator that yields lines read from the command line. 
            Automatically ignores empty lines

        :param lambda func_preprocess: Signature (str)=>string
            Function that can preprocess a line. If this returns null, iteration
            will stop
    """
    while True:
        line = sys.stdin.readline()
        if system.is_none_or_empty(line):
            continue
        if func_preprocess:
            line = func_preprocess(line)
        if line is None:
            break
        yield line

class InplacePrint:
    """
        Use this class to update stdio lines INPLACE.
        E.g. to inplace update # of bytes copied so far
    """
    def __init__(self):
        self.__prev = ""

    def print(self, msg):
        prevlen = len(self.__prev)
        if prevlen > len(msg):
            self.__reprint(" " * prevlen)
        self.__reprint(msg)
        self.__prev = msg

    def print_count(self, count, freq=None):
        if freq and count % freq != 0:
            return

        self.print(str(count))

    def print_count_progress(self, total, count_processed):
        if total > 0: 
            msg = "[{0}], {1} ({2:.2%})".format(total, count_processed, count_processed / total)
        else:
            msg = str(count_processed)
        self.print(msg)

    def print_bytecount(self, count):
        self.print(stringex.bytecount_to_string(count))
    
    def print_bytecount_progress(self, total_byte_count, count_processed):
        self.print(make_progress_message(total_byte_count, count_processed))

    def __reprint(self, msg):
        sys.stdout.write('\r' + msg)
        sys.stdout.flush()
