#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# Unit Testing Utilities
#
#------------------------------------------------------------------------
import unittest
import unittest.runner
import sys
import os

def test_begin(modulename):
    """
        All tests call this method for some basic setup
    """
    if modulename == '__main__':
        unittest.main()

def arg_exists(argname):
    argname = "Test_" + argname
    return os.environ.get(argname) is not None

def skipif_noarg(argname):
    """
        Sometimes we want to skip a unit test. 
        E.g. you may not want to run Sql tests if no Sql Server is available. 

    """
    argexists = arg_exists(argname)
    if argexists:
        # Yes, this is slow
        for arg in sys.argv:
            if arg == argname:
                argexists = True
                break

    return unittest.skipIf(not argexists, "No " + argname)
