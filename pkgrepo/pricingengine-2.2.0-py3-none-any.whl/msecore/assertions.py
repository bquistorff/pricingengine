#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# Unit Testing Utilities
#
#------------------------------------------------------------------------
from pandas.util.testing import assert_series_equal

def series_values_equal(ser_a, ser_b):
    '''
    Disregards indexes and names when checking if values of series are equal.
    '''
    assert_series_equal(ser_a.reset_index(drop=True), ser_b.reset_index(drop=True), check_names=False)
