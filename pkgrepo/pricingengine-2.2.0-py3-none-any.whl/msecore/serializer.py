#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import abc
import enum
import pickle
import json
import io
from msecore import (
    verify,
    system,
    stream,
    stringex,
    path
)

def dump_pickle(obj, filepath):
    with open(filepath, "wb") as file:
        pickle.dump(obj, file)

def load_pickle(filepath):
    with open(filepath, "rb") as file:
        return pickle.load(file)

class Format:
    Pickle = 0
    Json = 1
    Infer = 2

    @staticmethod
    def isformat(mode, modename):
        return mode == modename

    @staticmethod
    def infer(filepath):
        """
        Return inferred the format from the filepath
        """
        ext = path.ext(filepath)
        if len(ext) > 0:
            ext = ext.casefold()
            if ext == ".txt" or ext == ".json":
                return Format.Json
            if ext == ".pickle":
                return Format.Pickle
        raise system.NotSupportedException(filepath)

def serialize_to_stream(iterable, outputstream, mode=Format.Json):
    """
        Serialize objects to a stream
    """
    if Format.isformat(mode, Format.Json):
        outputstream = stream.ensure_textstream(outputstream)
        json_dump_to_stream(iterable, outputstream)
    elif Format.isformat(mode, Format.Pickle):
        verify.istype(outputstream, io.RawIOBase)
        pickle_to_stream(iterable, outputstream)
    else:
        raise system.NotSupportedException(mode)

def serialize_to_file(iterable, filepath, mode=Format.Json):
    """
        Serialize objects to a filepath
    """
    if Format.isformat(mode, Format.Infer):
        mode = Format.infer(filepath)

    if Format.isformat(mode, Format.Json):
        json_dump_to_file(iterable, filepath)
    elif Format.isformat(mode, Format.Pickle):
        pickle_to_file(iterable, filepath)
    else:
        raise system.NotSupportedException(mode)

def deserialize_stream(inputstream, mode=Format.Json):
    """
        Return deserialize objects from a stream
    """
    if Format.isformat(mode, Format.Json):
        inputstream = stream.ensure_textstream(inputstream)
        return json_load_stream(inputstream)
    elif Format.isformat(mode, Format.Pickle):
        verify.istype(inputstream, io.RawIOBase)
        return unpickle_stream(inputstream)
    else:
        raise system.NotSupportedException(mode)

def deserialize_stream_from_file(filepath, mode=Format.Json):
    """
        Return deserialize objects from a file
    """
    if Format.isformat(mode, Format.Infer):
        mode = Format.infer(filepath)

    if Format.isformat(mode, Format.Json):
        return json_load_stream_from_file(filepath)
    elif Format.isformat(mode, Format.Pickle):
        return unpickle_stream_from_file(filepath)
    else:
        raise system.NotSupportedException(mode)

def pickle_to_stream(iterable, binarystream):
    """
        Given an iterable, pickle each item to the given stream
    """
    verify.iterable(iterable)
    verify.not_none(binarystream, "binarystream")
    for item in iterable:
        pickle.dump(item, binarystream)

def pickle_to_file(iterable, filepath):
    """
        Given an iterable, pickle each item to the given stream
    """
    verify.iterable(iterable)
    verify.not_none_or_empty(filepath, "filepath")
    with open(filepath, "wb") as file:
        pickle_to_stream(iterable, file)

def unpickle_stream(binarystream):
    """
        Given a stream of pickled objects, return a generator of unpickled objects
        :yields: objects
    """
    verify.not_none(binarystream, "binarystream")
    while True:
        try:
            yield pickle.load(binarystream)
        except EOFError:
            break

def unpickle_stream_from_file(filepath):
    """
        Given a stream of pickled objects, return a generator of unpickled objects
        :yields: objects
    """
    verify.not_none_or_empty(filepath, "filepath")
    with open(filepath, "rb") as file: 
        yield from unpickle_stream(file)

def json_dump_to_stream(iterable, textstream):
    """
        Given an iterable, json each item as a line to the given text stream
    """
    verify.iterable(iterable)
    verify.not_none(textstream, "textstream")
    for item in iterable:
        stream.writeline(textstream, json.dumps(item))

def json_dump_to_file(iterable, filepath):
    """
        Given an iterable, json each item to the given file
    """
    verify.iterable(iterable)
    verify.not_none_or_empty(filepath, "filepath")
    with open(filepath, "w") as file:
        json_dump_to_stream(iterable, file)

def json_load_stream(textstream, objhook=None):
    """
        Given a text stream of json lines , returns the contained json objects
        :yields: json objects
    """
    verify.not_none(textstream, "stream")
    for line in stream.readlines(textstream):
        yield json.loads(line, object_hook=objhook)

def json_load_stream_from_file(filepath, objhook=None):
    """
        Given a text file, returns the contained json objects
        :yields: json objects
    """
    verify.not_none_or_empty(filepath, "filepath")
    with open(filepath, "r") as file: 
        yield from json_load_stream(file, objhook)

class TextSerializable(metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def deserialize_text(self, textstream):
        pass

    @abc.abstractmethod
    def serialize_text(self, textstream):
        pass

    def _writeline(self, textstream, text):
        stream.writeline(textstream, text)

    def _readline(self, textstream):
        line = textstream.readline()
        if line and len(line) > 1:
            return line[:-1]
        return None
