#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
#from collections import Counter
import collections
from collections import Sequence
from inspect import Signature, Parameter

#https://codereview.stackexchange.com/questions/173045/mutable-named-tuple-or-slotted-data-structure
#Alternatively could use the package 'recordclass'
#class MutableNamedTuple(Sequence): 
#    """Abstract Base Class for objects as efficient as mutable
#    namedtuples.
#    Subclass and define your named fields with __slots__.
#    """

#    @classmethod
#    def get_signature(cls):
#        parameters = [
#            Parameter(name=slot, kind=Parameter.POSITIONAL_OR_KEYWORD) for slot in cls.__slots__
#        ]
#        return Signature(parameters=parameters)

#    def __init_subclass__(cls, **kwargs):
#        super().__init_subclass__(**kwargs)
#        slots = cls.__slots__
#        cls.__slots__ = tuple(slots.split()) if isinstance(slots, str) else tuple(slots)
#        cls.__signature__ = cls.get_signature()
#        cls.__init__.__signature__ = cls.get_signature()
#        cls.__doc__ = '{cls.__name__}{cls.__signature__}\n\n{cls.__doc__}'.format(
#            cls=cls)

#    def __new__(cls, *args, **kwargs):
#        if cls is MutableNamedTuple:
#            raise TypeError("Can't instantiate abstract class MutableNamedTuple")
#        return super().__new__(cls)

#    @classmethod
#    def _get_bound_args(cls, args, kwargs):
#        return Signature.bind(cls.__signature__, *args, **kwargs).arguments.items()

#    __slots__ = ()

#    def __init__(self, *args, **kwargs):
#        bound_args = self._get_bound_args(args, kwargs)
#        for slot, value in bound_args:
#            setattr(self, slot, value)

#    def __repr__(self):
#        return type(self).__name__ + repr(tuple(self))

#    def __iter__(self): 
#        for name in self.__slots__:
#            yield getattr(self, name)

#    def __getitem__(self, index):
#        return getattr(self, self.__slots__[index])

#    def __len__(self):
#        return len(self.__slots__)

#https://stackoverflow.com/questions/11351032/namedtuple-and-optional-keyword-arguments
#Note that this (like namedtupel) is still immutable
def namedtuple_with_defaults(typename, field_names, default_values=()):
    my_tuple = collections.namedtuple(typename, field_names)
    my_tuple.__new__.__defaults__ = (None,) * len(my_tuple._fields)
    if isinstance(default_values, collections.Mapping):
        prototype = my_tuple(**default_values)
    else:
        prototype = my_tuple(*default_values)
    my_tuple.__new__.__defaults__ = tuple(prototype)
    return my_tuple

def get_non_unique(list_in):
    """
    Return the list of values from the given list that are not unique, or an empty list if there are no such values

    :param list_in: The list in which to find non-unique values
    :return: A list of values that are not unique
    """
    ret = [key for key, value in collections.Counter(list_in).items() if value > 1]
    return ret

def kv_enumerate(obj):
    '''
    Do a k,v for-loop over arrays and dictionaries in the same way
    '''
    return obj.items() if isinstance(obj, dict) else enumerate(obj)
