#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# Validation functions
#
#------------------------------------------------------------------------
import abc
import errno
import os
import numpy as np
import pandas as pd
from . import (
    listex
)

class Messages:
    BAD_MODEL_STATE_MESSAGE = "Model not yet fit"
    SCHEMA_MISMATCH_MESSAGE = "Schema of the given dataset does not match the expected schema"


class IValidatable(metaclass=abc.ABCMeta):
    """Typically objects with data driven or user supplied settings, implment this"""
   
    @abc.abstractmethod
    def validate(self):
        pass

def type_is_numeric(dtype, message):
    if not (np.issubdtype(dtype, np.float) or 
            np.issubdtype(dtype, np.int) or 
            np.issubdtype(dtype, np.uint8) or 
            np.issubdtype(dtype, np.uint16) or 
            np.issubdtype(dtype, np.uint32) or 
            np.issubdtype(dtype, np.uint64)):
        raise ValueError('{0} must be of type int or float'.format(message))

def nptype_is_one_of(dtype, given_types, message=None):
    message = "Value" if not message else message
    if not any([np.issubdtype(dtype, x) for x in given_types]):
        join_list = [str(x) for x in given_types]
        raise ValueError('{0} must be one of the following types: {1}'.format(message, ", ".join(join_list)))

def not_none(value, message):
    if value is None:
        raise ValueError('{0}. Value is Null'.format(message))
    
def not_nan_inf(value, message):
    if np.isnan(value) or np.isinf(value):
        raise ValueError('{0}. Value is NaN or Inf'.format(message))

def not_none_or_empty(value, message): 
    if value is None or len(value) == 0:
        raise ValueError('{0}. Value is none or empty'.format(message))

def true(value, message):
    if not value:
        raise ValueError(message)

def false(value, message):
    if value:
        raise ValueError(message)

def not_longerthan(value, maxlen, message):
    if len(value) > maxlen:
        raise ValueError('{0}. Length must be < {1}'.format(message, maxlen))

def equals(val1, val2, message):
    if val1 != val2:
        raise ValueError("{}. {} must be equal to {}".format(message, val1, val2))

def greaterthanzero(value, message):
    if value <= 0:
        raise ValueError('{0}. Value must be > 0'.format(message))

def greaterthanone(value, message):
    if value <= 1:
        raise ValueError('{0}. Value must be > 0'.format(message))

def lessthan(value, minval, message):
    if value >= minval:
        raise ValueError('{0}. Value must be < {1}'.format(message, minval))

def lessthanequals(value, minval, message):
    if value > minval:
        raise ValueError('{0}. Value must be <= {1}'.format(message, minval))

def greaterthan(value, maxval, message):
    if value <= maxval:
        raise ValueError('{0}. Value must be > {1}'.format(message, maxval))

def greaterthanequals(value, maxval, message):
    if value < maxval:
        raise ValueError('{0}. Value must be >= {1}'.format(message, maxval))

def inrange(value, minval, maxval, message):
    if value < minval or value > maxval:
        raise ValueError('{0}. Value must be in range: {1}:{2}'.format(message, minval, maxval))

def iterable(value):
    not_none(value, "iterable")

def istype(value, valuetype):
    '''
    :param value:
    :param valuetype: can be a tuple
    '''
    # Value can be of specified type or one of its subclasse
    if not isinstance(value, valuetype):
        raise ValueError('Value must be of type {0}'.format(valuetype))

def is_list_oftype(value, valuetype):
    istype(value, list)
    if any([not isinstance(x, valuetype) for x in value]):
        raise ValueError('All list elements must be of type {0}'.format(valuetype))

def series_is_numeric(series, message):
    type_is_numeric(series.dtype, message)

def dataframe_is_numeric(dataframe, message):
    for column in dataframe:
        series_is_numeric(dataframe[column], message + "(column {0})".format(column))

def dataframe_contains_col(dataframe, column_name, message):
    if not column_name in dataframe:
        raise ValueError('Dataframe {0} does not contain column {1}'.format(message, column_name))

def dataframe_contains_index(dataframe, index_name, message):
    if not index_name in dataframe.index.names:
        raise ValueError('Dataframe {0} does not contain index {1}'.format(message, index_name))

def dataframe_contains_col_index(dataframe, name, message):
    if not (name in dataframe.index.names or name in dataframe):
        raise ValueError('Dataframe {0} does not contain column or index {1}'.format(message, name))

def list_contains_value(list_in, value, message):
    if not value in list_in:
        raise ValueError('{0} does not contain {1}'.format(message, value))

def set_contains_value(set_in, value, message):
    if not value in set_in:
        raise ValueError('{0} does not contain {1}'.format(message, value))

def set_does_not_contain_value(set_in, value, message):
    if value in set_in:
        raise ValueError('{0} contains {1}'.format(message, value))

def series_groupby_is_numeric(series_groupby, message):
    if len(series_groupby) == 0:
        return
    type_is_numeric(series_groupby.dtype.values[0], message)

def validate(value):
    """Will recursively walk the tree calling validate on all IValidatable objects"""
    if value is not None and isinstance(value, IValidatable):
        value.validate()

def validate_required(value, message): 
    not_none(value, message)
    validate(value)

def validate_optional(value, message):
    if value != None:
        validate_required(value, message)

def directoryexists(value):
    if not os.path.exists(value):
        raise NotADirectoryError(errno.ENOTDIR, os.strerror(errno.ENOTDIR), value)

def fileexists(value):
    if not os.path.exists(value):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT), value)

def unique_values(value, message):
    non_unique = listex.get_non_unique(value)
    if len(non_unique) > 0:
        raise ValueError("{0} {1} not unique".format(message, ", ".join(non_unique)))

def length_equals(input_list, length, message):
    if not len(input_list) == length:
        raise ValueError("{0} not of length {1}".format(message, length))

def in_good_state(value, message):
    if not value:
        raise RuntimeError(message)

def issubclassof(target, base):
    if not issubclass(target, base):
        raise ValueError('{0} must be of subclass of {1}'.format(target, base))
