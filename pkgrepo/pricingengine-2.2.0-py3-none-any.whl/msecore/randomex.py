#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# Unit Testing Utilities
#
#------------------------------------------------------------------------

import random
import numpy as np

def set_random_seeds(seed=20170125):
    '''
    Sets both the builtin random.seed and Numpy's random.seed (separate)
    :param int seed: Seed to set. The default was the date when the repo was created.
    '''
    random.seed(seed) 
    np.random.seed(seed)
