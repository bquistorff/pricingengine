#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
# File, Url and Blob Path manipulation functions
# Extensions to os.path
#
#------------------------------------------------------------------------
import os
import uuid
import datetime
from . import (
    verify,
    system,
    stringex
)
        
def removeext(filename):
    """
        Remove the extension from a file name.

        :param str filename:
        :return: base filename
    """
    return os.path.splitext(filename)[0]

def ext(filename):
    """
        Returns the extension for a filename

        :param str filename:
        :return: extension
    """
    return os.path.splitext(filename)[1]

def hasext(filename, ex):
    """
        Return true if file has given extension

        :param str filename:
        :param str ex:  File extension. 
    """
    return ext(filename) == ex

def replaceext(filename, newext):
    return addext(removeext(filename), newext)

def addext(filename, ex):
    """
        Add an extension to a file name
        :return: Updated filename
    """
    verify.not_none_or_empty(ex, "ex")
    if not ex.startswith(os.path.extsep):
        ex = os.path.extsep + ex
    return filename + ex

def make_childpath(basepath, childpath=None, ex=None, timestamp=False):
    """
        Make a file path

        :param str basepath: optional path to a directory
        :param str childpath: File name or path
        :param str ex: optional file extension
        :param bool timestamp: Attach a timestamp
    """
    if not childpath:
        childpath = stringex.unique_string()
    newpath = os.path.join(basepath, childpath) if basepath else childpath
    if ex:
        newpath = addext(newpath, ex)
    if timestamp:
        newpath = append_timestamp(newpath)
    return newpath

def ensure_hasfilename(path, defaultname):
    """
        If path does not contain a fileName, appends defaultname to the path. 

        :param str path:
        :param str defaultname:
        :return: updated path
    """
    if os.path.isdir(path) or system.is_empty(ext(path)):
        verify.not_none_or_empty(defaultname, "defaultname")
        path = os.path.join(path, defaultname)

    return path

def replace_basedir(filepath, newdirpath):
    """
        Given a full path to a file, replace its directory path with a new one

        :param str filepath:
        :param str newdirpath:
        :return: new filepath 
    """
    return os.path.join(newdirpath, os.path.basename(filepath))

def append_to_name(path, suffix):
    """
        Append a suffix to a file/blob path. Retains the original extension

        :return: updated path
    """
    pathnoext, pathext = os.path.splitext(path)
    return pathnoext + suffix + pathext

def make_timestampstring(timestamp=None, sep='_'):
    if not timestamp:
        timestamp = datetime.datetime.now()
    return sep + '{:%Y%m%d_%H%M%S}'.format(timestamp)

def make_branchstring(sep='_'):
    return sep + system.git_info().head_name.replace('/', '_')

def append_timestamp(path, timestamp=None):
    """
        Append a timestamp to a file/blob path. Retains the original extension

        :return: updated path
    """
    return append_to_name(path, make_timestampstring(timestamp))

def make_datestring(timestamp=None, sep='_'):
    if not timestamp:
        timestamp = datetime.datetime.now()
    return sep + '{:%Y%m%d}'.format(timestamp)


def append_date(path, timestamp):
    """
        Append a date to a path. Retains original extension

        :return: updated path
    """
    return append_to_name(path, make_datestring(timestamp))

def append_datetime_range(path, datetime_range):
    """
        :param path: Original path
        :param datetime_range: datetime range to turn into string
        :type msecore.datetimeex.DateTimeRange:
        :return: updated path
    """
    verify.not_none(datetime_range, "datetime_range")

    suffix = make_timestampstring(datetime_range.minval) + "_" + make_timestampstring(datetime_range.maxval)
    return append_to_name(path, suffix)

def append_guid(path):
    """
        Append a guid to a filepath

        :return: updated filepath
    """
    pathnoext, pathext = os.path.splitext(path)
    guid = stringex.unique_string()
    return pathnoext + guid + pathext
