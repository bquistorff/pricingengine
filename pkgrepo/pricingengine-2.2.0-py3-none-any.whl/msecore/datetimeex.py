#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
# datetime extensions, utilities
#
#------------------------------------------------------------------------
import enum
import datetime
import dateutil
from . import (
    system,
    verify
)

def parse(dtstr, tzinfo=None):
    """
        Simple wrapper, so you don't have to import dateutil
    """
    newdt = dateutil.parser.parse(dtstr)
    if tzinfo:
        newdt = newdt.replace(tzinfo=tzinfo)
    return newdt

def parse_no_tz(dtstr):
    """
        Parse datetime, and remove all timezone info
    """
    newdt = parse(dtstr)
    return newdt.replace(tzinfo=None)

def days_from_now(numdays, now=None):
    """
        Returns a date that is 'numdays' from now. 

        :param int numdays:
            If negative, returns a datetime in the past
        :param now: If null, then now is current time-date
    """
    if not now:
        now = datetime.datetime.now()
    now += datetime.timedelta(days=numdays)
    return now

def to_start_of_minute(source):
    """
        For a source datetime, returns a new date time for the first minute

        :param datetime source:
    """
    return datetime.datetime(source.year, source.month, source.day, source.hour, source.minute)

def to_start_of_hour(source):
    """
        For a source datetime, returns a new date time for the first hour

        :param datetime source:
    """
    return datetime.datetime(source.year, source.month, source.day, source.hour)

def to_start_of_day(source):
    """
        For a source datetime, returns a new date time for the first millisecond of source's day (12.00 AM)

        :param datetime source:
    """
    return datetime.datetime(source.year, source.month, source.day)

def to_end_of_day(source):
    """
        For a source datetime, returns a new date time for the last millisecond of source's day

        :param datetime source:
    """
    return datetime.datetime(source.year, source.month, source.day, 23, 59, 59, 999)

def to_start_of_week(source, weekstartday=0):
    """
        For a source datetime, returns a new date time for the first day of the source's week

        :param datetime source:
        :param weekstartday: Default is 0
    """
    weekday = source.weekday()
    if weekday > 0:
        return days_from_now(weekstartday - weekday, to_start_of_day(source))
    return to_start_of_day(source)

def to_start_of_month(source):
    """
        For a source datetime, returns a new date time at first day of the source's month, 12.00 AM

        :param datetime source:
    """
    return datetime.datetime(source.year, source.month, 1)

def to_start_of_year(source):
    """
        For a source datetime, returns a new date time at first day of the source's year, 12.00 AM

        :param datetime source:
    """
    return datetime.datetime(source.year, 1, 1)

def to_utc(source):
    return source.replace(tzinfo=datetime.timezone.utc)

def week(source):
    """
        Returns the WEEK of the year this source is in. 

        :param datetime source:
    """
    _, weeknumber, _ = source.isocalendar()
    return weeknumber

class DateTimeRange(system.ValueRange):
    """
        DateTimeRange is used to work with time series, among other things. 
        Contains useful wrappers for typical datetime ranges
    """
    def __init__(self, minval, maxval):
        super().__init__(minval, maxval, True, True)
    
    @staticmethod
    def parse(minval, maxval, tzinfo=None):
        return DateTimeRange(parse(minval, tzinfo), parse(maxval, tzinfo))

    @staticmethod
    def parse_utc(minval, maxval):
        tzinfo = datetime.timezone.utc
        return DateTimeRange(parse(minval, tzinfo), parse(maxval, tzinfo))

    @staticmethod
    def parse_no_tz(minval, maxval):
        return DateTimeRange(parse_no_tz(minval), parse_no_tz(maxval))

    @staticmethod
    def last_n_days(numdays):
        """
            Return a DateTimeRange representing the last n days
        """
        now = datetime.datetime.now()
        return DateTimeRange(days_from_now(numdays, now), now)

    @staticmethod
    def current_day():
        """
            Return a DateTimeRange representing the current day
        """
        now = datetime.datetime.now()
        return DateTimeRange(to_start_of_day(now), now)

    @staticmethod
    def current_week():
        """
            Return a DateTimeRange representing the current month
        """
        now = datetime.datetime.now()
        return DateTimeRange(to_start_of_week(now), now)

    @staticmethod
    def current_month():
        """
            Return a DateTimeRange representing the current month
        """
        now = datetime.datetime.now()
        return DateTimeRange(to_start_of_month(now), now)

    @staticmethod
    def current_year():
        """
            Return a DateTimeRange representing the current year
        """
        now = datetime.datetime.now()
        return DateTimeRange(to_start_of_year(now), now)

def total_seconds(dt_to, dt_from):
    """
        Total # of seconds in the given range

        :param datetime dt_to:
        :param datetime dt_from:
    """
    return (dt_to - dt_from).total_seconds()

def total_minutes(dt_to, dt_from):
    """
        Return the total # of minutes in the given range

        :param datetime dt_to:
        :param datetime dt_from:
    """
    return total_seconds(dt_to, dt_from) / 60

def total_hours(dt_to, dt_from):
    """
        :param datetime dt_to:
        :param datetime dt_from:
    """
    return total_seconds(dt_to, dt_from) / 3600

def total_days(dt_to, dt_from):
    """
        :param datetime dt_to:
        :param datetime dt_from:
    """
    return total_hours(dt_to, dt_from) / 24
