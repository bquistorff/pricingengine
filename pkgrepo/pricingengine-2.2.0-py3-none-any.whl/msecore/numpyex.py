#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
# Numpy extension functions
#
#------------------------------------------------------------------------
import numpy as np
import pandas as pd
from . import (
    verify
)


def flatten(array):
    """
        Turn a multi-demensional array into a single dimension one
    """
    return np.ndarray.flatten(array)

def get_pe(truth, estimated):
    '''
    Computes a series of percentage error given a series of truth and estimated
    '''
    if isinstance(truth, float):
        truth = np.array([truth])
        estimated = np.array([estimated])
    residual = truth - estimated
    #sym_percentage_residual = np.where(residual == 0, 0, 
    #                                   np.divide(residual, (np.abs(estimated) + np.abs(truth)) / 2) * 100)
    #do the following so np.divide() doesn't see any weird values
    sym_percentage_residual2 = residual
    res_n0_idx = (residual != 0)
    denominator = (np.abs(estimated) + np.abs(truth)) / 2
    sym_percentage_residual2[res_n0_idx] = np.divide(residual[res_n0_idx], denominator[res_n0_idx]) * 100
    sym_percentage_residual = sym_percentage_residual2
    return sym_percentage_residual

def get_smape(truth, estimated):
    '''
    Computes sMAPE (symmetric mean average percentage error)
    '''
    sym_percentage_residual = get_pe(truth, estimated)
    smape = np.nanmean(np.abs(sym_percentage_residual))
    return smape


def howsimilar(truth, estimated):
    '''
    Calculate metrics comparing two scalars/vectors. Will disregard nan's.
    :return: Type: Mean Absolute Error, Mean Error, Mean Squared Error, sMAPE, r2

    '''
    if len(truth.shape) > 1 and truth.shape[1] > 1:
        if isinstance(truth, pd.DataFrame):
            truth = truth.values
        truth = truth.flatten()
        if isinstance(estimated, pd.DataFrame):
            estimated = estimated.values
        estimated = estimated.flatten()
    residual = truth-estimated

    sym_percentage_residual = get_pe(truth, estimated)
    y_bar = np.mean(truth)
    y_mean_dev = truth - y_bar
    #Below: if just using ndarrys, could use np.isnan(), but sometimes pd.Series
    nonnan_mask = ~pd.isnull(y_mean_dev) & ~pd.isnull(residual) 
    ss_tot_mean = np.mean(np.square(y_mean_dev[nonnan_mask]))
    ss_res_mean = np.mean(np.square(residual[nonnan_mask]))
    smape = np.nanmean(np.abs(sym_percentage_residual))
    if ss_tot_mean > 0:
        coef_determ = 1 - ss_res_mean / ss_tot_mean #same as 1-ss_res/ss_tot
    else:
        coef_determ = np.nan
    #mean_res_sign = np.mean(np.sign(residual[~np.isnan(residual)])) #would anyone want this?

    mae = np.nanmean(np.abs(residual))
    meanerror = np.nanmean(residual)
    mse = ss_res_mean
    return mae, meanerror, mse, smape, coef_determ
