#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
# FileSystem utilities
#
#------------------------------------------------------------------------
import os
import re
import zipfile
import pandas as pd
from msecore.listex import kv_enumerate
from msecoreml.pdmultiindexex import PdMultiIndexEx
from . import (
    verify,
    path,
    stringex
)

_LEGALIZEREGEX = re.compile('[^a-zA-Z0-9.]')
def legalize_filename(filename):
    """
    File names taken from Urls may contain characters that are not legal on the target store.
    We simply replace all non-alphanumeric characters with an _ so there could be collisions.
    """
    return _LEGALIZEREGEX.sub('_', filename)

def legalize_filepath(filepath):
    dirpath = os.path.dirname(filepath)
    filename = os.path.basename(filepath)
    return os.path.join(dirpath, legalize_filename(filename))

def list_filepaths(dirpath, extfilter=None):
    """
        Get an iterator full paths to files in a directory

        :param str dirpath: path to directory
        :param str extfilter: extension to include (default is all extensions)
        :return: iterator of full file paths
    """
    for name in os.listdir(dirpath):
        filepath = os.path.join(dirpath, name)
        if not os.path.isdir(filepath):
            if extfilter is None or path.ext(name) == extfilter:
                yield filepath

def list_dirpaths(dirpath):
    """
        Get an iterator full paths to sub-directories in a directory

        :param str dirpath: path to directory
        :return: iterator of full dir paths
    """
    for name in os.listdir(dirpath):
        dirpath = os.path.join(dirpath, name)
        if os.path.isdir(dirpath):
            yield dirpath

def ensuredir(dirpath):
    """
        Create a directory if it does not already exist. 
    """
    if not os.path.exists(dirpath):
        os.makedirs(dirpath)
    return dirpath

def create_zipfile(filepaths, zipfilepath):
    verify.not_none_or_empty(zipfilepath, "zipfilepath")
    
    with zipfile.ZipFile(zipfilepath, 'w') as zipdata:
        for filepath in filepaths:
            zipdata.write(filepath)

def extract_zipfile(srcpath, destpath=None):
    verify.not_none(srcpath, "srcpath")
    if destpath is None:
        destpath = os.path.dirname(srcpath)
    with zipfile.ZipFile(srcpath) as file:
        file.extractall(destpath)
        return destpath

def zipdir(srcpath, zipfilepath):
    create_zipfile(list_filepaths(srcpath), zipfilepath)

def extract_zipdir(srcpath, destpath=None):
    for filepath in list_filepaths(srcpath, ".zip"):
        destfilepath = None if destpath is None else path.replace_basedir(filepath, destpath)
        extract_zipfile(filepath, destfilepath)

def open_child(folderpath, filename, mode):
    """
        Open a file in a folder
    """
    filepath = path.make_childpath(folderpath, filename)
    return open(filepath, mode)

def open_child_unique(folderpath, mode):
    return open_child(folderpath, stringex.unique_string(), mode)

def write_to_textfile(filepath, value):
    """
        :param str filepath: path to file
        :param value: Object to print to file
    """
    verify.not_none_or_empty(filepath, "filepath")
    with open(filepath, "wt") as file:
        print(value, file=file)

def append_to_textfile(filepath, value):
    """
        :param str filepath: path to file
        :param value: Object to print to file
    """
    verify.not_none_or_empty(filepath, "filepath")
    with open(filepath, "at") as file:
        print(value, file=file)
        

def write_numbered_dfs(dfs, basename_path, single_xlsx=True, sheetnamebase='lead', filenameextbase='_l', xwriter=None):
    '''
    if there are nan's in the index, need to remove them for xlsx writing
    :param dfs: Can be dictionary, or list
    :param basename_path:
    :param single_xlsx:
    :param sheetnamebase:
    :param filenameextbase:
    :param xwriter:
    '''

    if single_xlsx:
        import xlsxwriter
        openclose = (xwriter is None)
        if openclose:
            xwriter = pd.ExcelWriter(basename_path+'.xlsx', engine='xlsxwriter')
        for i, df in kv_enumerate(dfs):
            PdMultiIndexEx.fillna_multiindex(df.index)
            ext = "" if len(dfs) == 1 else str(i)
            #merge_cells doesn't do what we want with indexes and blanks
            df.to_excel(xwriter, sheet_name=sheetnamebase+ext, merge_cells=False) 
        if openclose:
            xwriter.save()
    else:
        for i, df in kv_enumerate(dfs):
            ext = "" if len(dfs) == 1 else str(i)
            df.to_csv(basename_path+ filenameextbase+ext + '.csv')


def write_composite_sheet(dict_map, basename_path):
    import xlsxwriter
    xwriter = pd.ExcelWriter(basename_path+'.xlsx', engine='xlsxwriter')
    for key in sorted(dict_map):
        write_numbered_dfs(dict_map[key], basename_path="", single_xlsx=True, sheetnamebase=key, xwriter=xwriter)
    xwriter.save()
