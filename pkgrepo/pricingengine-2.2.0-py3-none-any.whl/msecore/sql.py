#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
import contextlib
import _collections_abc
#import collections.abc
import pyodbc
from . import (
    verify,
    system
)

def connectionstring(driver, server, port, dbname, userid, password):
    """Make an ODBC connection string"""
    if not userid and not password:
        return "DRIVER={{{0}}};SERVER={1};PORT={2};DATABASE={3}".format(driver, server, port, dbname)

    return "DRIVER={{{0}}};SERVER={1};PORT={2};DATABASE={3};UID={4};PWD={5}".format(driver, server, port, 
                                                                                    dbname, userid, password)

def connectionstring_sqlserver(server, dbname, userid=None, password=None):
    return connectionstring("SQL SERVER", server, 1433, dbname, userid, password)

def connectionstring_local(dbname):
    return connectionstring_sqlserver("localhost", dbname, None, None)

def connectionstring_adduserpass(connection_string, credentials):
    """
        :param connection_string:
        :param credentials:
        :type credentials:  msecore.security.UserPassCredentials
    """
    verify.validate_required(credentials, "credentials")

    return "{0};UID={1};PWD={2}".format(connection_string, credentials.userid, credentials.password)

def connectionstring_addintegrated(connection_string):
    return "{0};Integrated Security=true".format(connection_string)

class ColumnDef:
    """
        ColumnDef provides named access readers over a pyodbc header_tuple
    """
    __slots__ = ('__header_tuple')

    def __init__(self, header_tuple):
        """
            :param tuple header_tuple:
                Tuples returned by pyodbc, in order. 
                (name, type_code, display_size, internal_size, precision, scale, null_ok)
        """
        verify.not_none(header_tuple, "header_tuple")
        self.__header_tuple = header_tuple
    
    @property
    def name(self):
        return self.__header_tuple[0]
    
    @property
    def type(self):
        return self.__header_tuple[1]

    @property
    def size(self):
        return self.__header_tuple[3]

    @property
    def is_nullable(self):
        return self.__header_tuple[6]

    def __str__(self):
        return "Name={0}, Type={1}, Size={2}, Nullable={3}".format(self.name, self.type, self.size, self.is_nullable)

def columns(cursor):
    """
        Return the columns in a given pyodbc cursor

        :param cursor:
        :type cursor: pyodbc.cursor
        :return: An iterator of ColumnDef objects
    """
    verify.not_none(cursor, "cursor")
    for column_tuple in cursor.description:
        yield ColumnDef(column_tuple)
 
def column_names(cursor):
    """
        Given a pyodbc cursor, return the column names for the rows returned by the cursor

        :param cursor:
        :type cursor: pyodbc.cursor
        :return: An iterator of column names
    """
    verify.not_none(cursor, "cursor")

    for column_tuple in cursor.description:
        yield column_tuple[0]


def save_to_csv(cursor, csvwriter, func_rowtransform=None):
    """
        Take the rows in a pyodbc cursor and save them as CSV

        :param cursor:
        :type cursor: pyodbc.cursor
        :param csvwriter:
        :type: csvwriter: csv.writer
        :param func_rowtransform:  Signature (pyodbc.row)
    """
    verify.not_none(cursor, "cursor")
    verify.not_none(csvwriter, "csvwriter")
    csvwriter.writerow(column_names(cursor))
    if func_rowtransform is None:
        csvwriter.writerows(cursor)
    else:
        for row in cursor:
            newrow = func_rowtransform(row)
            csvwriter.writerow(newrow)

class SqlConnection(contextlib.ContextDecorator):
    """
        Wrap pyodbc so that we can auto-close connections as soon as we are 
        done with them. Pyodbc relies on Python's garbage collector to reclaim connections,
        (specially the CPython implemenation) which it hopes is adequately aggressive. 
        A caller can also call close() manually, but we don't want to rely on their discipline
        Manual calls close don't work in case of exceptions either. 

        We also want failed transactions to be rolled back as soon as possible. 
        pyodbc will automatically rollback any transaction that wasn't explicitly committed. 
        But if a caller forgets, or there is an exception, pyodbc will wait until the 
        underying garbage collector kicks in... and the transaction will remain active! 

        Instead, we want to use the "with" pattern in Python (like the 'using' + IDisposable 
        pattern in .NET)

    """
    def __init__(self, connectionstr):
        verify.not_none_or_empty(connectionstr, "connectionstr")
        self.__connectionstr = connectionstr
        self.__connection = None #create the connection as late as possible

    @property
    def connection(self):
        """Return the underlying raw pyodbc connection"""
        self.__ensure()
        return self.__connection

    def cursor(self):
        return SqlCursor(self.connection.cursor())

    def __ensure(self):
        if self.__connection is None:
            self.__connection = pyodbc.connect(self.__connectionstr)
                
    def __close(self):
        if self.__connection:
            self.__connection.close()
            self.__connection = None

    def __enter__(self):
        self.__ensure()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.__close()

class SqlCursor(contextlib.ContextDecorator, _collections_abc.Iterable):
    """
        Wraps a pyodbc cursor - ensures that the cursor is always closed. 
    """
    def __init__(self, cursor):
        """
            :param cursor:
            :type cursor: pyodbc.cursor
        """
        verify.not_none(cursor, "cursor")
        self.cursor = cursor
    
    def columns(self):
        return columns(self.cursor)

    def column_names(self):
        return column_names(self.cursor)

    def execute(self, sql, *params):
        return self.cursor.execute(sql, *params)
    
    def executemany(self, sql, *params):
        return self.cursor.executemany(sql, *params)

    def commit(self):
        self.cursor.commit()

    def save_csv(self, csvwriter, func_rowtransform=None):
        save_to_csv(self.cursor, csvwriter, func_rowtransform)

    def __close(self):
        if self.cursor:
            self.cursor.close()
            self.cursor = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.__close()

    def __iter__(self):
        return iter(self.cursor)

class SqlResource(verify.IValidatable):
    """
        A SqlResource has:
            A connection string
            A query
            A name
    """
    __slots__ = ('connection_string', 'query', 'name')
    def __init__(self, connection_string=None, query=None, name=None):
        """
            :param str connection_string:
                Connection string to the sql source
            :param str query:
                Sql query that will retrieve data from the resource
            :param str name:
                This resource's name
        """
        self.connection_string = connection_string
        self.query = query
        self.name = name

    def validate(self):
        verify.validate_required(self.connection_string, "connection_string")
        verify.validate_required(self.query, "query")
        verify.validate_required(self.name, "name")

    def get(self):
        """
            :return: An iterable of pyodbc.Row
        """
        with SqlConnection(self.connection_string) as connection:
            with connection.cursor() as cursor:
                cursor.execute(self.query)
                for row in cursor:
                    yield row
    
    def apply_credentials(self, userpass=None):
        """
            :param msecore.security.UserPassCredentials userpass:
        """
        if userpass:
            verify.validate_required(userpass, "userpass")
            self.connection_string = connectionstring_adduserpass(self.connection_string, userpass)
        else:
            self.connection_string = connectionstring_addintegrated(self.connection_string)

    @staticmethod
    def each_apply_credentials(sqlresources, userpass=None):
        """
            For each SqlResource, apply the userpass to its credentials

            :param msecore.security.UserPassCredentials userpass:            
            :yields: Each SqlResource
        """
        for sqlresource in sqlresources:
            sqlresource.apply_credentials(userpass)
            yield sqlresource

    def __str__(self):
        return "[{0}]\n{1}".format(self.name, self.query)
    
class SqlClient:
    """
        Class that encapsulates common access patterns for Sql databases
    """
    def __init__(self, policy=None):
        self.timeout = 0
        if policy is None: 
            policy = system.OperationPolicy()
        self.policy = policy
    
    def download_resource(self, sqlresource, datahandler):
        """
            :param sqlresource:
            :param function datahandler:
                Signature: (SqlCursor)
        """
        verify.not_none(sqlresource, "sqlresource")
        return self.download_rows(sqlresource.connection_string, sqlresource.query, datahandler)

    def download_rows(self, connection_string, query, datahandler):
        """
            :param str connection_string:
            :param str query:
            :param function datahandler:
                Signature: (SqlCursor)
        """
        self.policy.execute(lambda: self.__download_rows(connection_string, query, datahandler))

    def __download_rows(self, connection_string, query, datahandler):
        with SqlConnection(connection_string) as connection:
            if self.timeout:
                connection.connection.timeout = self.timeout
            with connection.cursor() as cursor:
                cursor.execute(query)
                datahandler(cursor)
