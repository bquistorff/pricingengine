#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------


class MseException(Exception):
    """
        Exception thrown 
    """
    def __init__(self, error_code, error_message=None):
        """
            :param enum error: error number
            :param string message: error message
        """
        super().__init__(error_code, MseException._tostring(error_message, error_code))
        self.errorcode = error_code

    @staticmethod
    def _tostring(message, error):
        if message:
            return "{0}, {1}".format(error.name, message)
        else:
            return error.name

    @staticmethod
    def verify(condition, mlerror, message=None):
        if not condition:
            raise MseException(mlerror, message)
