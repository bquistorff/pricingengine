#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import copy
import datetime
from collections import ChainMap
from scipy.stats import norm
from scipy.stats import binom
import numpy as np
import pandas as pd
from msecore.numpyex import get_pe
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pddataframeex import PdDataframeEx
from pricingengine.estimation.typed_dataset import ColType
from pricingengine.models.model import Model, SampleSplitModel
#from pricingengine.models.prepredicted import PrePredicted
from pricingengine.estimation.double_ml import DoubleML, DoubleMLLikeModel
from pricingengine.estimation.dynamic_dml import DynamicDML

#pylint: disable=redefined-variable-type, protected-access, too-many-locals

class Predictions():
    '''
    Class used to generate and manipulate predictions from a pretrained model
    '''
    ACTUAL_COL = 'actuals'
    CI_UPPER_ENDPOINT = 'CI upper'
    CI_LOWER_ENDPOINT = 'CI lower'
    RESIDUAL = 'error'
    PERCENT_ERROR = 'percent_error'
    ERROR_GEQ = 'error_geq'
    ERROR_VIEW_LEVEL = 'error_view'
    ERROR_STAT_LEVEL = 'error_view_stat'

    def __init__(self, model, estimation_dataset, outcome_is_log=False, ret_pred=None):
        
        '''
        Creates a new Predictions instance

        :param DoubleMLLikeModel model: The model used to make predictions. This object must have a _predict method
        :param EstimationDataSet estimation_dataset: The dataset on which predictions are made
        :param bool outcome_is_log: Set this to true if effectmodel was trained on a logged outcome and 
            all outcomes and forecasts will be transformed to non-log scale
        :param diffed_vars: List of variables that were first differenced before they were fit in first-stage
        :param ret_pred: None else empty DataFrame (if empty dataFrame then will be populated with predcitions)
        '''
        diffed_vars = []
        if hasattr(model, 'get_diffed_vars'):
            diffed_vars = model.get_diffed_vars()

        self._date_col = estimation_dataset.schema.get_time_col_name()
        self._outcome_is_log = outcome_is_log
        self._interval = estimation_dataset.data_interval
        self._prediction_col_name = Model.PREDICTION_COL_NAME
        self._avgerror_col_name = Model.AVG_ERROR_COL_NAME
        self._type_col_name = DoubleMLLikeModel.TYPE_COL_NAME
        self._lead_level_name = DynamicDML.LEAD_LEVEL_NAME
        self._leads = [0] #If no notion of "lead" then leave as 0
        if hasattr(model, 'options'):
            self._leads = model.options.leads
        self._baseline_df = pd.DataFrame()

        baseline_col_levels = [Model.VARIABLE_COLNAME, self._lead_level_name, None]

        data = model.predict(estimation_dataset, ret_pred=self._baseline_df)
        if ret_pred is not None:
            PdDataframeEx.assign_inplace(ret_pred, self._baseline_df)
        data[0, Predictions.ACTUAL_COL] = pd.Series(estimation_dataset.data[ \
            estimation_dataset.schema.get_colname_bycoltype(ColType.OUTCOME)].values, index=data.index) #grab actuals

        all_vars = estimation_dataset.schema.get_colnames_bycoltype(ColType.TREATMENT) + \
            [estimation_dataset.schema.get_colname_bycoltype(ColType.OUTCOME)]

        actuals = estimation_dataset.data[all_vars]
        actuals.columns = pd.MultiIndex.from_product([actuals.columns.values, [0], [Predictions.ACTUAL_COL]], 
                                                     names=baseline_col_levels)

        tmp = self._baseline_df.sort_index().unstack(baseline_col_levels[:-1]).reorder_levels(baseline_col_levels, 
                                                                                              axis=1)


        tmp = tmp.merge(actuals.reset_index(), right_on=tmp.index.names, left_index=True) \
            .set_index(tmp.index.names)

        tmp = tmp.reorder_levels([self._lead_level_name, Model.VARIABLE_COLNAME, None], axis=1)
        #print(self._leads)
        for lead in self._leads:
            for var in diffed_vars:
                tmp[lead, var, self._prediction_col_name] += estimation_dataset.data[var]
            #shift by lead
            p_names = estimation_dataset.schema.get_panel_col_names()
            data[lead] = data[lead].groupby(level=p_names).shift(lead)
            for col in tmp.columns[tmp.columns.get_level_values(self._lead_level_name) == lead]:
                tmp[col] = tmp[col].groupby(level=p_names).shift(lead) 
        
        tmp = tmp.reorder_levels([Model.VARIABLE_COLNAME, self._lead_level_name, None], axis=1)

        if self._outcome_is_log:
            prediction_cols = PdMultiIndexEx.get_1level_block_indicator(data.columns, self._type_col_name, 
                                                                        [self._prediction_col_name])
            data.loc[:, prediction_cols] = np.exp(data.loc[:, prediction_cols])
            data[0, Predictions.ACTUAL_COL] = np.exp(data[0, Predictions.ACTUAL_COL])

            o_orig = tmp[estimation_dataset.schema.get_colname_bycoltype(ColType.OUTCOME)]
            #o_orig = np.array(o_orig, dtype=np.float32)
            tmp[estimation_dataset.schema.get_colname_bycoltype(ColType.OUTCOME)] = np.exp(o_orig)

        
        self._baseline_df = tmp.reindex_axis(sorted(tmp.columns), axis=1)
        self._data = data.reindex_axis(sorted(data.columns), axis=1)

    def get_prediction_intervals(self, coverage=0.90):
        '''
        Returns prediction intervals for each observation with the corresponding level of coverage. 
        Prediction intervals are based on the avg_error columns and a gaussian approximation

        :param coverage: a float between 0 and 1 indicating the desired level of coverage for each forecast interval
        '''

        z_statistic = abs(norm.ppf((1 - coverage)/2))
        correction = np.sqrt(np.pi / 2)

        pred_plus_interval = self._data.copy()
        for lead in self._leads:
            if lead > 0:
                half_width = z_statistic  * correction * pred_plus_interval[lead, self._avgerror_col_name]
                center = pred_plus_interval[lead, self._prediction_col_name]
                if self._outcome_is_log:
                    pred_plus_interval[lead, Predictions.CI_UPPER_ENDPOINT] = np.exp(np.log(center) + half_width)
                    pred_plus_interval[lead, Predictions.CI_LOWER_ENDPOINT] = np.exp(np.log(center) - half_width)
                else:
                    pred_plus_interval[lead, Predictions.CI_UPPER_ENDPOINT] = center + half_width
                    pred_plus_interval[lead, Predictions.CI_LOWER_ENDPOINT] = center - half_width

        return pred_plus_interval
    
    @property
    def data(self):
        '''
        Return self._date
        '''
        return self._data


    @data.setter
    def data(self, df):
        '''
        Sets data
        '''
        self._data = df

    def filter(self, filter_dic, first_date=None, last_date=None):
        '''
        Return a subset of the predictions object that corresponds to the filter dictinoary passed in

        :param filter_dic: dictionary mapping categorical columns to lists of acceptable values
        :param first_date: omit any data before this date
        :param last_date: omit any data from after this date
        '''

        new_pred = copy.deepcopy(self)
        new_pred.data = new_pred.data.loc[PdMultiIndexEx.get_some_levels_block_indicator(new_pred.data.index, 
                                                                                         filter_dic), :]


        if not first_date is None:
            new_pred.data = new_pred.data[new_pred.data.index.get_level_values(self._date_col) >= first_date]

        if not last_date is None:
            new_pred.data = new_pred.data[new_pred.data.index.get_level_values(self._date_col) <= first_date]
        
        return new_pred

    def get_smape(self, names=None, first_stage=False):
        '''
        Computes sMAPE (symmetric mean average percentage error) for each unique combination of names. 
        Returns a dataframe of mapes for each lookahead and each unique combination of the indices found in names.

        :param names: A list of names (that must be present in the index of self._data). 
            avg. mapes will be computed for every unique combination of levels of these names
	    :param first_stage: Get smapes for first stage regressions as opposed to final outcome (default is False)
        '''


        
        if names is not None:
            if any([name not in self.data.index.names for name in names]):
                raise Exception('Cant split on : ' + str([name for name in names if name not in self.data.index.names]))
        else:
            names = []

        if first_stage:
            df = self._baseline_df.copy()
            var_list = df.columns.get_level_values(Model.VARIABLE_COLNAME)
            for lead in self._leads:
                for var in var_list:
                    df[var, lead, Predictions.PERCENT_ERROR] = abs(get_pe(df[var, 0, Predictions.ACTUAL_COL],
                                                                          df[var, lead, self._prediction_col_name]))
            #df = df.apply(pd.to_numeric)
            if names != []:
                groupby = df.groupby(level=names)
            else:
                groupby = df.groupby(lambda x: 0)
            mapes = groupby.agg({(var, lead, Predictions.PERCENT_ERROR) : np.mean
                                 for var in var_list
                                 for lead in self._leads})
            mapes.columns.names = [Model.VARIABLE_COLNAME, self._lead_level_name, Predictions.ERROR_VIEW_LEVEL]
        else:
            df = self._data.copy()
            for lead in self._leads:
                df[lead, Predictions.PERCENT_ERROR] = abs(get_pe(df[0, Predictions.ACTUAL_COL],
                                                                 df[lead, self._prediction_col_name]))
            
            if names != []:
                groupby = df.groupby(level=names)
            else:
                groupby = df.groupby(lambda x: 0)
            mapes = groupby.agg({(lead, Predictions.PERCENT_ERROR) : np.mean 
                                 for lead in df.columns.get_level_values(self._lead_level_name) 
                                 if lead > 0})
            mapes.columns.names = [self._lead_level_name, Predictions.ERROR_VIEW_LEVEL]

        return mapes.reindex_axis(sorted(mapes.columns), axis=1)


    def get_residual_sign_test_by_cols(self, names=None):
        '''
        Computes a sign test on the distribution of residuals for each unique combination of names. 
        Returns a dataframe of residual, counts, number of residuals greater than 0 and a sign test on 
        the null hypothesis that the median of the null distribution is zero.

        :param names: A list of names (that must be present in the index of self._data). 
            avg. mapes will be computed for every unique combination of levels of these names
        '''
        df = self._data.copy()
        if names is not None:
            if any([name not in df.index.names for name in names]):
                raise Exception('Cant split on : ' + names)
        else:
            names = []


        for lead in df.columns.get_level_values(self._lead_level_name):
            if lead > 0:
                df[lead, Predictions.ERROR_GEQ] = (df[lead, self._prediction_col_name] >= \
                    df[0, Predictions.ACTUAL_COL])
        dict(ChainMap(*[{}]))

        if names != []:
            groupby = df.groupby(level=names)
        else:
            groupby = df.groupby(lambda x: 0)
        signs = groupby.agg({(lead, Predictions.ERROR_GEQ) : [np.sum, 'count']
                             for lead in df.columns.get_level_values(self._lead_level_name)
                             if lead > 0})
        for lead in df.columns.get_level_values(self._lead_level_name):
            if lead > 0:
                signs[lead, Predictions.ERROR_GEQ, 'p'] = binom.cdf(signs[lead, Predictions.ERROR_GEQ, 'sum'],
                                                                    signs[lead, Predictions.ERROR_GEQ, 'count'], .5)
        signs.columns.names = [self._lead_level_name, Predictions.ERROR_VIEW_LEVEL, Predictions.ERROR_STAT_LEVEL]
        return signs


    def get_mean_residual(self, names=None):
        '''
        Computes the mean estimated residual for each unique combination of names. 
        Positive numbers indicate that the model is underforecasting. 
        If self.pred_is_logs=True, then the mean is computed on the underlying logs

        :param names: A list of names (that must be present in the index of self._data). 
            avg. mapes will be computed for every unique combination of levels of these names
        '''
        df = self._data.copy()
        if names is not None:
            if any([name not in df.index.names for name in names]):
                raise Exception('Cant split on : ' + names)
        else:
            names = []

        for lead in df.columns.get_level_values(self._lead_level_name):
            if lead > 0:
                if self._outcome_is_log:
                    df[lead, Predictions.RESIDUAL] = np.log(df[lead, self._prediction_col_name]) - \
                        np.log(df[0, Predictions.ACTUAL_COL])
                else:
                    df[lead, Predictions.RESIDUAL] = df[0, Predictions.ACTUAL_COL]  - \
                        df[lead, self._prediction_col_name]

        if names != []:
            groupby = df.groupby(level=names)
        else:
            groupby = df.groupby(lambda x: 0)
        avg_error = groupby.agg({(lead, Predictions.RESIDUAL) : [np.mean, 'count']
                                 for lead in df.columns.get_level_values(self._lead_level_name)
                                 if lead > 0})
        #avg_error.columns = sorted(avg_error.columns) #Sorting like this squashes the multiindex. If needed, do better
        avg_error.columns.names = [self._lead_level_name, Predictions.ERROR_VIEW_LEVEL, Predictions.ERROR_STAT_LEVEL]
        return avg_error

    
    def get_projections_from_date(self, projection_date, coverage):
        '''
        Organized prediction object to get all projections made from a certain date

        :param projection_date: The date from which the requested predictions are made
        :param coverage: a float between 0 and 1 indicating the desired level of coverage for each forecast interval
        '''
        df = self.get_prediction_intervals(coverage)
        index_dates = df.index.get_level_values(self._date_col)
        cols = df.columns

        output = pd.DataFrame()
        for lead in self._leads:
            tmp = df.loc[
                PdMultiIndexEx.get_1level_block_indicator(index_dates, self._date_col, 
                                                          projection_date + self._interval * float(lead)),
                PdMultiIndexEx.get_nlevel_block_indicator(cols, {self._type_col_name : self._prediction_col_name, 
                                                                 self._lead_level_name : lead}) +
                PdMultiIndexEx.get_nlevel_block_indicator(cols, {self._type_col_name : Predictions.CI_UPPER_ENDPOINT, 
                                                                 self._lead_level_name : lead}) +
                PdMultiIndexEx.get_nlevel_block_indicator(cols, {self._type_col_name : Predictions.CI_LOWER_ENDPOINT, 
                                                                 self._lead_level_name : lead})
                ]
            tmp.columns = tmp.columns.droplevel(level=self._lead_level_name)
            output = output.append(tmp)

        return output.sort_index()
