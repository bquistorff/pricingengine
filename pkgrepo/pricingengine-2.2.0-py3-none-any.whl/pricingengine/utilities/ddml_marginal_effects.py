#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import copy
import numpy as np
import pandas as pd
from scipy.stats import norm

from msecoreml.pdmultiindexex import PdMultiIndexEx
from pricingengine.variables.var_builder import VarBuilder

#pylint: disable=protected-access, too-many-locals

class DDMLMarginalEffects():
    '''
    Class for aggregating and computing marginal effects from dynamic_DML model
    '''

    def __init__(self, schema, treatment_name, model, competition_col, leads=None, filter_dic=None):
        '''
        Create an MarginalEffects object

        :param treatment_name: The treatment with respect to which the desired effects are computed
        :param model: The dynamic dml model from which marginal effects are derived.
        :param leads: list of leads to be included in the effect matrix
        :param competition_col: the col (from the estimationDataset) along which units might have spill over effects
        :param filter_dic: dictionary for filtering effect matrix (filtering before computing can be much faster)
        :WARNING: This class currently only works for dynamic_dml models
        '''
        if filter_dic is None: 
            filter_dic = {}
        #verify.in_good_state(effectmodel.__fit, verify.Messages.BAD_MODEL_STATE_MESSAGE)
        if leads is None:
            self._total_leads = model.options.leads
        else:
            self._total_leads = leads
        
        self._competition_col = competition_col
        self._lead_col_name = model.LEAD_LEVEL_NAME
        self._treatment_name = treatment_name

        mfx, aux_dataframe_leads = self._get_empty_matrix(model, filter_dic)
        self._mfx = mfx
        self._mfx_se = pd.DataFrame(np.nan, index=self.mfx.index, columns=self.mfx.columns)

        self._aux = aux_dataframe_leads
        self._schema = schema
        self._compute_mfx(model)
        

    @property
    def competition_col(self):
        return self._competition_col

    @property
    def total_leads(self):
        '''
        The leads of the MFX
        '''
        return self._total_leads

    @property
    def mfx(self):
        '''
        Gets a dataframe of estiamted marginal effects
        '''
        return self._mfx

    @property
    def mfx_se(self):
        '''
        Gets a dataframe of standard errors on estimated marginal effects
        '''
        return self._mfx_se
    
    def _drop_prefix(self, name):
        col_names = self._schema.get_col_names()
        prefix = [pre for pre in col_names if name.startswith(pre)]
        if len(prefix) == 0:
            #print('no colname found')
            return name
        elif len(prefix) > 1:
            print(prefix)
            raise Exception('Two dataset columns have the same name. This is not allowed.')
        else:
            return name[len(prefix[0]) + 1 :]

    def mfx_ci_upper(self, p=.025):
        '''
        Get dataframe of upper ci end points on marginal effects. p is the amount of probability left in the 
        upper tail, so setting p=.025 gets the upper end point of a two-sided 95% CI.
        '''
        return self._mfx + self._mfx_se * norm.ppf(1 - p)

    def mfx_ci_lower(self, p=.025):
        '''
        Get dataframe of lower ci end points on marginal effects. p is the amount of probability left in the 
        lower tail, so setting p=.025 gets the lower end point of a two-sided 95% CI.
        '''
        return self._mfx + self._mfx_se * norm.ppf(p)


    def _get_empty_matrix(self, model, filter_dic):
        '''
        Returns an empty effect matrix dataframe with cols and indices determined by the categorical treatments in 
        effectmodel

        :param model: The model from which treatment effects will be derived
        :param filter_dic: dictionary for filtering effect matrix
        '''

        cols = model.aux_dataframe.columns
        cols = cols[PdMultiIndexEx.get_some_levels_block_indicator(cols, filter_dic)]
        cols = pd.DataFrame(1, index=cols, columns=pd.Index(self._total_leads, name=self._lead_col_name)).stack().index
        competition_var_values = cols.get_level_values(self._competition_col).unique().values

        index = pd.MultiIndex.from_product([self._total_leads, competition_var_values], 
                                           names=[self._lead_col_name, self._competition_col])
        matrix = pd.DataFrame(columns=cols, index=index)

        aux_dataframe_leads = pd.DataFrame(model.aux_dataframe.loc[:, [j[:-1] for j in cols.values]].values, 
                                           index=model.aux_dataframe.index, columns=cols)
        return matrix.fillna(0.0), aux_dataframe_leads

    def _compute_mfx(self, model):

        relevant_feature_builders = {fb.var_builder_sig : fb.get_effect_weights(self)
                                     for fb in model.treatment_generator.feature_builders
                                     if fb.treatment_column == self._treatment_name}

        if len(relevant_feature_builders.keys()) == 0:
            raise Exception('No relevant treatment builders used in model training')

        coefs = model.get_coefficients(human_index=False).T
        relevant_coefs = PdMultiIndexEx.get_1level_block_indicator(coefs.columns, 
                                                                   VarBuilder.FEATURE_TYPE_COL_NAME,
                                                                   list(relevant_feature_builders.keys()))

        coefs = coefs.loc[:, relevant_coefs]
        var = model.get_variance_matrix(human_index=False).loc[relevant_coefs, relevant_coefs]

        coef_eff_weights = [pd.DataFrame(0,
                                         index=self.mfx.index,
                                         columns=self.mfx.columns)
                            for c in coefs.columns]
        
        
        feature_type_col_index = coefs.columns.names.index(VarBuilder.FEATURE_TYPE_COL_NAME)
        aux_column_index = [coefs.columns.names.index(aux) 
                            for aux in self._aux.index.values if aux in coefs.columns.names]
        impactor_column_index = VarBuilder._index_containing_substring(coefs.columns.names, 
                                                                       VarBuilder.IMPACTOR)
        impactor_colname = None
        if impactor_column_index > -1:
            impactor_colname = coefs.columns.names[impactor_column_index].split('_')[-1]
            
        base_column_indices = [j for j, _ in enumerate(coefs.columns.names) 
                               if j not in  [impactor_column_index, feature_type_col_index] + aux_column_index]

        coef_index_count = -1
        if len(coefs.columns.values) == 1:
            tmp = [coefs.columns.values]
        else:
            tmp = coefs.columns.values

        for column_value in tmp:
            coef_index_count += 1
            if not isinstance(column_value, (list, tuple, np.ndarray)):
                column_value = [column_value]

            #get feature specific effect weights (e.g. own price filter)
            effect_weights = relevant_feature_builders[column_value[feature_type_col_index]]

            #filter impacted instances from columns index
            effect_filter = {coefs.columns.names[j] : self._drop_prefix(column_value[j]) for j in base_column_indices if
                             str(column_value[j]) != VarBuilder.NAN_STR}
            use_cols = (PdMultiIndexEx.get_some_levels_block_indicator(self._mfx.columns, effect_filter))

            #filter rows only if coefficient has non nan "impactor" index
            if impactor_column_index > -1 and str(column_value[impactor_column_index]) != VarBuilder.NAN_STR:
                use_rows = PdMultiIndexEx.get_1level_block_indicator(self._mfx.index, 
                                                                     impactor_colname, 
                                                                     column_value[impactor_column_index])
            else:
                use_rows = [True for j in self._mfx.index]

            use_aux_cols = [column_value[aux] 
                            for aux in aux_column_index if str(column_value[aux]) != VarBuilder.NAN_STR]
            tmp = effect_weights.loc[use_rows, use_cols].values 
            for aux in use_aux_cols:
                tmp *= self._aux.loc[aux, use_cols].values 

            coef_eff_weights[coef_index_count].loc[use_rows, use_cols] += tmp


        
        for indx, _ in self._mfx.iterrows():
            for col in self._mfx:
                tmp = [c.loc[indx, col] for c in coef_eff_weights]
                self._mfx_se.loc[indx, col] = np.sqrt(np.matmul(np.matmul(tmp, var.values), tmp))
                self._mfx.loc[indx, col] = np.matmul(tmp, coefs.values[0])

    def filter(self, filter_dic, impacted_leads=None, impacting_leads=None):
        '''
        Return filtered marginal effects columns

        :param filter_dic: dictionary mapping from column levels to acceptable values
        :param impacted_leads: list of leads (columns) that will be preserved
        :param impacting_leads: list of leads (rows) that will be preserved
        '''
        
        new_elast = copy.deepcopy(self)
        print(new_elast.mfx.columns.names)
        print(filter_dic)
        col_list = PdMultiIndexEx.get_some_levels_block_indicator(new_elast.mfx.columns, filter_dic)
        new_elast._mfx = new_elast.mfx.loc[:, col_list]
        new_elast._mfx_se = new_elast.mfx_se.loc[:, col_list]

        if impacted_leads != None:
            col_list2 = PdMultiIndexEx.get_1level_block_indicator(new_elast.mfx.columns, 'lead', [impacted_leads])
            new_elast._mfx = new_elast.mfx.loc[:, col_list2]
            new_elast._mfx_se = new_elast.mfx_se.loc[:, col_list2]

        if impacting_leads != None:
            row_list = PdMultiIndexEx.get_1level_block_indicator(new_elast.mfx.index, 'lead', [impacting_leads])
            new_elast._mfx = new_elast.mfx.loc[row_list, :]
            new_elast._mfx_se = new_elast.mfx_se.loc[row_list, :]

        return new_elast


    def get_own_effect(self, filter_dic=None, lead=None):
        '''
        Get own treatment effect

        :param filter_dic: dictionary mapping from column levels to acceptable values. Default is empty dictionary.
        :param lead: lead used (for both row and column) to select marginal effects. Default is lead=1.
        '''
        if filter_dic is None: 
            filter_dic = {}

        if lead is None:
            lead = self.total_leads[0]

        eff_sub = self.filter(filter_dic, impacted_leads=lead, impacting_leads=lead)

        col_items = eff_sub.mfx.columns.get_level_values(self._competition_col)
        index_items = eff_sub.mfx.index.get_level_values(self._competition_col)

        #lk = []
        y = 0
        elast = []
        for item in col_items:
            x = np.where(index_items == item)[0][0]
            elast.append([eff_sub.mfx.iloc[x, y], eff_sub._mfx_se.iloc[x, y]])
            y += 1

        return pd.DataFrame(elast, index=eff_sub.mfx.columns, columns=['mfx', 'mfx_se'])      


    def get_pull_forward_path(self, filter_dic, lead):
        '''
        Get path of pull forward effects

        :param filter_dic: dictionary mapping from column levels to acceptable values
        :param lead: lead used to select marginal effects
        '''

        eff_sub = self.filter(filter_dic, impacted_leads=lead)

        if len(eff_sub.mfx.columns.values) != 1:
            raise Exception('Not a unique product')
        else:
            pf_path = eff_sub.mfx.loc[ \
                PdMultiIndexEx.get_1level_block_indicator(eff_sub.mfx.index, self._competition_col, 
                                                          [filter_dic[self._competition_col]]), :]


        return pf_path


