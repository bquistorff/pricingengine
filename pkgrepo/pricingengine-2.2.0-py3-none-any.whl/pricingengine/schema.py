#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
# 
#------------------------------------------------------------------------
from enum import Enum
import numpy as np
import msecore.verify as verify
from msecore.mseexception import MseException

class DataType(Enum):
    """
    Machine-learning category of column type (i.e., to handle cases where a column of ints may actually
    represent categorical data)
    """
    #Note: We don't use Pandas' Categorical type. It apparantely has some issues with numpy
    #https://pandas.pydata.org/pandas-docs/stable/categorical.html#categorical-is-not-a-numpy-array

    # STRING = 1 -> Not yet supported
    NUMERIC = 2
    CATEGORICAL = 3
    DATE_TIME = 4

    @staticmethod
    def is_supported_dtype(data_type, dtype):
        """
        Determine if the specifed data type is supported for the given DataType

        :param DataType data_type: The type of the column
        :param dtype dtype: The underlying data type of values contained in the column
        """
        verify.not_none(data_type, "data_type")
        verify.not_none(dtype, "dtype")
        verify.istype(data_type, DataType)
        verify.istype(dtype, np.dtype)

        data_type_to_dtype = {
            DataType.NUMERIC : set([np.float, np.int, np.uint8, np.uint16, np.uint32, np.uint64]),
            DataType.CATEGORICAL : set([np.object, np.str, np.int, np.uint8, np.uint16, np.uint32, np.uint64]),
            DataType.DATE_TIME : set([np.datetime64, np.int, np.uint8, np.uint16, np.uint32, np.uint64])
        }
        return any([np.issubdtype(dtype, x) for x in data_type_to_dtype[data_type]])

    @staticmethod
    def verify_is_supported_dtype(data_type, dtype):
        '''
        Check if dtype is supported for data_type
        '''
        if not DataType.is_supported_dtype(data_type, dtype):
            raise SchemaValidationException(SchemaValidationError.UnsupportedDType, 
                                            "{0} not supported for {1}".format(dtype, data_type))
        
class ColDef:
    '''
    Class used to define name and type of each column of data. Will typically reside in a Schema object
    '''
    def __init__(self, col_name, data_type, col_type=None):
        """
        :param str col_name: Name of the column
        :param DataType data_type: Type of the column
        :param ColType col_tag: Additional meta data specifying the feature category of the column
        """
        verify.not_none_or_empty(col_name, "col_name")
        verify.istype(col_name, np.str)

        verify.not_none(data_type, "data_type")
        verify.istype(data_type, DataType)

        if not col_type is None:
            verify.istype(col_type, Enum)


        self.__col_name = col_name
        self.__data_type = data_type
        self.__col_type = col_type

    def __eq__(self, other):
        return self.col_name == other.col_name and self.data_type == other.data_type and self.col_type == other.col_type

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return "%s(%r, %s, %s)" % (self.__class__.__name__, self.__col_name, self.__data_type, self.__col_type)

    @property
    def col_name(self):
        """
        The name of this column

        :return: The name of this column
        :rtype: str
        """
        return self.__col_name

    @property
    def data_type(self):
        """
        The datatype of this column

        :return: The type of this column
        :rtype: DataType
        """
        return self.__data_type

    @property
    def col_type(self):
        """
        The type for this column

        :return: The id for this column
        :rtype: ColType
        """
        return self.__col_type

class Schema:

    """
    Specifies the column information for a corresponding data set

    The schema must adhere to the following expectations:

    - Each column id can be applied to only a single column
    - Each column name can only be applied to a single column
    """
    

    def __init__(self, col_defs, time_colname=None, panel_colnames=None):
        """
        Created a new instance of a Schema

        :param list col_defs: A list of column ColDef objects specifying the columns in a time series
        :param str time_colname: Col name that corresponds to the time variable
        :param list panel_col_names: Column names which divide the data into time series, or None if
                                the data contains only a single time series.
        """
        verify.not_none_or_empty(col_defs, "col_defs")
        verify.is_list_oftype(col_defs, ColDef)

        panel_colnames = panel_colnames if not panel_colnames is None else []
        verify.is_list_oftype(panel_colnames, np.str)

        # Verify column names are unique
        col_names = [x.col_name for x in col_defs]
        verify.unique_values(col_names, "col_name")

        self.__col_defs = col_defs
        self.__name_to_col = {col.col_name : col for  col in self.__col_defs}
        self.__coltype_to_col = {col.col_type : col for  col in self.__col_defs}
        self.__panel_col_names = panel_colnames
        self.__time_col_name = time_colname
        self.__col_names = [col.col_name for col in self.__col_defs]

        # Verify panel columns are defined in the set of column definitions
        for required_name in panel_colnames:
            if not required_name in self.__name_to_col:
                raise SchemaValidationException(SchemaValidationError.NoSuchColumn, required_name)
        for required_name in panel_colnames:
            if self.__name_to_col[required_name].data_type != DataType.CATEGORICAL:
                raise SchemaValidationException(SchemaValidationError.IncorrectColumnType, required_name)
        if time_colname is not None and not time_colname in self.__name_to_col:
            raise SchemaValidationException(SchemaValidationError.NoSuchColumn, time_colname)
        #if time_colname is not None and self.__name_to_col[time_colname].data_type != DataType.DATE_TIME:
        #    raise SchemaValidationException(SchemaValidationError.IncorrectColumnType, time_colname)

    def __eq__(self, other):

        # Ensure indexes are the same columns in the same order
        if not self.get_panel_col_names() == other.get_panel_col_names():
            return False
        
        if not self.get_time_col_name() == other.get_time_col_name():
            return False

        # Ensure the same number of columns
        if not len(self.get_col_names()) == len(other.get_col_names()):
            return False

        # Ensure columns have same names and definitions
        names = self.__col_names
        self_col_defs = [self.get_coldef_byname(name) for name in names]
        other_col_defs = [other.get_coldef_byname(name) for name in names]
        return self_col_defs == other_col_defs

    def __ne__(self, other):
        return not self == other

    def __repr__(self):
        return "%s(%r, %r, %r)" % (self.__class__.__name__, self.__col_defs, self.__time_col_name, 
                                   self.__panel_col_names)

    def get_col_names(self):
        """
        Get a list of the names of all columns specified in the schema

        :return: A list of column names
        """
        return self.__col_names.copy()

    def get_coldef_byname(self, col_name):
        """
        Get the definition of the column with the specified name or None if there is no such column

        :param col_name: the column name for which to find the column
        :return: The column with the specified name
        :rtype: str
        """
        return self.__name_to_col[col_name]

    def get_coldef_bycoltype(self, col_type):
        """
        Get the definition of the column with the specified id or None if there is no such column

        :param col_type: the ColType for which to find the column
        :return: The name of the column with the specified id
        :rtype: str
        """
        return self.__coltype_to_col[col_type]

    def get_colname_bycoltype(self, col_type):
        """
        Get the name of the column with the specified id or None if there is no such column

        :param col_type: the ColType for which to find the column
        :return: The name of the column with the specified id
        :rtype: str
        """
        return self.__coltype_to_col[col_type].col_name

    def get_colnames_bydatatype(self, data_type):
        """
        Get the list of column names, or an empty list, of the column of the specified type

        :param data_type: the DataType for which to find columns
        :return: A list of column names for columns of the specified data type
        """
        col_names = [col_name for col_name in self.__col_names if self.__name_to_col[col_name].data_type == data_type]
        return col_names

    def get_colnames_bycoltype(self, col_type):
        """
        Get the list of column names, or an empty list, of the column of the specified type

        :param col_type: the ColType for which to find columns
        :return: A list of column names for columns of the specified data type
        """
        col_names = [col_name for col_name in self.__col_names if self.__name_to_col[col_name].col_type == col_type]
        return col_names



    def get_col_defs(self):
        """
        Get the list of column definitions

        :return: A list of the column definitions for this schema
        """
        return self.__col_defs

    def get_panel_col_names(self):
        """
        Get the list of index columns, or an empty list if the time series corresponds to a single panel

        :return: A list of the names of the columns that are index columns
        """
        return self.__panel_col_names.copy()
    
    def get_time_col_name(self):
        '''
        Get col_name corresponding to TIME var
        '''

        return self.__time_col_name


    def get_col_types(self):
        """
        Get a list of all the ColTypes defined in the schema

        :return: A list of the ColTypes defined in the schmea
        """
        return self.__coltype_to_col.keys()

class SchemaValidationError(Enum):
    """
        Schema Validation Errors
    """
    NoError = 0
    UnsupportedDType = 1
    SchemaMismatch = 2
    NoSuchColumn = 3
    NoSuchColumnDef = 4
    IncorrectColumnType = 5
    DuplicateColType = 6
    DuplicateColName = 7

class SchemaValidationException(MseException):
    """
        Exception thrown when schema validation fails
    """
    def __init__(self, error, message=None):
        super().__init__(error, message)
