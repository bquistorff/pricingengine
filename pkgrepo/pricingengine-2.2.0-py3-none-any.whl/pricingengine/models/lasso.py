#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import warnings

import pandas as pd
import numpy as np
import sklearn
from sklearn import linear_model
from .linearmodel import LinearModel
from .causalmodel import CausalModel

class LassoCV(CausalModel):
    '''
    Wrapper to sci-kit learn LassoCV model
    '''
    def __init__(self, tol=.0001, max_iter=1000):
        super().__init__()
        self.__model = linear_model.LassoCV(max_iter=max_iter, tol=tol)
        self._variance = None

    def __repr__(self):
        '''
        Not usable as instantiation
        '''
        return "%s: %r" % (self.__class__.__name__, self.__model)

    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y)
        #Don't use cluster groups
        #with warnings.catch_warnings():
        #    warnings.simplefilter("ignore", category=sklearn.exceptions.ConvergenceWarning)
        self.__model.fit(mtx_x, vec_y)
        k = np.shape(mtx_x)[1]
        self._variance = np.full((k, k), np.nan)

    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x).reshape(mtx_x.shape[0], )

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coeff = self.__model.coef_
        columns = self._x_column_index
        return pd.DataFrame([coeff], columns=columns)


    def get_standard_errors(self):
        '''
        Return the coefficients of the computed model
        '''
        standard_error = np.sqrt(np.diag(self._variance))
        columns = self._x_column_index
        standard_error[standard_error == 0] = float("nan")
        return pd.DataFrame([standard_error], columns=columns)

    @property
    def variance(self):
        '''
        Return the underlying results object (contains more statistical properties)
        '''
        return self._variance

    def get_variance_matrix(self):
        '''
        Return the standard errors of the computed model
        '''
        columns = self._x_column_index
        return pd.DataFrame(self.variance, columns=columns, index=columns)


class Lasso(LinearModel):
    '''
    Wrapper to sci-kit learn Lasso model
    '''
    #Eventually could allow data-drive penalty (algo A.21) from
    # BELLONI CHERNOZHUKOV HANSE (2012) 
    #  SPARSE MODELS AND METHODS FOR OPTIMAL INSTRUMENTS WIT AN APPLICATION TO EMINENT DOMAIN
    #  https://arxiv.org/pdf/1010.4345.pdf
    def __init__(self, alpha=1.0):
        super().__init__()
        self.__model = linear_model.Lasso(alpha=alpha)

    def _fit(self, mtx_x, vec_y):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y)
        return self.__model.fit(mtx_x, vec_y)

    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x)

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coeff = self.__model.coef_
        columns = self._x_column_index
        return pd.DataFrame([coeff], columns=columns)


