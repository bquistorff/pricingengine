#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import warnings

import numpy as np
import pandas as pd
#The pandas.core.datetools module is deprecated and will be removed in a 
#future version. Please use the pandas.tseries module instead.
with warnings.catch_warnings():
    warnings.simplefilter("ignore", category=FutureWarning)
    import statsmodels.api as sm

from msecore import verify
from msecoreml.pddataframeex import PdDataframeEx
from .model import Model, SampleSplitModel
from .prepredicted import SSPrePredicted
from .ols import OLS


class CrossFitContainer(SampleSplitModel):
    '''
    A convenient way to store separate copies of the same model that are trained on different folds of data.
    Often they are models of the same class.
    The MSE is out-of-sample.
    '''

    def __init__(self, base_models):
        super().__init__(len(base_models))
        self._base_models = base_models

    def __repr__(self):
        return "%s(%r)" % (self.__class__.__name__, self._base_models)

    @staticmethod
    def wrap_single_model_if_needed(base_model, n_folds):
        if isinstance(base_model, SampleSplitModel):
            if not isinstance(base_model, SSPrePredicted): #They don't know the num splits
                verify.equals(base_model.num_splits, n_folds, "Passed in SSModel with wrong # of splits")
            return base_model
        else:
            from copy import deepcopy
            return CrossFitContainer([deepcopy(base_model) for i in range(n_folds)])

    @staticmethod
    def wrap_generic_if_needed(base_model, n_folds):
        if isinstance(base_model, list):
            verify.equals(len(base_model), n_folds, "SSModel: n_folds at fit() not same as __init__().")
            return CrossFitContainer(base_model)
        else:
            return CrossFitContainer.wrap_single_model_if_needed(base_model, n_folds)

    @property
    def base_models(self):
        '''
        Access list of base models
        '''
        return self._base_models

    def _fit(self, x, y, folds):
        verify.equals(len(folds), self.num_splits, "SSModel: n_folds at fit() not same as __init__().")
        for i, (train, _) in enumerate(folds):
            x_train = SampleSplitModel._subset_row_data(x, train)
            y_train = SampleSplitModel._subset_row_data(y, train)
            SampleSplitModel._add_fold_to_pd_colnames(y_train, i)
            self._base_models[i].fit(x_train, y_train)
        
    def _predict(self, x, folds=None):
        '''
        This will have each fold's model predict out over the test set (or whole if folds=None)
        '''
        if folds is not None:
            verify.equals(len(folds), self.num_splits, "SSModel: n_folds at fit() not same as __init__().")
        #if isinstance(x, (pd.DataFrame, pd.Series)):
        #    preds = pd.DataFrame(index=x.index)
        #else:
        if self.n_tasks == 1:
            preds = np.full([x.shape[0], self.num_splits], np.nan)
        else:
            preds = np.full([x.shape[0], self.n_tasks, self.num_splits], np.nan)

        for i, model in enumerate(self._base_models):
            if folds is None:
                x_to_use = x
            else:
                _, test = folds[i]
                x_to_use = SampleSplitModel._subset_row_data(x, test)
            p = model.predict(x_to_use)
            #if isinstance(x, (pd.DataFrame, pd.Series)):
            #    preds[i] = p
            #else:
            if self.n_tasks == 1:
                if folds is None:
                    preds[:, i] = p
                else:
                    preds[test, i] = p
            else:
                if folds is None:
                    preds[:, :, i] = p
                else:
                    preds[test, :, i] = p
        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=RuntimeWarning)  #mean of empty slice
            pred = np.nanmean(preds, axis=len(preds.shape)-1)

        return pred

    def _fit_and_predict(self, x, y, folds):
        '''
        A combined fit and predict that might be a bit more data efficient
        '''
        verify.equals(len(folds), self.num_splits, "SSModel: n_folds at fit() not same as __init__().")
        #if isinstance(x, (pd.DataFrame, pd.Series)):
        #    preds = pd.DataFrame(index=x.index)
        #else:
        if self.n_tasks == 1:
            preds = np.full([x.shape[0], self.num_splits], np.nan)
        else:
            preds = np.full([x.shape[0], self.n_tasks, self.num_splits], np.nan)

        for i, (train, test) in enumerate(folds):
            x_test = SampleSplitModel._subset_row_data(x, test)
            x_train = SampleSplitModel._subset_row_data(x, train)
            y_train = SampleSplitModel._subset_row_data(y, train)
            SampleSplitModel._add_fold_to_pd_colnames(y_train, i)

            self._base_models[i].fit(x_train, y_train)
            p = self._base_models[i].predict(x_test)
            if self.n_tasks == 1:
                preds[test, i] = p
            else:
                preds[test, :, i] = p

        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=RuntimeWarning)  #mean of empty slice
            y_pred = np.nanmean(preds, axis=len(preds.shape)-1)
        return y_pred

    def get_feature_info(self, avg_splits=False):
        '''
        Returns a df with rows as folds/splits and columns for each variable
        '''
        if avg_splits:
            return pd.concat((m.get_coefficients() for m in self._base_models)).mean()

        model = self._base_models[0]
        m_features_weights = model.get_coefficients()
        for split in range(1, self.num_splits):
            new_row = self._base_models[split].get_coefficients()
            m_features_weights = pd.concat([m_features_weights, new_row], ignore_index=True)
        if avg_splits:
            m_features_weights = m_features_weights.groupby(lambda x: 0).mean()
        else:
            m_features_weights.index.name = SampleSplitModel.FOLD_COLNAME
        return m_features_weights




class StackedSS(SampleSplitModel):
    '''
    Stacked Generalization (stacking) is weighting submodels by doing a regression of 
    output on the models' OOS predictions.
    Some of the literature does this via a leave-one-out predictions but we do it off of out-of-fold predictions
    (NB: A "committee" would be equal weights)
    The "Ensemble" model from CCDDHNR 2017 is StackedSS([Lasso, BoostedTrees, RandomForest, NeuralNet], 5, True)
    The MSE is in-sample.
    For multi-task learning assumes equal weights among outcomes
    '''
    def __init__(self, models, num_splits, norm_weights_one=False):
        super().__init__(num_splits)
        self.__models = models
        self.__weights = None
        self.__norm_weights_one = norm_weights_one

    def __repr__(self):
        return "%s(%r, %s, %s)" % (self.__class__.__name__, self.__models, self.__num_splits, self.__norm_weights_one)

    def _fit(self, x, y, folds):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(x, y, folds)
        preds_flat = pd.DataFrame()
        for i, model in enumerate(self.__models):
            model.fit(x, y, folds=folds)
            p = model.predict(x, folds=folds)
            if self.n_tasks > 1:
                preds_flat[i] = Model.get_flat_array(p)
            else:
                preds_flat[i] = p

        y_to_reg = y
        if self.n_tasks > 1:
            y_to_reg = Model.get_flat_array(y_to_reg)
        ols = sm.OLS(y_to_reg, preds_flat, hasconst=False)
        ols_result = ols.fit()
        self.__weights = ols_result.params

        if self.__norm_weights_one:
            self.__weights = self.__weights / sum(self.__weights)

    def _predict(self, x, folds=None):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(x, folds=folds)
        if self.n_tasks == 1:
            preds = np.full([x.shape[0], len(self.__models)], np.nan)
        else:
            preds = np.full([x.shape[0], self.n_tasks, len(self.__models)], np.nan)
        for i, model in enumerate(self.__models):
            p = model.predict(x, folds=folds)
            p *= self.__weights[i]
            if self.n_tasks == 1:
                preds[:, i] = p
            else:
                preds[:, :, i] = p
        
        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=RuntimeWarning)  #mean of empty slice
            pred = np.nanmean(preds, axis=len(preds.shape)-1)
        return pred
    
    def _fit_and_predict(self, x, y, folds):
        #Don't call super()._fit_and_predict
        
        #fit (save preds_dict)
        preds_dict = {}
        preds_flat = pd.DataFrame()
        for i, model in enumerate(self.__models):
            model.fit(x, y, folds)
            p = model.predict(x, folds=folds)
            if self.n_tasks > 1:
                preds_flat[i] = Model.get_flat_array(p)
            else:
                preds_flat[i] = p
            preds_dict[i] = p
            
        y_to_reg = y
        if self.n_tasks > 1:
            y_to_reg = Model.get_flat_array(y_to_reg)
        ols = sm.OLS(y_to_reg, preds_flat, hasconst=False)
        ols_result = ols.fit()
        self.__weights = ols_result.params

        if self.__norm_weights_one:
            self.__weights = self.__weights / sum(self.__weights)
            
        #predict (using preds_dict)
        if self.n_tasks == 1:
            preds = np.full([x.shape[0], len(self.__models)], np.nan)
        else:
            preds = np.full([x.shape[0], self.n_tasks, len(self.__models)], np.nan)
        for i, model in enumerate(self.__models):
            p = preds_dict[i]
            p *= self.__weights[i]
            if self.n_tasks == 1:
                preds[:, i] = p
            else:
                preds[:, :, i] = p
            
        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=RuntimeWarning)  #mean of empty slice
            pred = np.nanmean(preds, axis=len(preds.shape)-1)
            
        return pred


class BucketSS(SampleSplitModel):
    '''
    Bucket of Models is just picking the one best model via submodel MSE.
    The final MSE is in-sample.
    '''
    def __init__(self, models, num_splits):
        super().__init__(num_splits)
        self.__models = models
        self.__best_idx = None

    def __repr__(self):
        return "%s(%r, %s)" % (self.__class__.__name__, self.__models, self.__num_splits)

    @staticmethod
    def gen_best_ensemble(models, num_splits, norm_weights_one=False):
        '''
        The "Best" model from CCDDHNR 2017 is gen_best_ensemble([Lasso, BoostedTrees, RandomForest, NeuralNet], 5, True)
        '''
        return BucketSS(models+[StackedSS(models, num_splits, norm_weights_one=norm_weights_one)], num_splits)

    def _fit(self, x, y, folds):
        super()._fit(x, y, folds)
        fit_diags = []
        for model in self.__models:
            model.fit_and_predict(x, y, folds)
            fit_diags.append(model.mse)

        self.__best_idx = fit_diags.index(min(fit_diags))
        #Could delete the other models to free up memory

    def _predict(self, x, folds=None):
        super()._predict(x, folds)
        return self.__models[self.__best_idx].predict(x, folds=folds)

    
    def _fit_and_predict(self, x, y, folds):
        #Don't call super()._fit_and_predict
        for i, model in enumerate(self.__models):
            y_predict = model.fit_and_predict(x, y, folds)
            if i == 0 or model.mse < curr_best_mse: #pylint: disable=used-before-assignment
                curr_best_idx = i
                curr_best_predict = y_predict
                curr_best_mse = model.mse

        self.__best_idx = curr_best_idx
        #Could delete the other models to free up memory
        
        return curr_best_predict
