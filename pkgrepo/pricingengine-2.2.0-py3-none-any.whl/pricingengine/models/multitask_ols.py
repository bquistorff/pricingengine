#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import numpy as np
from .model import Model
from .ols import OLS

class MultiTaskOLS(Model):
    def __init__(self, add_const=False):
        super().__init__()
        self._n_tasks = None
        self.__model = OLS(add_const=add_const)

    def _fit(self, x, y):
        super()._fit(x, y)
        self._n_tasks = y.shape[1]
        if self._n_tasks > 1:
            vec_y_avg = y.mean(axis=1)
        else:
            vec_y_avg = y
        return self.__model.fit(x, vec_y_avg)

    def _predict(self, x):
        super()._predict(x)
        pred1d = self.__model.predict(x)
        pred2d_degenerate = np.expand_dims(pred1d, 1)
        pred2d_rep = np.repeat(pred2d_degenerate, 2, axis=1)
        return pred2d_rep
