#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from abc import abstractmethod
from .model import Model

class LinearModel(Model):
    '''
    Abstact base class for all linear models
    '''
    COEF_NAME = "coef"
    def __init__(self):
        super().__init__()

    @abstractmethod
    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        pass
