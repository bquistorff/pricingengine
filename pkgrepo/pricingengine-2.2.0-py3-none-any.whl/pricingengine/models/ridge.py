#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
from sklearn import linear_model
from .causalmodel import CausalModel

class RidgeCV(CausalModel):
    ALPHA_MIN = .00000001
    ALPHA_MAX = 999999
    '''
    Wrapper to sci-kit learn RidgeCV model
    '''
    def __init__(self):
        super().__init__()
        self.__model = linear_model.RidgeCV(alphas=[np.exp(j*.2) for j in range(-10, 11)])
        self._variance = None
        self._regularization = None
       
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y, cluster_groups)
        tmp = self.__model.fit(mtx_x, vec_y)
        while (tmp.alpha_ == min(tmp.alphas) and tmp.alpha_ > RidgeCV.ALPHA_MIN) or \
            (tmp.alpha_ == max(tmp.alphas) and tmp.alpha_ < RidgeCV.ALPHA_MAX):
            if tmp.alpha_ == min(tmp.alphas):
                alphas = [np.median(tmp.alphas) * np.exp(j * .2) for j in range(-20, 1)]
                self.__model = linear_model.RidgeCV(alphas=alphas)
            else:
                alphas = [np.median(tmp.alphas) * np.exp(j * .2) for j in range(0, 21)]
                self.__model = linear_model.RidgeCV(alphas=alphas)
            tmp = self.__model.fit(mtx_x, vec_y)
        
        self._regularization = 2 * tmp.alpha_

        k = np.shape(mtx_x)[1]
        y_fit = self.__model.predict(mtx_x)
        y_res = vec_y - y_fit

        hessian_inv = np.linalg.inv(np.matmul(np.transpose(mtx_x), mtx_x) + self._regularization * np.eye(k))
        x_escaled = np.transpose(y_res * np.transpose(mtx_x))
        if isinstance(x_escaled, pd.DataFrame):
            x_escaled = x_escaled.values

        if cluster_groups is None:
            score = np.matmul(np.transpose(x_escaled), x_escaled)
        else:
            values, _ = self._sum_by_group(x_escaled, cluster_groups)
            score = np.matrix(np.zeros((k, k)))
            for val in values:
                score += np.transpose(np.matrix(val)) * np.matrix(val)

        self._variance = hessian_inv * score * hessian_inv 

    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x).reshape(mtx_x.shape[0], )

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coeff = self.__model.coef_
        columns = self._x_column_index
        return pd.DataFrame([coeff], columns=columns)

    def get_standard_errors(self):
        '''
        Return the coefficients of the computed model
        '''
        standard_error = np.sqrt(np.diag(self._variance))
        columns = self._x_column_index
        standard_error[standard_error == 0] = float("nan")
        return pd.DataFrame([standard_error], columns=columns)

    @property
    def variance(self):
        '''
        Return the underlying results object (contains more statistical properties)
        '''
        return self._variance

    def get_variance_matrix(self):
        columns = self._x_column_index
        return pd.DataFrame(self.variance, columns=columns, index=columns)


class Ridge(CausalModel):
    ALPHA_MIN = .00000001
    ALPHA_MAX = 999999
    '''
    Wrapper to sci-kit learn RidgeCV model
    '''
    def __init__(self, alpha):
        super().__init__()
        self.__model = linear_model.Ridge(alpha=alpha)
        self._variance = None
        self._regularization = alpha * 2
       
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y, cluster_groups)
        self.__model.fit(mtx_x, vec_y)
       
        

        k = np.shape(mtx_x)[1]
        y_fit = self.__model.predict(mtx_x)
        y_res = vec_y - y_fit

        hessian_inv = np.linalg.inv(np.matmul(np.transpose(mtx_x), mtx_x) + self._regularization * np.eye(k))
        x_escaled = np.transpose(y_res * np.transpose(mtx_x)).values

        if cluster_groups is None:
            score = np.matmul(np.transpose(x_escaled), x_escaled)
        else:
            values, _ = self._sum_by_group(x_escaled, cluster_groups)
            score = np.matrix(np.zeros((k, k)))
            for val in values:
                score += np.transpose(np.matrix(val)) * np.matrix(val)

        self._variance = hessian_inv * score * hessian_inv 

    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x).reshape(mtx_x.shape[0], )

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coeff = self.__model.coef_
        columns = self._x_column_index
        return pd.DataFrame([coeff], columns=columns)

    def get_standard_errors(self):
        '''
        Return the coefficients of the computed model
        '''
        standard_error = np.sqrt(np.diag(self._variance))
        columns = self._x_column_index
        standard_error[standard_error == 0] = float("nan")
        return pd.DataFrame([standard_error], columns=columns)

    @property
    def variance(self):
        '''
        Return the underlying results object (contains more statistical properties)
        '''
        return self._variance


    def get_variance_matrix(self):
        columns = self._x_column_index
        return pd.DataFrame(self.variance, columns=columns, index=columns)
