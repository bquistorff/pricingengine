#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
import scipy as sp

from sklearn import linear_model
from .causalmodel import CausalModel
from .lasso import LassoCV
#pylint: disable=cell-var-from-loop, redefined-variable-type, line-too-long
class DebiasedLasso(CausalModel):
    '''
    Wrapper to sci-kit learn LassoCV model
    '''
    def __init__(self, allowed_bias=None, lasso_tol=.001):
        super().__init__()
        self.__model_one = LassoCV(tol=lasso_tol)
        self._allowed_bias = allowed_bias
        self._variance = None
        self._beta = None
        self._beta1 = None
        self._beta2 = None
        self._cols_to_keep = None
        self._dropped_cols = None
    
    @staticmethod
    def _obj_func(guess):
        return np.sum(abs(guess))
        #return np.sum(np.sqrt(np.power((guess), 2) + .000001)) - np.sqrt(.000001) * len(guess)
    
    @staticmethod
    def _obj_gradient(guess):
        return 1 - 2 * (guess < 0)

    @staticmethod
    def _constraint(guess, hessian, obj):
        col_diff = np.array([np.dot(guess, np.transpose(np.array(q)))[0] for q in hessian]) - obj
        return np.sum(abs(col_diff))
        #return np.max(abs(col_diff))

    @staticmethod
    def _constraint_gradient(guess, hessian, obj):
        col_diff = np.array([np.dot(guess, np.transpose(np.array(q)))[0] for q in hessian]) - obj
        return np.sum([np.array(hessian[p])[0] * (1 - 2 * (col_diff[p] < 0)) for p in range(len(hessian))], axis=0)

    @staticmethod
    def _get_reg_hess_inv(hessian, allowed_bias):
        reg_hess_inv = hessian.copy()
        [k, _] = np.shape(hessian)
        try:
            hess_inv = np.linalg.inv(hessian)
        except:
            print('Singular Matrix')
            hess_inv = np.linalg.pinv(hessian)
        obj_matrix = np.eye(k)
        for col_index in range(k):
            obj = obj_matrix[col_index]
            guess = (np.array(hess_inv[col_index])[0])

            res = sp.optimize.minimize(DebiasedLasso._obj_func,
                                       guess, 
                                       jac=DebiasedLasso._obj_gradient,
                                       constraints=({'type': 'ineq', 
                                                     'fun': lambda x: allowed_bias - DebiasedLasso._constraint(x, hessian, obj),
                                                     'jac': lambda x: -DebiasedLasso._constraint_gradient(x, hessian, obj)}),
                                       options={'maxiter': 10000})

            if not res.success:
                print(res)
                raise Exception('Optimization Failed')
            reg_hess_inv[col_index] = res.x

        return reg_hess_inv
       
    def _prune_columns(self, mtx_x):
        self._cols_to_keep = (mtx_x != 0).any(axis=0)
        self._dropped_cols = mtx_x.columns[(mtx_x == 0).all(axis=0)]
        return mtx_x.loc[:, self._cols_to_keep]
    
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y)
        mtx_x = self._prune_columns(mtx_x)

        self.__model_one.fit(mtx_x, vec_y)
        err = vec_y - self.__model_one.predict(mtx_x)

        x = np.matrix(mtx_x.values)
        [_, k] = np.shape(x)

        if self._allowed_bias is None:
            self._allowed_bias = .1 #choose bias rule here

        reg_hess_inv = self._get_reg_hess_inv(np.transpose(x) * x, self._allowed_bias)
        
        err = np.matrix(err).transpose()
        beta_2 = reg_hess_inv * (np.transpose(x) * err)
        
        err_2 = err - x * beta_2
        x_escaled = np.array(err_2) * mtx_x.values

        if cluster_groups is None:
            score = np.matmul(np.transpose(x_escaled), x_escaled)
        else:
            values, _ = self._sum_by_group(x_escaled, cluster_groups)
            score = np.matrix(np.zeros((k, k)))
            for val in values:
                score += np.transpose(np.matrix(val)) * np.matrix(val)

        self._variance = reg_hess_inv * score * reg_hess_inv
        self._beta1 = self.__model_one.get_coefficients()
        self._beta2 = pd.DataFrame(np.transpose(beta_2), index=self._beta1.index, columns=self._beta1.columns)
        

    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        mtx_x = mtx_x.loc[:, self._cols_to_keep]

        yh_1 = self.__model_one.predict(mtx_x)
        yh_2 = pd.Series(np.array(np.transpose(np.matmul(mtx_x.values, np.transpose(self._beta2.values)))[0]), index=mtx_x.index)
        return yh_1 + yh_2

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coef = self._beta1.values + self._beta2.values
        coef = np.append(coef[0], [0.0 for j in  range(len(self._dropped_cols))])
        try:
            columns = pd.MultiIndex.from_tuples(np.append(self._beta1.columns, self._dropped_cols), names=self._beta1.columns.names)
        except:
            #native index may be 1-dim (not a tuple)
            columns = pd.Index(np.append(self._beta1.columns, self._dropped_cols))
        return pd.DataFrame([coef], columns=columns)

    def get_standard_errors(self):
        '''
        Return the coefficients of the computed model
        '''
        standard_error = np.sqrt(np.diag(self._variance))
        try:
            columns = pd.MultiIndex.from_tuples(np.append(self._beta1.columns, self._dropped_cols), names=self._dropped_cols.names)
        except:
            columns = pd.Index(np.append(self._beta1.columns, self._dropped_cols))
        standard_error[standard_error == 0] = float("nan")
        standard_error = np.append(standard_error, [0.0  for j in range(len(self._dropped_cols))])
        return pd.DataFrame([standard_error], columns=columns)


    def get_variance_matrix(self):
        columns = pd.MultiIndex.from_tuples(np.append(self._beta1.columns, self._dropped_cols), names=self._dropped_cols.names)
        df = pd.DataFrame(0.0, columns=columns, index=columns)

        df.loc[self._beta1.columns, self._beta1.columns] = self._variance
        return df
