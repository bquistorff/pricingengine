#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
from sklearn import linear_model
from .model import Model
from .ols import OLS

class Zero(Model):
    '''
    Model that always returns fitted values of 0. Residual is then equal to target.
    Used if you don't want to partial out anything from a variable
    '''
    def __init__(self):
        super().__init__()
        self.__model = None
       
    def _fit(self, x, y):
        super()._fit(x, y)
        return None

    def _predict(self, x):
        super()._predict(x)
        data = np.zeros(len(x))
        if isinstance(x, pd.DataFrame):
            data = pd.Series(data, index=x.index)
        return data

class One(Model):
    '''
    Always fits a constant OLS
    '''

    def __init__(self):
        super().__init__()
        self._model = OLS(add_const=True)

    def _fit(self, mtx_x, vec_y):
        super()._fit(mtx_x, vec_y)
        #mtx_x_to_use = []
        mtx_x_to_use = np.empty((mtx_x.shape[0], 0))
        self._model.fit(mtx_x_to_use, vec_y)
        return None

    def _predict(self, mtx_x):
        super()._predict(mtx_x)
        #mtx_x_to_use = []
        mtx_x_to_use = np.empty((mtx_x.shape[0], 0))
        return self._model.predict(mtx_x_to_use)
