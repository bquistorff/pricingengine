#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from abc import ABCMeta, abstractmethod
from copy import deepcopy

import pandas as pd
import numpy as np

from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdseriesex import PdSeriesEx
from msecoreml.mlexception import MLException, MLErrorCode
from msecoreml.sample_splitting import SampleSplitting
from msecore import verify
from msecore.numpyex import howsimilar


class Model(metaclass=ABCMeta):
    '''
    Abstract base class for all basic models. 
    Will handle:
    * removing non-complete observations
    * making sure return type has appropriate container (e.g. Panda's index)
    * type checks
    '''
    VARIABLE_COLNAME = "variable"
    PREDICTION_COL_NAME = 'prediction'
    RESIDUAL_COL_NAME = "residual"
    SUBMODEL_COLNAME = "Submodel"
    ONLY_SUBMODEL = "only"
    AVG_ERROR_COL_NAME = 'avg error'
    ERROR_VAR_NAME = 'error'
    MAE_NAME = "MAE"
    MSE_NAME = "MSE"
    SMAPE_NAME = "sMAPE"
    R2_NAME = "R2"
    CONST_NAME = 'const'

    def __init__(self):
        self._x_column_index = None
        self._y_column_index = None
        self._is_fit = False  
        self._n_tasks = None #1 for normal. >1 for multitask
        self._mae = None
        self._smape = None
        self._mse = None
        self._r2 = None
        self._mean_res_sign = None

    def __repr__(self):
        return "%s()" % (self.__class__.__name__)

    @property
    def x_column_index(self):
        '''
        Return the colum Index/MultiIndex from the training data
        '''
        if not self._is_fit:
            raise MLException(MLErrorCode.ModelNotYetInitialized)
        return self._x_column_index

    @abstractmethod
    def _fit(self, x, y):
        '''
        Model implementation-specific fit method
        '''
        #Don't know if we need these since they're also in fit()
        verify.istype(x, (np.ndarray, pd.Series, pd.DataFrame))
        verify.istype(y, (np.ndarray, pd.Series, pd.DataFrame))

    @abstractmethod
    def _predict(self, x):
        '''
        Model implementation-specific predict method
        '''
        #Don't know if we need this since it's also in predict()
        verify.istype(x, (np.ndarray, pd.Series, pd.DataFrame))
    
    @staticmethod
    def _get_inclusion_mask(x, y=None):
        ind_x = PdDataframeEx.get_nan_inf_indicator(x)
        if isinstance(ind_x, pd.Series):
            ind_x = ind_x.values
        if y is None:
            return ~ind_x
        else:
            ind_y = PdSeriesEx.get_nan_inf_indicator(y)
            if isinstance(ind_y, pd.Series):
                ind_y = ind_y.values
            if len(ind_y.shape) > 1 and ind_y.shape[1] > 1:
                ind_y = np.any(ind_y, axis=1)
            return ~(ind_x | ind_y)

    @staticmethod
    def n_tasks_from_y(y):
        if isinstance(y, (pd.Series, pd.DataFrame)):
            y = y.values
        if len(y.shape) > 1:
            return y.shape[1]
        else:
            return 1

    @staticmethod
    def get_possible_col_index(data):
        if isinstance(data, pd.DataFrame):
            return data.columns
        elif isinstance(data, pd.Series):
            return [data.name]
        return None

    def _fit_setup(self, x, y):
        #Checks
        verify.not_none_or_empty(x, "x")
        verify.not_none_or_empty(y, "y")
        verify.istype(x, (np.ndarray, pd.Series, pd.DataFrame))
        verify.istype(y, (np.ndarray, pd.Series, pd.DataFrame))
        
        if isinstance(x, (pd.Series, pd.DataFrame)) and isinstance(y, (pd.Series, pd.DataFrame)) and \
            not np.array_equal(x.index.values, y.index.values):
            raise MLException(MLErrorCode.RowIndexMismatch)

        #set fit properties
        self._x_column_index = Model.get_possible_col_index(x)
        self._y_column_index = Model.get_possible_col_index(y)
        self._n_tasks = Model.n_tasks_from_y(y)

    def fit(self, x, y):
        '''  
        Fit the model to the given training and target data

        :param x: A Pandas Dataframe of m rows by n columns
        :param y: A Pandas Series of length m
        '''
        self._fit_setup(x, y)

        inclusion_mask = Model._get_inclusion_mask(x, y)
        self._fit(x[inclusion_mask], y[inclusion_mask])
        self._is_fit = True

    @staticmethod
    def wrap_y_if_needed(y, x, name):
        ntasks = Model.n_tasks_from_y(y)
        if isinstance(x, (pd.DataFrame, pd.Series)):
            if ntasks > 1:
                return pd.DataFrame(y, index=x.index)
            else:
                return pd.Series(y, index=x.index, name=name)
        return y
    @staticmethod
    def put_prediction_in_whole(prediction, full_n, inclusion_mask):
        if isinstance(prediction, (pd.DataFrame, pd.Series)):
            prediction = prediction.values
        n_tasks = Model.n_tasks_from_y(prediction)
        if n_tasks > 1:
            ret_values = np.full((full_n, n_tasks), np.nan)
            ret_values[inclusion_mask] = prediction
        else:
            ret_values = np.full((full_n), np.nan)
            ret_values[inclusion_mask] = prediction.flatten()
        return ret_values
    

    @staticmethod
    def get_flat_array(data):
        #data can be np array or pandas object
        if isinstance(data, (pd.Series, pd.DataFrame)):
            data = data.values
        return data.flatten()

    def predict(self, x, y_true=None):
        '''
        Transform the given data using the previously fit model

        :param x: A Pandas Dataframe of k rows and n columns
        :param y_true: If passed in then sets accuracy statistics
        :return: The Pandas series of length k resulting from applying the fit model to the given values
        '''
        verify.not_none_or_empty(x, "x")
        verify.istype(x, (np.ndarray, pd.DataFrame))
        
        if not self._is_fit:
            raise MLException(MLErrorCode.ModelNotYetInitialized)

        #at one point commented this out because seems to be causing a two nans bug
        #if not np.array_equal(np.array(list(self.x_column_index.values)), np.array(list(x.columns.values))): 
        #    raise MLException(MLErrorCode.ColumnIndexMismatch, "x")

        inclusion_mask = Model._get_inclusion_mask(x)

        prediction = self._predict(x[inclusion_mask])

        if y_true is not None:
            self._mae, _, self._mse, self._smape, self._r2 = howsimilar(y_true[inclusion_mask], prediction)
            
        ret_values = Model.put_prediction_in_whole(prediction, x.shape[0], inclusion_mask)
        ret_values = Model.wrap_y_if_needed(ret_values, x, Model.PREDICTION_COL_NAME)
        return ret_values

    def fit_and_predict(self, x, y):
        '''
        A combined fit and predict that might be a bit more data efficient
        Sets accuracy statistics
        Currently, will not predict for observations where outcome is missing

        :param x: matrix of features
        :param y: vector of realized outcomes
        '''
        self._fit_setup(x, y)
        inclusion_mask = Model._get_inclusion_mask(x, y)
        y_valid = y[inclusion_mask]

        prediction = self._fit_and_predict(x[inclusion_mask], y_valid)
        #residual = y - y_predict
        
        self._mae, _, self._mse, self._smape, self._r2 = howsimilar(y_valid, prediction)
            
        self._is_fit = True
        #Fix the output since we don't know output of _fit_and_predict
        ret_values = Model.put_prediction_in_whole(prediction, x.shape[0], inclusion_mask)
        ret_values = Model.wrap_y_if_needed(ret_values, x, Model.PREDICTION_COL_NAME)
        return ret_values

    def _fit_and_predict(self, x, y):
        #Reimplement in base class if there's a more efficient way
        self.fit(x, y)
        y_predict = self.predict(x)
        return y_predict

    def predict_and_residualize(self, x, y):
        '''
        Compute residuals using a prefit model
        Sets accuracy statistics

        :param x: matrix of features
        :param y: vector of realized outcomes
        '''
        verify.not_none_or_empty(x, "x")
        verify.not_none_or_empty(y, "y")
        verify.istype(x, (np.ndarray, pd.Series, pd.DataFrame))
        verify.istype(y, (np.ndarray, pd.Series, pd.DataFrame))
        
        y_predict = self.predict(x)
        residual = y - y_predict

        #inclusion_mask = Model._get_inclusion_mask(x, y)
        #y = y[inclusion_mask]
        #y_predict = y_predict[inclusion_mask]
        self._mae, _, self._mse, self._smape, self._r2 = howsimilar(y, y_predict)
        
        return residual

    def fit_predict_and_residualize(self, x, y):
        '''
        Sets accuracy statistics
        '''
        y_predict = self.fit_and_predict(x, y)
        residual = y - y_predict
        return residual
    
    @property
    def mae(self):
        '''
        mae() Mean Absolute Error. Will ignore NaNs
        '''
        return self._mae
    
    @property
    def smape(self):
        '''
        smape: Symmetric Mean Absolute Percent Error. Use this rather than MAPE as that can be Inf. Will ignore NaNs
        '''

        return self._smape

    @property
    def mse(self):
        '''
        mspe: Mean Squared Error also called mean squared prediction error (mspe). Will ignore NaNs
        '''
        return self._mse

    @property
    def rmse(self):
        '''
        rmspe: Root Mean Squared Error also called root mean squared prediction error (rmspe). Will ignore NaNs
        '''
        return np.sqrt(self._mse)

    @property
    def coeff_of_determination(self):
        '''
        r^2/R^2: Coefficient of determination . Will ignore NaNs
        '''
        return self._r2

    #@property
    #def mean_dir_res(self):
    #    '''
    #    mean_dir_res_bias: Mean direction of the Residual (+1 for truth above prediction, 
    #      and -1 for truth below prediction). Will ignore NaNs
    #    '''
    #    return self._mean_res_sign

    #@property
    #def mean_dir_pred(self):
    #    '''
    #    mean_dir_pred: Mean direction of the Prediction (+1 for prediction above truth, and -1 for 
    #        prediction below truth). Will ignore NaNs
    #    This is -1 * mean_dir_res
    #    '''
    #    return -1*self._mean_res_sign

    @property
    def n_tasks(self):
        '''
        Returns the number of "tasks". 1 indicates standard estimation. More indicates multi-task
        '''
        return self._n_tasks

    def copy(self):
        '''
        Return a copy of the model object
        '''
        return deepcopy(self)

class SampleSplitModel(metaclass=ABCMeta):
    '''
    ABC for models that keep track of what parts of data were used for fitting certain components.
    The most common case is that you have several ML models that fit on one section and then
    are used to predict out on another.
    Will handle:
    * removing non-complete observations
    * making sure return type has appropriate container (e.g. Panda's index)
    * type checks
    '''
    FOLD_COLNAME = "fold"
    NO_SPLIT = 'no split'
    RECORDER_TRAININGON_NAME = "trainingOn"

    def __init__(self, num_splits):
        self._x_column_index = None
        self._y_column_index = None
        self._is_fit = False
        self.__num_splits = num_splits
        self._n_tasks = None #1 for normal. >1 for multitask
        self._mae = None
        self._smape = None
        self._mse = None
        self._r2 = None
        self._mean_res_sign = None

    def __repr__(self):
        return "%s(%r)" % (self.__class__.__name__, self.__num_splits)

    @property
    def x_column_index(self):
        '''
        Return the colum Index/MultiIndex from the training data
        '''
        if not self._is_fit:
            raise MLException(MLErrorCode.ModelNotYetInitialized)
        return self._x_column_index

    @property
    def num_splits(self):
        '''
        Number of divisions into which to split data for computing residuals
        '''
        return self.__num_splits
    
    @property
    def mae(self):
        '''
        mae() Mean Absolute Error. Will ignore NaNs
        '''
        return self._mae
    
    @property
    def smape(self):
        '''
        smape: Symmetric Mean Absolute Percent Error. Use this rather than MAPE as that can be Inf. Will ignore NaNs
        '''

        return self._smape

    @property
    def mse(self):
        '''
        mspe: Mean Squared Error also called mean squared prediction error (mspe). Will ignore NaNs
        '''
        return self._mse

    @property
    def rmse(self):
        '''
        rmspe: Root Mean Squared Error also called root mean squared prediction error (rmspe). Will ignore NaNs
        '''
        return np.sqrt(self._mse)

    @property
    def coeff_of_determination(self):
        '''
        r^2/R^2: Coefficient of determination . Will ignore NaNs
        '''
        return self._r2

    @property
    def n_tasks(self):
        '''
        Returns the number of "tasks". 1 indicates standard estimation. More indicates multi-task
        '''
        return self._n_tasks

    def _fit_setup(self, x, y):
        verify.not_none_or_empty(x, "x")
        verify.not_none_or_empty(y, "y")
        verify.istype(x, (np.ndarray, pd.Series, pd.DataFrame))
        verify.istype(y, (np.ndarray, pd.Series, pd.DataFrame))
        
        if isinstance(x, (pd.Series, pd.DataFrame)) and isinstance(y, (pd.Series, pd.DataFrame)):
            if not np.array_equal(x.index.values, y.index.values):
                raise MLException(MLErrorCode.RowIndexMismatch)
        self._x_column_index = Model.get_possible_col_index(x)
        self._y_column_index = Model.get_possible_col_index(y)
            
        self._n_tasks = Model.n_tasks_from_y(y)
    
    def fit(self, x, y, folds):
        '''  
        Fit the model to the given training and target data

        :param x: A Pandas Dataframe of m rows by n columns
        :param y: A Pandas Series of length m
        :param folds:
        '''
        self._fit_setup(x, y)

        inclusion_mask = Model._get_inclusion_mask(x, y) #pylint: disable=protected-access
        #Figure out the inclusion mask
        folds_valid = SampleSplitting.filter_folds(inclusion_mask, folds)
        self._fit(x[inclusion_mask], y[inclusion_mask], folds_valid)
        self._is_fit = True
    
    @abstractmethod
    def _fit(self, x, y, folds):
        pass
        
    def predict(self, x, folds=None, y_true=None):
        '''
        :param x:
        :param folds: If none, then assumes that none of this data was used for fitting.
        :param y_true: If passed in then sets accuracy statistics
        '''
        verify.not_none_or_empty(x, "x")
        verify.istype(x, (np.ndarray, pd.DataFrame))
        
        if not self._is_fit:
            raise MLException(MLErrorCode.ModelNotYetInitialized)
        
        inclusion_mask = Model._get_inclusion_mask(x) #pylint: disable=protected-access

        folds_valid = SampleSplitting.filter_folds(inclusion_mask, folds)
        prediction = self._predict(x[inclusion_mask], folds_valid)

        if y_true is not None:
            self._mae, _, self._mse, self._smape, self._r2 = howsimilar(y_true[inclusion_mask], prediction)

        ret_values = Model.put_prediction_in_whole(prediction, x.shape[0], inclusion_mask)
        ret_values = Model.wrap_y_if_needed(ret_values, x, Model.PREDICTION_COL_NAME)
        return ret_values

    @abstractmethod
    def _predict(self, x, folds=None):
        pass

    def fit_and_predict(self, x, y, folds):
        '''
        A combined fit and predict that might be a bit more data efficient
        Sets accuracy statistics
        Currently, will not predict for observations where outcome is missing

        :param x: matrix of features
        :param y: vector of realized outcomes
        :param folds:
        '''
        self._fit_setup(x, y)
        inclusion_mask = Model._get_inclusion_mask(x, y) #pylint: disable=protected-access
        y_valid = y[inclusion_mask]
        folds_valid = SampleSplitting.filter_folds(inclusion_mask, folds)

        prediction = self._fit_and_predict(x[inclusion_mask], y_valid, folds_valid)
        #residual = y - y_predict
        
        self._mae, _, self._mse, self._smape, self._r2 = howsimilar(y_valid, prediction)

        self._is_fit = True
        ret_values = Model.put_prediction_in_whole(prediction, x.shape[0], inclusion_mask)
        #Fix the output since we don't know output of _fit_and_predict
        ret_values = Model.wrap_y_if_needed(ret_values, x, Model.PREDICTION_COL_NAME)
        return ret_values
    
    def _fit_and_predict(self, x, y, folds):
        #Reimplement in base class if there's a more efficient way
        self.fit(x, y, folds)
        ret_values = self.predict(x, folds=folds)
        return ret_values


    def predict_and_residualize(self, x, y, folds=None):
        '''
        Sets accuracy statistics
        '''
        verify.not_none_or_empty(x, "x")
        verify.not_none_or_empty(y, "y")
        verify.istype(x, (np.ndarray, pd.Series, pd.DataFrame))
        verify.istype(y, (np.ndarray, pd.Series, pd.DataFrame))

        y_predict = self.predict(x, folds=folds)
        residual = y - y_predict
        
        #inclusion_mask = Model._get_inclusion_mask(x, y)
        #y = y[inclusion_mask]
        #y_predict = y_predict[inclusion_mask]
        self._mae, _, self._mse, self._smape, self._r2 = howsimilar(y, y_predict)

        return residual
    
    def fit_predict_and_residualize(self, x, y, folds):
        '''
        Sets accuracy statistics
        '''
        y_predict = self.fit_and_predict(x, y, folds=folds)
        residual = y - y_predict
        return residual
    
    @staticmethod
    def fit_and_predict_mult(ssmodels, features, y_multi, folds): #pylint: disable=invalid-name
        '''
        :param dict ssmodels:
        :param dict features:
        :param dict y_multi:
        :param folds:
        '''
        classes = [ssmodel.__class__ for ssmodel in ssmodels.values()]
        #Check if all of same class and has an optimized method
        if len(set(classes)) == 1 and hasattr(classes[0], 'fit_predict_and_residualize_mult'):
            return classes[0].fit_and_predict_mult(ssmodels, features, y_multi, folds)

        #general solution
        predictions_dict = {}
        for varname, ssmodel in ssmodels.items():
            predictions_dict[varname] = ssmodel.fit_and_predict(features[varname], y_multi[varname], folds)
        return pd.concat(predictions_dict, names=[Model.VARIABLE_COLNAME])

    @staticmethod
    def predict_mult(ssmodels, features, folds): #pylint: disable=invalid-name
        '''
        :param dict ssmodels:
        :param dict features:
        :param folds:
        '''
        #general solution
        predictions_dict = {}
        for varname, ssmodel in ssmodels.items():
            predictions_dict[varname] = ssmodel.predict(features[varname], folds)
        return pd.concat(predictions_dict, names=[Model.VARIABLE_COLNAME])

    @staticmethod
    def _add_fold_to_pd_colnames(pd_obj, i):
        if isinstance(pd_obj, pd.Series):
            pd_obj.name += " " + SampleSplitModel.FOLD_COLNAME + str(i)
        elif isinstance(pd_obj, pd.DataFrame):
            pd_obj.columns += " " + SampleSplitModel.FOLD_COLNAME + str(i)

    @staticmethod
    def _subset_row_data(data, index_list):
        if isinstance(data, pd.DataFrame):
            return data.iloc[index_list, :]
        if isinstance(data, pd.Series):
            return data.iloc[index_list]
        if len(data.shape) > 1:
            return data[index_list, :]
        return data[index_list]

    def get_fit_diagnostics(self):
        '''
        return a single-rowed dataframe of MAE, MSE, sMAPE, and R2
        '''
        fit_diagnostics = pd.DataFrame({Model.MAE_NAME:[self.mae], 
                                        Model.MSE_NAME:[self.mse],
                                        Model.SMAPE_NAME:[self.smape],
                                        Model.R2_NAME:[self.coeff_of_determination]})

        #if not avg_splits:
        #    idx = pd.MultiIndex.from_product([range(self.num_splits)], names=[SampleSplitModel.FOLD_COLNAME])
        #    colnames = [Model.MAE_NAME, Model.MSE_NAME, Model.SMAPE_NAME, Model.R2_NAME]
        #    fit_diagnostics = pd.DataFrame(index=idx, columns=colnames, dtype=float)
        #    for split in range(self.num_splits):
        #        model = self._base_models[split]
        #        fit_diagnostics.loc[split] = [model.mae, model.mse, model.smape, model.coeff_of_determination]

        return fit_diagnostics
