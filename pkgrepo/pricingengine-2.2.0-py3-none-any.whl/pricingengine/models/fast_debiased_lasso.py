#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np

from sklearn import linear_model
from .causalmodel import CausalModel
from .ridge import Ridge, RidgeCV
from .lasso import LassoCV

class FastDebiasedLasso(CausalModel):
    '''
    Wrapper to sci-kit learn LassoCV model
    '''
    def __init__(self, lasso_tol=.001):
        super().__init__()
        self.__model_one = LassoCV(tol=lasso_tol)
        self.__model_two = Ridge(alpha=1) #RidgeCV()
        self._hessian_regularization = 0
        self._variance = None
        self._beta = None
       
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y)
        self.__model_one.fit(mtx_x, vec_y)
        err = vec_y - self.__model_one.predict(mtx_x)

        self.__model_two.fit(mtx_x, err, cluster_groups)

        self._variance = self.__model_two.variance
        self._beta = self.__model_one.get_coefficients() + self.__model_two.get_coefficients()


    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        return (self.__model_one.predict(mtx_x) + self.__model_two.predict(mtx_x)).reshape(mtx_x.shape[0], )

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coef = self._beta
        columns = self._x_column_index
        return pd.DataFrame(coef, columns=columns)

    def get_standard_errors(self):
        '''
        Return the coefficients of the computed model
        '''
        standard_error = np.sqrt(np.diag(self._variance))
        columns = self._x_column_index
        standard_error[standard_error == 0] = float("nan")
        return pd.DataFrame([standard_error], columns=columns)


    def get_variance_matrix(self):
        columns = self._x_column_index
        return pd.DataFrame(self._variance, columns=columns, index=columns)
