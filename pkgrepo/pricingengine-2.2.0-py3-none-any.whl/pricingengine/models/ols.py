#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import warnings
import numpy as np
import pandas as pd
try: #pandas 0.20
    from pandas.errors import PerformanceWarning
except: #pandas 0.19
    from pandas.core.common import PerformanceWarning
    
#The pandas.core.datetools module is deprecated and will be removed in a 
#future version. Please use the pandas.tseries module instead.
with warnings.catch_warnings():
    warnings.simplefilter("ignore", category=FutureWarning)
    import statsmodels.api as sm

from .model import Model
from .causalmodel import CausalModel


class OLS(CausalModel):
    '''
    Wrapper to statsmodels's ols model
    '''
    def __init__(self, add_const=False):
        super().__init__()
        
        self._modelres = None
        self._vec_y_len = None
        self._add_const = add_const
        self._model = None

    def __repr__(self):
        return "%s(add_const=%s)" % (self.__class__.__name__, self._add_const)

    @staticmethod
    def add_const(mtx_x):
        if isinstance(mtx_x, pd.DataFrame):
            mtx_x_to_use = mtx_x.copy()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=PerformanceWarning)
                mtx_x_to_use.loc[:, 'const'] = 1 #indexing past lexsort depth may impact performance.
            #c_val = mtx_x_to_use.loc[:, ['const']].columns.values[0]
            c_val = mtx_x_to_use.iloc[:, [-1]].columns.values[0]

            cols = mtx_x_to_use.columns.tolist()
            cols.insert(0, cols.pop(cols.index(c_val)))
            mtx_x_to_use = mtx_x_to_use.reindex(columns=cols)

        else:
            mtx_x_to_use = np.hstack((mtx_x, np.ones((mtx_x.shape[0], 1))))

        return mtx_x_to_use
    
    def fit(self, mtx_x, vec_y, cluster_groups=None):
        #add the constant before going through the normal procedure
        self._vec_y_len = len(vec_y)
        if self._add_const:
            if mtx_x is None:
                mtx_x_to_use = np.full((self._vec_y_len, 1), 1.)
            else:
                mtx_x_to_use = OLS.add_const(mtx_x)
        else:
            mtx_x_to_use = mtx_x
        super().fit(mtx_x_to_use, vec_y, cluster_groups)
       
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y, cluster_groups)
        if self._add_const and self._x_column_index is not None:
            self._x_column_index = [Model.CONST_NAME] + self._x_column_index


        self._model = sm.OLS(vec_y, mtx_x, hasconst=self._add_const)

        if cluster_groups is None:
            self._modelres = self._model.fit()
        else:
            self._modelres = self._model.fit(cov_type='cluster', cov_kwds={'groups' : cluster_groups})

    def predict(self, mtx_x, vec_y_true=None):
        '''
        Ovewritting
        '''
        #add the constant before going through the normal procedure
        if self._add_const:
            if mtx_x is None:
                mtx_x_to_use = np.full((self._vec_y_len, 1), 1.)
            else:
                mtx_x_to_use = OLS.add_const(mtx_x)
        else:
            mtx_x_to_use = mtx_x
        return super().predict(mtx_x_to_use, vec_y_true)

    def _predict(self, mtx_x):
        super()._predict(mtx_x)

        pred = self._modelres.predict(mtx_x)

        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=FutureWarning) #Ignore warning about reshape deprecated
            result = pred.reshape(mtx_x.shape[0], )
        return result

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coeff = self._modelres.params
        columns = self._x_column_index
        return pd.DataFrame([coeff], columns=columns)


    def get_standard_errors(self):
        '''
        Return the stadnard errors of the computed model
        '''
        standard_error = self._modelres.HC0_se
        standard_error[standard_error == 0] = float("nan")
        columns = self._x_column_index
        return pd.DataFrame([standard_error], columns=columns)

    @property
    def add_est_results(self):
        '''
        Return the underlying results object (contains more statistical properties)
        '''
        return self._modelres


    def get_variance_matrix(self):
        columns = self._x_column_index
        var = self._modelres.cov_HC0
        #if self._add_const:
        #    var = var[1:, 1:]
        return pd.DataFrame(var, columns=columns, index=columns)
