#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
#import warnings

#import pandas as pd
#import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

from .model import Model

class BoostedTrees(Model):
    '''
    Wrapper to sci-kit learn GradientBoostingRegressor model
    '''
    #Eventually offer to set learning_rate via CV (this is the sh
    def __init__(self, learning_rate=0.1, n_estimators=100, max_depth=3, random_state=None):
        '''
        :param learning_rate: This is the shrinkage (regularization) parameter
        :param n_estimators: Number of Trees
        :param max_depth: maximum depth of the individual regression estimators. 
            The maximum depth limits the number of nodes in the tree. 
            Tune this parameter for best performance; the best value depends on the interaction of the input variables.
        :param random_state:
        '''
        super().__init__()
        self.__model = GradientBoostingRegressor(loss='ls', learning_rate=learning_rate, n_estimators=n_estimators, 
                                                 max_depth=max_depth, random_state=random_state)

    def __repr__(self):
        '''
        Not usable as instantiation
        '''
        return "%s: %r" % (self.__class__.__name__, self.__model)

    def _fit(self, mtx_x, vec_y):
        super()._fit(mtx_x, vec_y)
        self.__model.fit(mtx_x, vec_y)

    def _predict(self, mtx_x):
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x)
