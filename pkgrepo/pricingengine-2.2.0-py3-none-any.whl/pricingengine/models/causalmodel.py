#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np

from abc import abstractmethod
from .linearmodel import LinearModel
from .model import Model
from msecore import verify
from msecoreml.mlexception import MLException, MLErrorCode

#pylint: disable=arguments-differ

class CausalModel(LinearModel):
    '''
    Abstact base class for all linear causal models
    '''
    SE_NAME = "se"
    def __init__(self):
        super().__init__()
        self.cluster_groups = None

    @abstractmethod
    def get_standard_errors(self):
        '''
        Return the standard errors of the computed model
        '''
        pass

    @abstractmethod
    def get_variance_matrix(self):
        '''
        Return the standard errors of the computed model
        '''
        pass

    @abstractmethod
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Reimplement the model.fit now that we have a new parameter
        '''
        verify.istype(mtx_x, (np.ndarray, pd.Series, pd.DataFrame))
        verify.istype(vec_y, (np.ndarray, pd.Series, pd.DataFrame))

    def _fit_setup(self, mtx_x, vec_y, cluster_groups):
        super()._fit_setup(mtx_x, vec_y)
        
        if cluster_groups is not None:
            verify.istype(mtx_x, (pd.Series, pd.DataFrame))
            verify.istype(vec_y, (pd.Series, pd.DataFrame))
    
    def fit(self, mtx_x, vec_y, cluster_groups=None):
        '''  
        Reimplement the model.fit now that we have a new parameter

        :param mtx_x: A Pandas Dataframe of m rows by n columns
        :param vec_y: A Pandas Series of length m
        :param cluster_groups: Optional pandas series of length m indicating
            group ids for clustering
        '''
        self._fit_setup(mtx_x, vec_y, cluster_groups)

        inclusion_mask = super()._get_inclusion_mask(mtx_x, vec_y)
        if cluster_groups is None:
            self._fit(mtx_x[inclusion_mask], vec_y[inclusion_mask])
        else:
            self._fit(mtx_x[inclusion_mask], vec_y[inclusion_mask], cluster_groups=cluster_groups[inclusion_mask])

        self._is_fit = True
        

    def _sum_by_group(self, values, groups):
        order = np.argsort(groups)
        groups = groups[order]
        values = values[order]
        values.cumsum(out=values, axis=0)
        index = np.ones(len(groups), 'bool')
        index[:-1] = groups[1:] != groups[:-1]
        values = values[index]
        groups = groups[index]
        values[1:] = values[1:] - values[:-1]
        return values, groups

