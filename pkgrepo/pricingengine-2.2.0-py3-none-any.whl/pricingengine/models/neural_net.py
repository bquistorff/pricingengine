#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from sklearn.neural_network import MLPRegressor

from .model import Model

class NeuralNet(Model):
    '''
    Wrapper to sci-kit learn MLP Regressor
    '''
    # Eventually, provide an L1-penalized version
    # CCDDHNR 2017 said they do linear activiation functions but I'm assuming that just for output layer
    def __init__(self, hidden_layer_sizes=(2,), max_iter=200):
        super().__init__()
        self.__model = MLPRegressor(hidden_layer_sizes=hidden_layer_sizes,
                                    solver='lbfgs', #better for small data. non-stocastic
                                    max_iter=max_iter,
                                   )

    def __repr__(self):
        '''
        Not usable as instantiation
        '''
        return "%s: %r" % (self.__class__.__name__, self.__model)

    def _fit(self, mtx_x, vec_y):
        super()._fit(mtx_x, vec_y)
        return self.__model.fit(mtx_x, vec_y)

    def _predict(self, mtx_x):
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x)
