#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import numpy as np
import pandas as pd
from sklearn import linear_model

from .causalmodel import CausalModel
from .ols import OLS

class PostLasso(CausalModel):
    '''
    Wrapper to sm ols after sci-kit LassoCV model
    '''
    def __init__(self, lasso_model=linear_model.LassoCV()):
        super().__init__()
        self.__prelim_model = lasso_model
        self.__model = OLS(add_const=True)
        self.__selected_coefficients = None
       
    def _fit(self, mtx_x, vec_y, cluster_groups=None):
        '''
        Fit method invoked by parent class
        '''
        super()._fit(mtx_x, vec_y)
        prelim_model = self.__prelim_model.fit(mtx_x, vec_y)
        self.__selected_coefficients = [i for i, c in enumerate(prelim_model.coef_) if abs(c) > 0]
        if len(self.__selected_coefficients) > 0:
            mtx_x_selected = mtx_x[:, self.__selected_coefficients]
        else:
            mtx_x_selected = None
        tmp = self.__model.fit(mtx_x_selected, vec_y, cluster_groups)
        return tmp

    def _predict(self, mtx_x):
        '''
        Predict method invoked by parent class
        '''
        super()._predict(mtx_x)
        if len(self.__selected_coefficients) > 0:
            mtx_x_selected = mtx_x[:, self.__selected_coefficients]
        else:
            mtx_x_selected = None
        pred = self.__model.predict(mtx_x_selected)
        return pred

    def get_coefficients(self):
        '''
        Return the coefficients of the computed model
        '''
        coeff = self.__model.add_est_results.params
        columns = self._x_column_index
        gross_coeff = np.array([0] * len(self.__selected_coefficients))
        gross_coeff[self.__selected_coefficients] = coeff
        return pd.DataFrame([gross_coeff], columns=columns)


    def get_standard_errors(self):
        '''
        Return the coefficients of the computed model
        '''
        standard_error = self.__model.add_est_results.bse
        standard_error[standard_error == 0] = float("nan")
        columns = self._x_column_index

        gross_standard_error = np.array([float("nan")] * len(self.__selected_coefficients))
        gross_standard_error[self.__selected_coefficients] = standard_error


        return pd.DataFrame([gross_standard_error], columns=columns)

    @property
    def add_est_results(self):
        '''
        Return the underlying results object (contains more statistical properties)
        '''
        return self.__model.add_est_results


    
    def get_variance_matrix(self):
        columns = self._x_column_index
        return pd.DataFrame(self.__model.add_est_results.cov_HC0, columns=columns, index=columns)
