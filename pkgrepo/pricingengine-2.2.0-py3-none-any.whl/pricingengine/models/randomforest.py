#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
#import warnings

#import pandas as pd
#import numpy as np
import sklearn

from .model import Model

class RandomForest(Model):
    '''
    Wrapper to sci-kit learn RandomForestRegressor model
    '''
    def __init__(self, n_estimators=10, max_depth=None, n_jobs=1, random_state=None):
        super().__init__()
        self.__model = sklearn.ensemble.RandomForestRegressor(n_estimators=n_estimators, max_depth=max_depth, 
                                                              n_jobs=n_jobs, random_state=random_state)

    def __repr__(self):
        '''
        Not usable as instantiation
        '''
        return "%s: %r" % (self.__class__.__name__, self.__model)

    def _fit(self, mtx_x, vec_y):
        super()._fit(mtx_x, vec_y)
        self.__model.fit(mtx_x, vec_y)

    def _predict(self, mtx_x):
        super()._predict(mtx_x)
        return self.__model.predict(mtx_x)
