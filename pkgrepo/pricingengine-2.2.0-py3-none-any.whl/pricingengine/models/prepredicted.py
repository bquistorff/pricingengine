#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import re
import numpy as np
import pandas as pd
from msecoreml.pddataframeex import PdDataframeEx
from pricingengine.models.model import Model, SampleSplitModel
from pricingengine.estimation.feature_generator import FeatureGenerator
from pricingengine.estimation.typed_dataset import ColType

class PrePredicted(Model):
    '''
    Currently only works for standard (non-multi-task learning) models
    '''
    def __init__(self, prediction):
        '''
        :param prediction: Must has same indexing as df used for prediction
        '''
        super().__init__()
        self._prediction = prediction
        self._prediction.name = Model.PREDICTION_COL_NAME
        self._fake_coeff_vec = None
        
    def _fit(self, mtx_x, vec_y):
        super()._fit(mtx_x.values, vec_y.values) #for the checks
        self._fake_coeff_vec = pd.DataFrame(columns=mtx_x.columns, index=[0])

    def _predict(self, mtx_x):
        super()._predict(mtx_x.values) #for the checks
        
        df = self._prediction.reorder_levels(mtx_x.index.names)
        df = mtx_x.merge(df, how='left', left_index=True, right_index=True)
        return df[Model.PREDICTION_COL_NAME]



class SSPrePredicted(SampleSplitModel):
    '''
    Store results for a model that has already been fit and predicted.
    This is used for baseline models to allow us to separate that part 
    of the analysis pipeline.

    To store the data from a builtin DDML model: ::
        full_baseline_preds = pd.DataFrame()
        ddml.predict(ds, ret_pred=full_baseline_preds)
        PrePredicted.write_pred_df_to_csv(recorder_fname, full_baseline_preds)
    
    The file will have have the first columns as the data (observation) index, 
    followed by columns Variable, Lead, Prediction.
    Rows in the recorder file are uniquely identified by (data-index, Variable, Lead). 

    To load the data from this type of csv: ::

        builtin_predictions = PrePredicted.get_rec_df_from_csv(recorder_fname, schema)
        baselines = DynamicDML.gen_prepredicted_baselines(builtin_predictions)
        ddml2 = DynamicDML(baseline_model=baselines, ...)

    If you estimate a DynamicDML model for the whole data and then one on a subset (to do out-of-sample evaluation) 
    then you will need different Prepredicteds because the folds will be different.
    '''

    def __init__(self, value):
        super().__init__(num_splits=None)
        self._df = None
        self._const_value = None
        if isinstance(value, pd.DataFrame):
            self._df = value
        else: #assume constant
            self._const_value = value
        self._fake_coeff_vec = None
        
    def _fit(self, mtx_x, vec_y, folds):
        super()._fit(mtx_x.values, vec_y.values, folds) #for the checks
        self._fake_coeff_vec = pd.DataFrame(columns=mtx_x.columns, index=[0])

    def _predict(self, mtx_x, folds=None): #pylint: disable=unused-argument
        super()._predict(mtx_x.values) #for the checks
        
        if self._const_value is not None:
            return pd.Series(self._const_value, index=mtx_x.index, name=Model.PREDICTION_COL_NAME)
        
        df = self._df.reorder_levels(mtx_x.index.names)
        df = mtx_x.merge(df, how='left', left_index=True, right_index=True)
        return df[Model.PREDICTION_COL_NAME]


    #def _fit_and_predict(self, vec_y, mtx_x, folds): #Not any faster

    def get_coefficients(self):
        return self._fake_coeff_vec
    

    # To-From CSV
    # Panel-identifying variable values are quoted even when they are numbers
    # When passing through a csv file these can get turned easily from quoted numbers to numbers]
    # and this means that merging the data gets messed up
    # The option quoting=csv.QUOTE_NONNUMERIC doesn't seem to work
    # so manually convert those columns back to strings

    @staticmethod
    def write_rec_df_to_csv(fname, recs):
        recs.to_csv(fname) 

    @staticmethod
    def get_rec_df_from_csv(fname, schema, extra_index_vars=None): 
        '''
        :param fname: Filename
        :param schema: Schema
        :param extra_index_vars: Examples: [Model.VARIABLE_COLNAME, DynamicDML.LEAD_LEVEL_NAME]
        '''
        if extra_index_vars is None:
            extra_index_vars = []
        panel_names = schema.get_panel_col_names()
        ndataindex = 1 + len(panel_names) #One for time
        nindex = ndataindex + len(extra_index_vars)
        df = pd.read_csv(fname, parse_dates=True, index_col=list(range(nindex)))
        inames = panel_names + [schema.get_time_col_name()] + extra_index_vars
        dfr = df.reset_index()
        for pname in panel_names:
            dfr[pname] = dfr[pname].astype(np.str)
        dfrs = dfr.set_index(inames)

        return dfrs
