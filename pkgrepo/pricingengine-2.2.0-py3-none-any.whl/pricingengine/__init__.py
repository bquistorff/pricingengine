#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------

#Make imports easier
from msecoreml.pddataframeex import PdDataframeEx

from pricingengine.schema import Schema, ColDef, DataType
from pricingengine.estimation.regression import Regression
from pricingengine.estimation.typed_dataset import ColType
from pricingengine.estimation.estimation_dataset import EstimationDataSet
from pricingengine.dataset import DataSet
from pricingengine.estimation.double_ml import DoubleML
from pricingengine.estimation.dynamic_dml import DynamicDML, DDMLOptions
from pricingengine.estimation.feature_generator import FeatureGenerator
from pricingengine.featurizers import default_dynamic_featurizer
from pricingengine.featurizers import default_panel_featurizer

from pricingengine.models.model import Model, SampleSplitModel
from pricingengine.models.ensemble import CrossFitContainer, BucketSS, StackedSS
from pricingengine.models.fast_debiased_lasso import FastDebiasedLasso
from pricingengine.models.debiased_lasso import DebiasedLasso
from pricingengine.models.lasso import LassoCV
from pricingengine.models.ridge import RidgeCV
from pricingengine.models.ols import OLS
from pricingengine.models.zero import Zero
from pricingengine.models.prepredicted import PrePredicted, SSPrePredicted
from pricingengine.models.boosting import BoostedTrees
from pricingengine.models.randomforest import RandomForest

from pricingengine.variables.own_past_agg_var import OwnPastAggVar
from pricingengine.variables.own_var import OwnVar
from pricingengine.variables.peer_agg_var import PeerAggVar
from pricingengine.variables.p_to_p_var import PToPVar
from pricingengine.variables.const_var import ConstVar

from pricingengine.utilities.predictions import Predictions

# The version as used in the setup.py, docs conf.py, and get_version.bat
# Only change what's between the double quotes
__version__ = "2.2.0"
