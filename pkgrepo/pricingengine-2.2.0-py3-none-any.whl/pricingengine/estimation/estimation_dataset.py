#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from abc import abstractmethod
import pandas as pd
import numpy as np
import msecore.verify as verify
from pricingengine.schema import Schema, ColDef
from pricingengine.estimation.typed_dataset import TypedDataSet, ColType, DataType
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.sample_splitting import SampleSplitting


#pylint: disable=too-many-locals

#-----------------------------------------------------------------------------------------------------------------------
# Data Validation
#-----------------------------------------------------------------------------------------------------------------------
class EstimationDataSetValidator(object):
    '''
    Base class for validators
    '''
    @abstractmethod
    def validate(self, estimation_dataset):
        '''
        validate estimation_dataset object
        '''
        verify.istype(estimation_dataset, EstimationDataSet)

class ValidPanels(EstimationDataSetValidator):
    '''
    Class that validates estimationdataset object
    '''

    def validate(self, estimation_dataset):
        '''
        Verify the given daataset by making sure that all consecutive data points have a common timedelta
        '''    
        super().validate(estimation_dataset)
        

        # Break the dataset into groups
        date_colname = estimation_dataset.schema.get_time_col_name()
        groups = list(estimation_dataset.data.groupby(estimation_dataset.group_labels))

        # Extract a delta to use as the target delta, min date, max date
        target_delta = estimation_dataset.data_interval

        # Verify each group has the same time deltas
        for key, df in groups:
            dates_index = pd.Series(df.index.get_level_values(date_colname))
            time_deltas = dates_index.diff()[1:]
            verify.true(all(time_deltas == target_delta), "Inconsistent time deltas {0}".format(str(key)))
            #verify.true(dates_index.iloc[0] == min_date, "Inconsistent start date")
            #verify.true(dates_index.iloc[-1] == max_date, "Inconsistent end date")

class EstimationDataSet(TypedDataSet):
    '''
    Dataset with known schema used for generating features
    '''
    __required_ids = [ColType.OUTCOME, ColType.TREATMENT]

    def __init__(self, data, schema, validators=frozenset([ValidPanels()]), fold_fit_info=None):
        '''
        :param data: pandas dataframe containing date, units, and price columns with a single column index
        :param schema: Schema describing the data
        :param validators: A list of validators to use for verifying data integrity
        :param fold_fit_info: Series where each value is the index of the model that has this as the test portion
            or NaN if all folds can have this as test (when fit on subset of dataset).
            This is None if this dataset has been fit. Will be set after fit.
            We store this rather than folds since we can filter more easily.
        '''
        super().__init__(data, schema, EstimationDataSet.__required_ids)
        validator_list = list(validators)
        verify.is_list_oftype(validator_list, EstimationDataSetValidator)

        self._data = self._data.sort_values(schema.get_panel_col_names() + [schema.get_time_col_name()])
        self._fold_fit_info = None
        self.fold_fit_info = fold_fit_info

        self._get_data_interval()
        for validator in validator_list:
            validator.validate(self)
            

    def __repr__(self):
        #don't show the validator since it must have been valid
        return "%s(%r, %r, %r)" % (self.__class__.__name__, self.data, self.schema, self.fold_fit_info)

    @property
    def schema(self):
        '''
        Returns schema
        '''
        return self._schema
    
    @property
    def data(self):
        '''
        Returns data
        '''
        return self._data

    @property
    def data_interval(self):
        '''
        Return the temporal spacing between consecutive data points
        '''
        return self._data_interval

    @property
    def fold_fit_info(self):
        '''
        Returns the folds (test part at least) for what was fit
        '''
        return self._fold_fit_info

    @fold_fit_info.setter
    def fold_fit_info(self, fold_fit_info):
        self._fold_fit_info = fold_fit_info
        #TODO: Only need the test info so could clear train out


    @staticmethod
    def from_df(df, treatment_colname="treatment", outcome_colname="units", date_colname="date", 
                is_panel_col=lambda x: x.startswith('p_'), 
                validators=frozenset([ValidPanels()])):
        '''
        Create an EstimationDataSet from the given dataframe. 

        :param df: A pandas dataframe containing price, units, and date columns. 

                   - String columns and panel columns will be interpreted as categorical columns
                   - Float/int columns will be interpreted as numeric columns (convert numeric columns to string if
                       the column is to be interpreted as categorical)

        :param treatment_colname: The name of the numeric column containing treatment
        :param outcome_colname: The name of the numeric column quantities
        :param date_colname: The name of the datetime column containing dates
        :param is_panel_col: A function that takes in a column names and returns a boolean indicating if 
                             the column is used to break the dataset into panels
        :param validators: list of validators applied to the produced EstimationDataSet
        '''
        verify.not_none_or_empty(df, "df")

        # Verify column types of named columns
        EstimationDataSet._verify_datatype(df, treatment_colname, DataType.NUMERIC)
        EstimationDataSet._verify_datatype(df, outcome_colname, DataType.NUMERIC)
        EstimationDataSet._verify_datatype(df, date_colname, DataType.DATE_TIME)

        # Create column definitions
        col_defs = [ColDef(treatment_colname, DataType.NUMERIC, ColType.TREATMENT), 
                    ColDef(outcome_colname, DataType.NUMERIC, ColType.OUTCOME), 
                    ColDef(date_colname, DataType.DATE_TIME)]
        unknown_colnames = set(df.columns) - set([treatment_colname, outcome_colname, date_colname])
        for col_name in unknown_colnames: 
            data_type = DataType.CATEGORICAL if EstimationDataSet._is_categorical_col(df, col_name, is_panel_col) \
                else DataType.NUMERIC
            col_defs.append(ColDef(col_name, data_type))

        # Get panel colnames
        panel_colnames = [x for x in df.columns if is_panel_col(x)]

        # Create EstimationDataSet
        schema = Schema(col_defs, date_colname, panel_colnames)
        dataset = EstimationDataSet(df, schema, validators)
        return dataset

    #Sometimes it may be easier to store the info in a series
    # for the number indicates which fold exclusively has that observation
    # in its test set. -1 indicates no fold has that obs exclusively in test set
    # (ie all can predict out on it) (or is test when single fold).

    @staticmethod
    def _convert_folds_to_array(folds, nrows, do_test=True):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter(action='ignore', category=FutureWarning) #Ignore warning about dtype change
            arr = np.full((nrows,), -1)
        intersection = None
        for i, (train, test) in enumerate(folds):
            if do_test:
                to_use = test
            else:
                to_use = train
            arr[to_use] = i
            if intersection is None:
                intersection = set(to_use)
            else:
                intersection = intersection.intersection(to_use)
        arr[list(intersection)] = -1
        return arr

    @staticmethod
    def _convert_folds_to_test_series(folds, idx):
        nrows = len(idx)
        test_arr = EstimationDataSet._convert_folds_to_array(folds, nrows, do_test=True)
        return pd.Series(test_arr, index=idx)

    @staticmethod
    def _convert_folds_to_series(folds, idx, do_test=True):
        '''
        :param folds: fold info list of tuples (train, test) of arrays.
        :param idx: Index for the returned series
        :param do_test: If true, marks out the test spots, else does the train spots
        '''
        nrows = len(idx)
        arr = EstimationDataSet._convert_folds_to_array(folds, nrows, do_test)
        return pd.Series(arr, index=idx)

    @staticmethod
    def _convert_test_array_to_test_folds(array, nfolds): #pylint: disable=invalid-name
        folds = []
        for i in range(nfolds):
            test = np.where(np.logical_or(array == i, array == -1))[0]
            folds.append(([], test))
        return folds

    @staticmethod
    def _convert_test_series_to_test_folds(series, nfolds): #pylint: disable=invalid-name
        return EstimationDataSet._convert_test_array_to_test_folds(series.values, nfolds)

    @staticmethod
    def convert_folds_across_indexes(orig_folds, orig_idx, new_idx):
        '''
        Converts fold info from one DataFrame index to another
        '''
        orig_series = EstimationDataSet._convert_folds_to_test_series(orig_folds, orig_idx)
        new_series = pd.Series(-1, index=new_idx)
        inner_idx = orig_series.align(new_series, 'inner')[0].index #left [0] and [1] will be same on inner
        new_series[inner_idx] = orig_series[inner_idx]
        new_folds = EstimationDataSet._convert_test_series_to_test_folds(new_series, len(orig_folds))
        return new_folds


    def gen_folds_for_new_index(self, new_idx):
        '''
        Converts fold info from this object's index to another
        '''
        if self.fold_fit_info is None:
            return None
        
        return EstimationDataSet.convert_folds_across_indexes(self._fold_fit_info, self.data.index, new_idx)

    def set_folds_from_other_index(self, other_folds, other_idx):
        '''
        Sets this object's fold info to that from another context (fold_info and index)
        '''
        self.fold_fit_info = EstimationDataSet.convert_folds_across_indexes(other_folds, other_idx, self.data.index)


    def filter(self, filter_dic=None, first_date=None, last_date=None):
        '''
        Returns a new estimation_dataset object which is filtered by the requirements in the filter_dic

        :param filter_dic: dictionary mapping data columns to lists of allowed values
        :param first_date: omit any data before this date
        :param last_date: omit any data from after this date
        '''
        filter_dic = {} if filter_dic is None else filter_dic
        row_selector = PdMultiIndexEx.get_some_levels_block_indicator(self._data.index, filter_dic)
        filtered_data = self._data.loc[row_selector, :]
        fold_fit_info = None
        if self._fold_fit_info is not None:
            import copy
            fold_fit_info = copy.deepcopy(self._fold_fit_info)
        fold_fit_info = SampleSplitting.filter_folds(row_selector, fold_fit_info)

        if first_date != None:
            row_selector = filtered_data[self._schema.get_time_col_name()] >= first_date
            filtered_data = filtered_data[row_selector]
            fold_fit_info = SampleSplitting.filter_folds(row_selector, fold_fit_info)
        if last_date != None:
            row_selector = filtered_data[self._schema.get_time_col_name()] <= last_date
            filtered_data = filtered_data[row_selector]
            fold_fit_info = SampleSplitting.filter_folds(row_selector, fold_fit_info)

        return EstimationDataSet(filtered_data, self._schema, validators=[], fold_fit_info=fold_fit_info)

    def _get_data_interval(self):
        '''
        Gets self._schema.get_time_col_name() interval between first occurence of consecutive 
        observations with identical panel variables. If appropriately validator is used, this is the unique 
        "data interval".
        '''
        
        iloc_index = 1
        while not all([self.data.iloc[iloc_index][p] == self.data.iloc[iloc_index - 1][p] 
                       for p in self.schema.get_panel_col_names()]):
            iloc_index += 1

        self._data_interval = (self.data.iloc[iloc_index][self._schema.get_time_col_name()] - 
                               self.data.iloc[iloc_index - 1][self._schema.get_time_col_name()])

    def append_data_one_instance(self, panel_dic, treatments_path, start_date):
        '''
        Returns a new estimation_dataset object with additional rows corresponding to the product specified in 
        panel_dic and the given price_path. The synthetic data will begin on the start_date and carry forward at the 
        same intervals as the rest of the data. If necessary, it will overwrite pre-existing data.

        :param panel_dic: dictionary of panel values that must specify a unique instance
        :param treatments_path: dictionary (keyed by treatment_names) with values as iterables of numbers 
            specifying the planned treatments of that instance week-by-week going forward. 
            The 0th value of each iterable corresponds to the start_date
        :param start_date: First week in which the price_path is applied. I.E. price_path[0] specifies the price on 
            the start_date. This value must be in the estimation_dataset or immediately following an observation in 
            the estimation_dataset.
        '''

        weeks = [len(treatments_path[t]) for t in  treatments_path]
        u_weeks = np.unique(weeks)
        if len(u_weeks) == 1:
            num_weeks = u_weeks[0]
        else:
            raise Exception('Iterables in treatment_path must all be the same length')

        data_interval = self._data_interval
        tmp = self.filter(panel_dic)
        if ((start_date not in tmp.data[self._schema.get_time_col_name()].dt.values) and 
                (start_date != tmp.data[self._schema.get_time_col_name()].max() + data_interval)):
            raise Exception('Invalid start_date. Must be a date in or immediately after currently available data.')

        panel_cols = list(panel_dic.keys())
        treat_cols = list(treatments_path.keys())
        data_cols = panel_cols + [self._schema.get_time_col_name(), 
                                  self._schema.get_colname_bycoltype(ColType.OUTCOME)] + treat_cols
        #index_cols = panel_cols + [self._schema.get_time_col_name()]
        
        remaining_cols = [c for c in self.data.columns if c not in data_cols]
        rem_data = self.data.groupby(panel_cols).agg({r: lambda x: x.iloc[-1] for r in remaining_cols})
        rem_row = rem_data.loc[tuple(panel_dic.values())]

        values = []
        for d_var in range(num_weeks):
            values.extend([[panel_dic[p] for p in panel_cols] + 
                           [start_date + data_interval * d_var, np.nan] + 
                           [treatments_path[treatment_name][d_var] for treatment_name in treat_cols] + 
                           list(rem_row.values)])
        

        df = pd.DataFrame(values, columns=data_cols + list(rem_data.columns.values))
        df = df.set_index(self.data.index.names, drop=False)

        new_data = pd.concat([self.data, df])
        new_data = new_data.groupby(new_data.index).last() #overwrite any old data with new data
        new_folds = self.gen_folds_for_new_index(new_data.index)
        estimation_dataset_new = EstimationDataSet(new_data, self.schema, fold_fit_info=new_folds)

        return estimation_dataset_new

    @staticmethod
    def _is_categorical_col(df, colname, is_panel_col):
        return is_panel_col(colname) or not DataType.is_supported_dtype(DataType.NUMERIC, df[colname].dtype)

    @staticmethod
    def _verify_datatype(df, colname, datatype):
        verify.true(DataType.is_supported_dtype(datatype, df[colname].dtype), 
                    "{0} incompatible column type".format(colname))
