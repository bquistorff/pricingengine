# ------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# ------------------------------------------------------------------------

import warnings
import pandas as pd
import numpy as np
from abc import ABCMeta, abstractmethod


import msecore.verify as verify
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdonehotencoder import PdOneHotEncoder

from pricingengine.estimation.estimation_dataset import EstimationDataSet
from pricingengine.schema import Schema
from pricingengine.dataset import DataSet
from pricingengine.models.model import Model
from pricingengine.models.linearmodel import LinearModel
from pricingengine.models.causalmodel import CausalModel
from pricingengine.models.lasso import LassoCV
from pricingengine.models.ols import OLS
from pricingengine.variables.var_builder import VarBuilder

from pricingengine.estimation.typed_dataset import ColType, DataType
from pricingengine.estimation.feature_generator import FeatureGenerator
#pylint: disable=redefined-variable-type, too-many-instance-attributes, too-many-locals
class Estimation(metaclass=ABCMeta):
    def __init__(self, schema, cluster_date):
        self._schema = schema
        self._cluster_date = cluster_date
        self._is_fit = False
        self._encoders = None
        
    # Note that _set_encoders is separable because
    # someone may want to set options on the encoders before they are fit (in future allow this via api)
    # so they could do the following instead of fit
    #   ddml._init_encoders(dataset)
    #   <play with ddml._encoders[name]>
    #   ddml._fit_encoders(dataset)
    #   ddml.fit(dataset)
    def _set_encoders(self, dataset):
        '''
        Fit encoders for all CATEGORICAL columns in estimation_dataset. This allows creation of corresponding 
        dummy variables
        '''
        self._init_encoders(dataset)
        self._fit_encoders(dataset)

    def _init_encoders(self, dataset):
        self._encoders = dataset.gen_encoders()
        
    def _fit_encoders(self, dataset):
        dataset.fit_encoders(self._encoders)
        
    def fit(self, estimation_dataset):
        '''
        Fit baseline and causal models on the given dataset

        :param EstimationDataSet estimation_dataset: A dataset on which to train the model
        '''
        verify.istype(estimation_dataset, EstimationDataSet)
        verify.true(self._schema == estimation_dataset.schema, verify.Messages.SCHEMA_MISMATCH_MESSAGE)
        self._is_fit = True
        self._fit(estimation_dataset)


    @staticmethod
    def _squash_int_ind_levels(idx):

        if isinstance(idx, pd.MultiIndex):
            idx_int = idx.droplevel(VarBuilder.FEATURE_TYPE_COL_NAME)
            p2p_impactor = [dx for dx, name in enumerate(idx_int.names) if 'impactor' in name]
            if len(p2p_impactor) > 1:
                raise Exception('impactor cannote be used as a column name')
            elif len(p2p_impactor) == 1:
                p2p_impactor = p2p_impactor[0]
                idx_int = pd.MultiIndex.from_tuples([x[0:p2p_impactor] + x[p2p_impactor + 1:]
                                                     for dx, x in enumerate(idx_int)])
            else:
                p2p_impactor = -99

            idx_feat = PdMultiIndexEx.concat_index_levels(
                idx.droplevel([idx_name for dx, idx_name in enumerate(idx.names) 
                               if idx_name != VarBuilder.FEATURE_TYPE_COL_NAME
                               and dx != p2p_impactor + 1]), sep='_', name=VarBuilder.FEATURE_TYPE_COL_NAME)
            
            idx_int = PdMultiIndexEx.concat_index_levels(idx_int, sep=VarBuilder.INTERACTION_SEP, 
                                                         name=VarBuilder.AUX_COL_NAME)
            new_midx = PdMultiIndexEx.midx_from_list_of_namedarray([idx_feat, idx_int])
            return new_midx
        else: #Then plain pd.Index
            return idx
        
    def get_coefficients(self, human_index=True):
        '''
        Get coefficients from the causal model

        :param human_index: If True, then the interactions levels of the multiindex are squashed.
            Otherwise, they are are left separate (useful for automated post-processing).
        '''
        beta_raw = self._causal_model.get_coefficients().copy()
        scale = self._treatment_scale().T
        beta = (beta_raw / scale).T
        if human_index:
            beta.index = Estimation._squash_int_ind_levels(beta.index)
        beta.columns = [LinearModel.COEF_NAME]
        return beta

    def get_variance_matrix(self, human_index=True):
        '''
        Get variance matrix from the causal model
        '''
        var_raw = self._causal_model.get_variance_matrix()
        scales = self._treatment_scale().T
        var = var_raw / np.matmul(np.transpose(np.matrix(scales)), np.matrix(scales))
        if human_index:
            var.index = Estimation._squash_int_ind_levels(var.index)
            var.columns = Estimation._squash_int_ind_levels(var.columns)
        return var
        

    def get_standard_errors(self, human_index=True):
        '''
        Get standard errors from the causal model
        '''        
        se_raw = self._causal_model.get_standard_errors().copy()
        scale = self._treatment_scale().T
        std_err = (se_raw / scale).T
        if human_index:
            std_err.index = Estimation._squash_int_ind_levels(std_err.index)
        std_err.columns = [CausalModel.SE_NAME]
        return std_err

    def _map_unique_to_integer(self, values):
        dic = {ni: indi for indi, ni in enumerate(set(values))}
        return [dic[ni] for ni in values]
    
    def predict(self, dataset, ret_pred=None):
        '''
        Compute predictions for the given dataset using previously trained model

        :param EstimationDataset dataset: A dataset containing features from which to generate 
            predictions. The schema of the dataset must match the schema of the dataset used to fit the model. 
        :param ret_pred: Pass in an empty dataframe if you want that dataframe to be populated with predictions
            of the first stage models
        :raises ValueError: If the schema of the given dataset does not match the schema given for initialization
        :raises RuntimeError: If the model has not yet been fit
        '''
        verify.istype(dataset, DataSet)
        verify.in_good_state(self._is_fit, verify.Messages.BAD_MODEL_STATE_MESSAGE)
        verify.true(self._schema == dataset.schema, verify.Messages.SCHEMA_MISMATCH_MESSAGE)
        return self._predict(dataset, ret_pred)

    @abstractmethod
    def _predict(self, estimation_dataset, ret_pred=None):
        pass

class Regression(Estimation):
    '''
    Class for implement estimation with VarBuilders
    '''

    def __init__(self,
                 schema,
                 model=OLS(),
                 error_model=LassoCV(),
                 regressor_builders=None,
                 cluster_date=True):
        '''
        Initialize a new Regression instance.

        :param schema: The expected schema of datasets to be fit and transformed
        :param Model model: used for estimation
        :param Model error_model: model used to estiamte average abs error (i.e. heteroskedasticity function)
        :param regressor_builders: List of VarBuilders used to create regressors
        '''
        super().__init__(schema, cluster_date)
        
        self.__feature_generator = FeatureGenerator(schema, feature_builders=regressor_builders)
        self._encoders = None
        self.__model = model.copy()
        self.__error_model = error_model.copy()
        self._features_fit = None
        

    def _treatment_scale(self):
        scales = [fb.scale_list for fb in self.__feature_generator.feature_builders]
        return np.array([x[0] for y in scales for x in y])

    @property
    def features_fit(self):
        '''
        Return features used to fit model
        '''
        return self._features_fit

    @property
    def feature_generator(self):
        '''
        Return the feature generator 
        '''
        return self.__feature_generator  


    @property
    def error_model(self):
        '''
        Return the error model
        '''
        return self.__error_model 

    @property
    def model(self):
        '''
        Return the causal model
        '''
        return self.__model 

    def _fit(self, dataset):
        self._set_encoders(dataset)
        self.__feature_generator.encoder = self._encoders


        regressors = self.__feature_generator.fit_all(dataset)
        outcome = dataset.data[dataset.schema.get_colname_bycoltype(ColType.OUTCOME)]
        
        if self._cluster_date:
            time_col = dataset.schema.get_time_col_name()
            obs_index = PdMultiIndexEx.to_frame(dataset.index)[time_col]
            cluster_groups = np.array(self._map_unique_to_integer(obs_index))
        else:
            cluster_groups = None
        self.__model.fit(regressors, outcome, cluster_groups=cluster_groups)
        err = outcome - self.__model.predict(regressors)

        self.__error_model.fit(regressors, abs(err))


    def _predict(self, dataset, ret_pred=None): #pylint: disable=unused-argument
        regressors = self.__feature_generator.fit_all(dataset)
        return self.__model.predict(regressors)

         








