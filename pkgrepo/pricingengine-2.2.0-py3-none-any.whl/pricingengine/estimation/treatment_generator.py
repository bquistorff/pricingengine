#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import itertools
import functools

import numpy as np
import pandas as pd

import msecore.verify as verify
from msecoreml.pdonehotencoder import PdOneHotEncoder
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdmultiindexex import PdMultiIndexEx
from pricingengine.variablegenerator import VariableGenerator
from pricingengine.variables.own_var import OwnVar
from pricingengine.estimation.typed_dataset import ColType, TypedDataSet
from pricingengine.variables.var_builder import VarBuilder
#pylint: disable=redefined-variable-type

#Possibly get rid of this class entirely and just use an instance of TypedDataSet below
class _TreatmentDataSet(TypedDataSet):
    '''
    Dataset class that contains TREATMENT_RESIDUAL
    '''

    __required_ids = [ColType.TREATMENT_RESIDUAL, ColType.TREATMENT, ColType.OUTCOME]

    def __init__(self, data, schema):
        super().__init__(data, schema, _TreatmentDataSet.__required_ids)


class TreatmentGenerator(VariableGenerator):
    '''
    Generator of treatment features from a given treatment dataset. 

    Treatments are composed of three types of features
    
    - The own treatment
    - The own treatment interacted with all features except the designated competition feature
    - The peer-treatment for the competition feature (include the own-treatment)
    - The peer-treatment interacted with all features except the designated competition feature
    '''
    
    def __init__(self, schema, builders=None):
        super().__init__(schema)
        if builders is None: 
            builders = []
        self._encoders = None
        self._missing_index_str = "None"
        self._builders = None
        if builders == []:
            self._builders = [OwnVar(col) for col in schema.get_colnames_bycoltype(ColType.TREATMENT)]
        else:
            self._builders = builders

    def __set_missing_str(self, dataset):
        known_strs = set()
        panel_colnames = self._schema.get_panel_col_names()
        for panel_colname in panel_colnames:
            known_strs.update(set(dataset.data[panel_colname]))
        while self._missing_index_str in known_strs:
            self._missing_index_str = "_" + self._missing_index_str

    def fit(self, dataset):
        verify.istype(dataset, _TreatmentDataSet)
        self.__set_missing_str(dataset)
        super().fit(dataset)
        self._encoders = {x : PdOneHotEncoder() for x in dataset.schema.get_panel_col_names()}
        for name in dataset.schema.get_panel_col_names():
            self._encoders[name].fit(dataset.get_col_by_name(name))
        return self.transform(dataset)

    def transform(self, dataset):
        verify.istype(dataset, _TreatmentDataSet)
        self.__set_missing_str(dataset)

        feature_sets = [x.build(dataset, self._encoders) for x in self.feature_builders]
        flattened_feature_sets = functools.reduce(itertools.chain, feature_sets)
        features = PdDataframeEx.concat_along_rows([self._align_index(x) for x in flattened_feature_sets])

        return features
   
    def get_combined_peer_treatment_key(self, source_name, target_name):
        return source_name + VarBuilder.PEER_TREATMENT_DELIMITER + target_name

    @property
    def feature_builders(self):
        return self._builders

    @property
    def missing_index_str(self):
        return self._missing_index_str

    @property
    def encoders(self):
        return self._encoders

    @encoders.setter
    def encoder(self, enc):
        self._encoders = enc

    def _align_index(self, df):
        
        panel_colnames = self._schema.get_panel_col_names() + [VarBuilder.CUSTOM_FEATURE_INDEX] + \
                         ['auxilary_interaction']
        columns = PdMultiIndexEx.align_index(df.columns, panel_colnames)
        ret = pd.DataFrame(df.values, index=df.index, columns=columns)
        return ret
    
    def get_technical_treatment(self, treatment_residuals_refdate, estimation_dataset, encoders):
        if len(self.feature_builders) > 0:
            treatments_list = [x.build(estimation_dataset, encoders, treatments=treatment_residuals_refdate)
                               for x in self.feature_builders]

            all_columns = []
            for x in treatments_list:
                all_columns.extend([name for name in x.columns.names if not name is None])
            all_columns = np.unique(all_columns)
            to_concat = [pd.DataFrame(x.values, index=x.index,
                                      columns=PdMultiIndexEx.align_index(x.columns, all_columns))
                         for x in treatments_list]
            treatments = PdDataframeEx.concat_along_rows(to_concat)
        else:
            treatments = pd.DataFrame(index=estimation_dataset.index)

        return treatments
