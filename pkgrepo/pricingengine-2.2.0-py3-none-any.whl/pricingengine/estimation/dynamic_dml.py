# ------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# ------------------------------------------------------------------------
from abc import ABCMeta, abstractmethod
import itertools
import warnings
import numpy as np
import pandas as pd
try: #pandas 0.20
    from pandas.errors import PerformanceWarning
except: #pandas 0.19
    from pandas.core.common import PerformanceWarning
from sklearn.model_selection import StratifiedKFold, GroupKFold, KFold

from msecore import verify
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdseriesex import PdSeriesEx
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx
from msecoreml.pdonehotencoder import PdOneHotEncoder
from msecoreml.sample_splitting import SingleFoldFullOverlap

from pricingengine.estimation.typed_dataset import ColType, DataType
from pricingengine.estimation.regression import Estimation
from pricingengine.estimation.double_ml import DoubleML, SingleFoldFullOverlap, DoubleMLLikeModel
from pricingengine.models.model import Model, SampleSplitModel
from pricingengine.schema import Schema, ColDef
from pricingengine.models.ols import OLS
from pricingengine.models.lasso import LassoCV
from pricingengine.models.causalmodel import CausalModel
from pricingengine.models.ensemble import CrossFitContainer
from pricingengine.models.prepredicted import SSPrePredicted
from pricingengine.featurizers.default_dynamic_featurizer import get_featurizer
from pricingengine.utilities.ddml_marginal_effects import DDMLMarginalEffects
from pricingengine.variables.var_builder import VarBuilder
from pricingengine.variables.const_var import ConstVar

from .estimation_dataset import EstimationDataSet
from .feature_generator import FeatureGenerator #, FeatureOptions
from .treatment_generator import TreatmentGenerator



#pylint: disable=too-many-lines, too-many-locals, too-many-instance-attributes, redefined-variable-type, dangerous-default-value, 

class DDMLOptions:
    '''
    Options for computing effects using Dynamic DoubleML
    '''
    def __init__(self, min_lead=1, max_lead=1):
        '''
        Create a new DDMLOptions instance. 

        :param min_lead: Smallest lead to model
        :param max_lead: Largest lead to model
        '''
        verify.greaterthanequals(min_lead, 1, "num_lead_periods")
        verify.greaterthanequals(max_lead, 1, "num_lead_periods")
        verify.greaterthanequals(max_lead, min_lead, "num_lead_periods")

        self.__min_lead = min_lead
        self.__max_lead = max_lead

    def __repr__(self):
        return "%s(%r, %r)" % (self.__class__.__name__, self.__min_lead, self.__max_lead)


    @property
    def leads(self):
        '''
        Return list where each element is a number of periods ahead to compute effects
        '''
        return list(range(self.__min_lead, 1 + self.__max_lead))

class BaseAndError(metaclass=ABCMeta):
    '''
    Model that will fit and predict baseline models and error
    '''
    def __init__(self, leads):
        self.leads = leads

    @abstractmethod
    def fit_baseline_models_featurized(self, common_features, lead_features, outcome_lead, treatments_lead, folds):
        pass

    @abstractmethod
    def predict_baseline(self, common_features, lead_features, fold_fit_info):
        pass

    @abstractmethod
    def baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        pass

    @abstractmethod
    def baseline_fit_diagnostics(self):
        pass
    
    @abstractmethod
    def fit_error_model(self, features_fit, err):
        pass
    
    @abstractmethod
    def error_model_predict(self, features_fit):
        pass

    @staticmethod
    @abstractmethod
    def gen_prepredicted(df):
        pass
    
#sometimes don't need the full sample_splitter just an object with an n_splits attribute
class N_Split: #pylint: disable=invalid-name
    def __init__(self, n_splits):
        self.n_splits = n_splits

class SeqDoubleML(BaseAndError):
    '''
    A dictionary (by lead) of DoubleML objects
    Often takes dictionaries of parameters (by lead) and returns output dictionaries
    Don't implement any of the causal methods yet (since not needed by DynamicDML)
    '''

    def __init__(self, double_mls):
        super().__init__(list(double_mls.keys()))
        self._double_mls = double_mls

    @staticmethod
    def gen_SeqDoubleML(schema, baseline_models, causal_model, error_model, treatment_builders,  #pylint: disable=invalid-name
                        feature_builders, n_splits, leads):
        import copy
        if not (isinstance(baseline_models, dict) and isinstance(list(baseline_models.keys())[0], (int, np.int64))):
            baseline_models = {lead: copy.deepcopy(baseline_models) for lead in leads}
        dummy_splitter = N_Split(n_splits)
        double_mls = {lead : DoubleML(schema,
                                      baseline_model=baseline_models[lead], 
                                      causal_model=causal_model.copy(), 
                                      error_model=error_model.copy(), 
                                      treatment_builders=treatment_builders,
                                      feature_builders=feature_builders,
                                      sample_splitter=dummy_splitter) 
                      for lead in leads}
        return SeqDoubleML(double_mls)

    #Not needed for now
    def set_treatment_generator(self, treatment_generator):
        for lead in self.leads:  
            self._double_mls[lead].treatment_generator = treatment_generator

    #Fit Baseline
    def fit_baseline_models_featurized(self, common_features, lead_features, outcome_lead, treatments_lead, folds):
        features_fit = SeqDoubleML.concat_common_lead(common_features, lead_features, self.leads)
        features_error = {lead: features_fit[lead][Model.ERROR_VAR_NAME] for lead in self.leads}
        treatment_residuals = {}
        outcome_residuals = {}
        for lead in self.leads:
            treatment_residuals[lead], outcome_residuals[lead] = self._double_mls[lead].fit_baseline_models_featurized(
                features_fit[lead], outcome_lead[lead], treatments_lead[lead], folds)
        return treatment_residuals, outcome_residuals, features_error

    # Baseline predictions
    def predict_baseline(self, common_features, lead_features, fold_fit_info):
        features_fit = SeqDoubleML.concat_common_lead(common_features, lead_features, self.leads)
        features_error = {lead: features_fit[lead][Model.ERROR_VAR_NAME] for lead in self.leads}
        outcome_predicted_base = {}
        #for lead in self.leads: #I think this doesn't matter
        #    outcome_predicted_base[lead] = pd.Series(index=features.index)
        treatment_prediction = {}
        for lead in self.leads:
            outcome_predicted_base[lead], treatment_prediction[lead] = \
                self._double_mls[lead].predict_baseline(features_fit[lead], fold_fit_info)
        return outcome_predicted_base, treatment_prediction, features_error
    
    # Baseline predictions (Individual)
    def base_pred_outcome_frame(self, common_features, features_by_lead, leads):
        return [self._double_mls[lead]._baseline_outcome_models.predict( #pylint: disable=protected-access
            pd.concat([common_features, features_by_lead[lead]], axis=1)) for lead in leads]

    def base_pred_treat_frame(self, features, features_by_lead, treatment_name, leads):
        return [self._double_mls[lead]._baseline_treatment_models[treatment_name].predict(pd.concat([features, features_by_lead[lead]], axis=1))  #pylint: disable=protected-access, line-too-long
                for lead in leads] 

    #Baseline Info
    def outcome_coefficients(self, lead):
        return self._double_mls[lead].baseline_outcome_coefficients()

    def treatment_coefficients(self, lead, treatment_name):
        return self._double_mls[lead].baseline_treatment_coefficients(treatment_name)

    def baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        leads = self.leads
        return {lead: self._double_mls[lead].baseline_models_feat_info(avg_splits, combine_vars) for lead in leads}

    def baseline_fit_diagnostics(self):
        return {lead: self._double_mls[lead].baseline_fit_diagnostics() for lead in self.leads}

    
    #Error
    def fit_error_model(self, features_fit, err):
        for lead in self.leads:
            self._double_mls[lead].error_model.fit(features_fit[lead], abs(err[lead]))

    def error_model_predict(self, features_fit):
        return {lead: self._double_mls[lead].error_model.predict(features_fit[lead]) for lead in self.leads}
    
    @staticmethod
    def concat_common_lead(common_features_dict, lead_features_dict, leads):
        '''
        Returns a lead -> varname -> combined_features
        '''
        combined = {lead:{} for lead in leads}
        for varname in common_features_dict:
            common_features = common_features_dict[varname]
            for lead in leads:
                lead_features = lead_features_dict[lead][varname]
                combined_lead_vl = pd.concat([common_features, lead_features], axis=1, join='inner')
                combined_lead_vl.columns = \
                    pd.Index(np.concatenate((common_features.columns.values, lead_features.columns.values))) #fix cols
                combined[lead][varname] = combined_lead_vl
        return combined
    
    @staticmethod
    def gen_prepredicted(df):
        model_dict = {}
        grouped = df.groupby(level=DynamicDML.LEAD_LEVEL_NAME, as_index=False) #group_keys=False
        for lead, lead_df in grouped:
            lead_df.index = lead_df.index.droplevel(DynamicDML.LEAD_LEVEL_NAME)
            model_dict[lead] = DoubleML.gen_prepredicted(lead_df)
        return model_dict

class MultiTaskBaseAndError(BaseAndError):

    def __init__(self, schema, baseline_model, causal_model, error_model, n_splits, leads):
        super().__init__(leads)
    
        self.schema = schema
        self._baseline_model = baseline_model
        self._causal_model = causal_model
        self._error_model = error_model
        self._treatment_names = schema.get_colnames_bycoltype(ColType.TREATMENT) 

        # DEVNOTE: Need to check that the schema has a single unique outcome column 
        self._num_splits = n_splits
        self._outcome_name = schema.get_colnames_bycoltype(ColType.OUTCOME)[0]
        self._initialize_baseline_models(baseline_model)

    def _initialize_baseline_models(self, baseline_model):
        '''
        Initialize all models
        '''
        all_treatments = self.schema.get_colnames_bycoltype(ColType.TREATMENT)
        self._baseline_treatment_models = {}
        self._baseline_outcome_models = CrossFitContainer.wrap_single_model_if_needed(baseline_model, self._num_splits)
        for treatment in all_treatments:
            from copy import deepcopy
            self._baseline_treatment_models[treatment] = deepcopy(self._baseline_outcome_models)
        self._all_baseline_models = self._baseline_treatment_models.copy() #shallow copy is good
        self._all_baseline_models[self._outcome_name] = self._baseline_outcome_models

    def fit_baseline_models_featurized(self, common_features, lead_features, outcome_lead, treatments_lead, folds):
        '''
        :param common_features: features common to all leads
        :param lead_features: lead-specific features
        :param outcome_lead: dict mapping lead to outcome variable values
        :param treatments_lead: dict mapping lead to treatment variable values
        :param folds: list of train test splits used for cross validation
        '''
        #Make sure DDML passes in error
        features_fit = self._concat_common_union_lead(common_features, lead_features)
        features_error = features_fit[Model.ERROR_VAR_NAME]

        # first transform treatments_lead from a dict mapping lead to treatment_name to pandas series into a dict 
        # mapping treatment_lead to dataframe where the columns of the matrix correspond to the lead ...
        mtx_ys = dict()
        for treatment_name in self._treatment_names:
            mtx_ys[treatment_name] = pd.DataFrame()
            for lead in treatments_lead:
                mtx_ys[treatment_name].loc[:, str(lead)] = treatments_lead[lead][treatment_name]

        mtx_ys[self._outcome_name] = pd.DataFrame()
        for lead in outcome_lead:
            mtx_ys[self._outcome_name].loc[:, str(lead)] = outcome_lead[lead]

        # preds_dict is a DataFrame
        preds_dict = SampleSplitModel.fit_and_predict_mult(self._all_baseline_models, features_fit, 
                                                           mtx_ys, folds)

        # need to extract the data from preds_dict ...
        treatment_residuals = {}
        for lead in self.leads:
            lead_index = self.leads.index(lead)
            treatment_residuals[lead] = dict()
            for treatment_name in self._treatment_names:
                treatment_residuals[lead][treatment_name] = \
                    treatments_lead[lead][treatment_name] - preds_dict.loc[treatment_name].loc[:, lead_index]

        outcome_residuals = {}
        for lead in self.leads:
            lead_index = self.leads.index(lead)
            outcome_residuals[lead] = outcome_lead[lead] - preds_dict.loc[self._outcome_name].loc[:, lead_index]

        return treatment_residuals, outcome_residuals, features_error
        
    def predict_baseline(self, common_features, lead_features, fold_fit_info):
        '''
        :param common_features: features common to all leads
        :param lead_features: lead-specific features
        :param fold_fit_info: same data format as folds variable in fit_baseline_models_featurized
        '''
        features_fit = self._concat_common_union_lead(common_features, lead_features)
        features_error = features_fit[Model.ERROR_VAR_NAME]

        # preds_dict is a DataFrame
        preds_dict = SampleSplitModel.predict_mult(self._all_baseline_models, features_fit, fold_fit_info)

        treatment_prediction = {}
        for lead in self.leads:
            lead_index = self.leads.index(lead)
            treatment_prediction[lead] = dict()
            for treatment_name in self._treatment_names:
                treatment_prediction[lead][treatment_name] = preds_dict.loc[treatment_name].loc[:, lead_index]

        outcome_prediction = {}
        for lead in self.leads:
            lead_index = self.leads.index(lead)
            outcome_prediction[lead] = preds_dict.loc[self._outcome_name].loc[:, lead_index]

        return outcome_prediction, treatment_prediction, features_error

    def _concat_common_union_lead(self, common_features_dict, lead_features_dict):
        #Returns a varname -> combined features (across all leads)
        combined = common_features_dict.copy()
        for varname in common_features_dict:
            for lead in self.leads:
                lead_features = lead_features_dict[lead][varname]
                combined_colnames = combined[varname].columns.values
                combined[varname] = pd.concat([combined[varname], lead_features], axis=1, join='inner')
                combined[varname].columns = \
                    pd.Index(np.concatenate((combined_colnames, lead_features.columns.values)))
        return combined

    #Baseline Info
    def outcome_coefficients(self, lead):
        lead_index = self.leads.index(lead)
        model = self._baseline_outcome_models
        coefficients = model.get_feature_info(avg_splits=True)
        return coefficients[lead_index]

    def treatment_coefficients(self, lead, treatment_name):
        lead_index = self.leads.index(lead)
        model = self._baseline_treatment_models[treatment_name] # CrossFitContainer
        coefficients = model.get_feature_info(avg_splits=True)

        return coefficients[lead_index]
    
    def baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        #TODO: complete
        pass

    def baseline_fit_diagnostics(self):
        #TODO: complete
        pass

    def fit_error_model(self, features_fit, err):
        model = self._error_model
        mtx_x = features_fit

        mtx_y = pd.DataFrame()
        for lead in self.leads:
            mtx_y.loc[:, str(lead)] = abs(err[lead])

        model.fit(mtx_x=mtx_x, vec_y=mtx_y)
    
    def error_model_predict(self, features_fit):
        error_prediction = {}

        model = self._error_model
        mtx_x = features_fit
        predictions_y = model.predict(mtx_x)

        for lead in self.leads:
            lead_index = self.leads.index(lead)
            error_prediction[lead] = predictions_y.iloc[:, lead_index]

        return error_prediction
    
    @staticmethod
    def gen_prepredicted(df):
        #TODO: complete
        pass

class DynamicDML(DoubleMLLikeModel):
    '''
    A series of DoubleML models, each lead contains a separate first stage model that corresponds to forecasting
    the outcome at a given lead. There is also a common causal_model that corresponds to causal impacts of treatments
    which are jointly learned from all models.
    '''
    LEAD_LEVEL_NAME = "lead"

    def _time_from_index(self, idx):
        return idx.get_level_values(self._schema.get_time_col_name()).values

    def __init__(self, schema, 
                 baseline_model=LassoCV(), 
                 causal_model=OLS(), 
                 error_model=LassoCV(), 
                 feature_builders=None, 
                 treatment_builders=None,
                 training_filter=None,
                 options=DDMLOptions(),
                 outcome_model_type=FeatureGenerator.LEVEL_MODEL,
                 treatment_diff_models=[],
                 sample_splitter=KFold(n_splits=2, shuffle=True),
                 cluster_date=True,
                 cv_structure_fn=None,
                 multi_task=False,
                 no_constant=False):
        '''
        Create a new instance of an effect model.

        :param Schema schema: The schema for subsequent training and prediction data
        :param baseline_model: Instance with subclass Model to be used for 
            computing baseline treatment and outcome prediction models. 
            This object may also be a dict which points from each column name to a corresponding Model.
        :param CausalModel causal_model: Model to be used for computing treatment effects
        :param Model error_model: Model to be used for estimating average (absolute) error size as a function of 
            features (i.e. heteroskedasticity function)
        :param feature_builders: List of VarBuilder objects used to create features for first stage regressions
        :param treatment_builders: List of VarBuilder objects used to create treatments for second stage regressions
        :param training_filter: function that takes the feature generator and estimation_dataset and returns a vector
            of bools which indicates which observations should be used for training. Default is all observations.
        :param DDMLOptions options: Model options
        :param outcome_model_type: FeatureGenerator.LEVEL_MODEL (default) trains first stage model in levels.
            FeatureGenerator.DIFF_MODEL trains first stage outcome model on first differences
        :param treatment_diff_models: list of treatments that are estimated in first differences (Default is LEVEL)
        :param sample_splitter: member of sklearn.model_selection used for sample splitting. Default is KFold.
        :param cluster_date: Bool (default True) input for whether or not to cluster standard erros at the level of the
            date column
        :param cv_structure_fn: function that takes the df multiindex and returns labelled structure.
            Used by either GroupKFold or StratifiedKFold.
            Default is to use the time variable.
        :param multi_task: Bool (default False) to indicate whether one instance of the specified baseline model will
            be used to make predictions for multiple leads.  (Only certain models have this capability, for instance
            CNTKCausalModel).  If False, then N copies of the model will be used to model the outcome for each lead.
        :param no_constant: Bool (default False) to force the construction of ConstVar treatments with all
            available interactions. If True, these constants are omitted.
        '''
        if feature_builders is None:
            feature_builders = get_featurizer(schema)
        super().__init__(schema, causal_model, treatment_builders, feature_builders, sample_splitter,
                         cluster_date, no_constant)
        
        if not isinstance(baseline_model, (dict, Model, SampleSplitModel)):
            raise Exception('Invalid type for baseline_model')
        verify.istype(options, DDMLOptions)


        # Initialize inputs attributes
        self.__options = options

        self._outcome_model_type = outcome_model_type
        self._treatment_diff_models = treatment_diff_models
        
        self._aux_dataframe = None
        
        #TODO: Think about getting rid of training_filter
        self.__training_filter = training_filter
        if cv_structure_fn is not None:
            self._cv_structure_fn = cv_structure_fn
        else:
            self._cv_structure_fn = self._time_from_index
        

        if treatment_builders is not None:
            if not no_constant:
                all_ints = np.unique([int for treatment_builder in treatment_builders
                                      for int in treatment_builder.interactor.interaction_levels])
                treatment_builders.append(ConstVar(interaction_levels=all_ints))
            
            builder_ct = 0
            for builder in treatment_builders:
                builder.var_builder_sig = (str(builder_ct) + '. ') + builder.var_builder_sig
                builder_ct += 1

        #TODO:: Allow to be more general
        if multi_task:
            self._base_and_error_models = MultiTaskBaseAndError(schema, baseline_model, causal_model, 
                                                                error_model, self._sample_splitter.n_splits, 
                                                                options.leads)
        else:
            self._base_and_error_models = SeqDoubleML.gen_SeqDoubleML(schema, baseline_model, causal_model, 
                                                                      error_model, treatment_builders, 
                                                                      feature_builders, self._sample_splitter.n_splits,
                                                                      options.leads)
        
        #Intermediate info for the fit functions:
        self.__usable_data = None

        
    def __repr__(self):
        '''
        Not quite usable as instantiation
        '''
        return "%s(%r, BaseAndError: %r, %r, %r, %r, training_filter: %s, %r, %r, %r, %r, %r, cv_structure_fn: %s)" % \
            (self.__class__.__name__, self._schema, self._base_and_error_models, self._causal_model,
             self._feature_generator._feature_builders, self._treatment_generator._builders, #pylint: disable=protected-access
             id(self.__training_filter) if self.__training_filter is not None else None,
             self.options, self._outcome_model_type, self._treatment_diff_models,
             self._sample_splitter, self._cluster_date,
             id(self._cv_structure_fn) if self._cv_structure_fn is not None else None)
        
    @property
    def options(self):
        '''
        Return the options given during initialization
        '''
        return self.__options
    
    @property
    def aux_dataframe(self):
        '''
        Return the auxiliary dataframe used to compute marginal effects
        '''
        return self._aux_dataframe

    @staticmethod
    def outcome_colname():
        '''
        Return the column name of the outcome variable used to compute the exogenous features
        '''
        return FeatureGenerator.outcome_colname()

    def __get_treatment_schema(self):
        '''
        Create a schema for the treatments using the estimation schema and appending a column def for the 
        residual computation that will be used as the treatment variable when computing effects
        '''
        treatment_coldefs = self._schema.get_col_defs() + [ColDef(DoubleMLLikeModel._TREATMENT_COLNAME,
                                                                  DataType.NUMERIC, ColType.TREATMENT_RESIDUAL)]
        return Schema(treatment_coldefs, self._schema.get_time_col_name(), self._schema.get_panel_col_names())

    def _get_auxiliary_dataframe(self, estimation_dataset):
        '''
        Create an auxiliary dataframe. The index of which consists of every unique combination of 
            panel_vars + discrete treatment interactions in the data nd the values of which give
            average conditional values for each continuous interaction variable
        
        :param estimation_dataset: the full estimation_dataset
        '''

        warnings.filterwarnings("ignore") #ignoring duplicate error on index/col duplicate in groupbys below

        #list of all unique continuous interactions used across feturizers
        cont_columns = estimation_dataset.schema.get_colnames_bydatatype(DataType.NUMERIC)
        base_cont = [[col for col in j.interactor.unq_cols if col in cont_columns] 
                     for j in self.treatment_generator.feature_builders]
        continuous_interactions = list(np.unique(list(itertools.chain.from_iterable(base_cont)))) 

        #list of all unique discrete interactions used across feturizers
        base_disc = [[col for col in j.interactor.unq_cols if col not in cont_columns]  
                     for j in self.treatment_generator.feature_builders]
        discrete_interactions = list(np.unique(list(itertools.chain.from_iterable(base_disc))))         

        #list of all unique discrete treatments + panel_vars
        all_cols = list(np.unique(estimation_dataset.schema.get_panel_col_names() + discrete_interactions)) 
        
        if len(continuous_interactions) > 0:
            aux_data = estimation_dataset.data.groupby(all_cols).agg({a : \
                np.mean for a in continuous_interactions}).reset_index()
        else:
            aux_data = estimation_dataset.data.groupby(all_cols).agg(['count']).reset_index()

        aux_data = aux_data.sort_values(by=all_cols)
        aux_data = aux_data.set_index(all_cols).transpose()

        warnings.filterwarnings("default") #bring back warnings
        return aux_data

    def _apply_training_filter(self, estimation_dataset, features, treatments, 
                               outcomes):
        '''
        Apply training filter to get a subset of all relevant data structures
        '''
        if self.__training_filter is None:
            useable_data = estimation_dataset
        else:
            keep = self.__training_filter(self._fg_for_type(self._oname), estimation_dataset)
            
            features = {varname: features[varname].loc[keep, :] for varname in features}

    
            if treatments is not None:
                treatments = {treatment : treatments[treatment].loc[keep, :] for treatment in treatments}
            if outcomes is not None:
                outcomes = outcomes.loc[keep, :]
            #Filtered data need not have constant time delta
            useable_data = EstimationDataSet(estimation_dataset.data.loc[keep, :], estimation_dataset.schema, 
                                             validators=[])

        return useable_data, features, treatments, outcomes

    @staticmethod
    def _compute_treatment_leads(dataset):

        cols = dataset.get_all_cols_by_coltype(ColType.TREATMENT)
        panels = cols.groupby(dataset.group_labels)

        panels_dict = {treatment : panels[treatment] 
                       for treatment in dataset.schema.get_colnames_bycoltype(ColType.TREATMENT)}
        return panels_dict
    
    @staticmethod
    def _compute_outcome_leads(dataset):
        #If you want to make more options here, note that you may need to generate custom column names 
        # and insure they are concsistent with treatment_lead_colnames and outcome_lead_colnames
        cols = dataset.get_all_cols_by_coltype(ColType.OUTCOME)
        cols = cols.rename(columns={cols.columns[0] : DynamicDML.outcome_colname()})
        #If there were more than 1 element of cols, an error would have been triggered earlier in the code
        col = cols[DynamicDML.outcome_colname()] 

        panels = col.groupby(dataset.group_labels)
        return panels

    def _get_treat_leads_to_model(self, treatment_panels):
        treatment_leads = {}
        for treatment_name in self._schema.get_colnames_bycoltype(ColType.TREATMENT):
            if self.treatment_model_type(treatment_name) == FeatureGenerator.LEVEL_MODEL:
                gened_leads = PdGroupByEx.gen_leads(treatment_panels[treatment_name], self.options.leads)
                treatment_leads[treatment_name] = PdSeriesEx.concat_along_rows(gened_leads)
            else: # FeatureGenerator.DIFF_MODEL:
                gened_fore_diffs = PdGroupByEx.gen_fore_diffs(treatment_panels[treatment_name], self.options.leads)
                treatment_leads[treatment_name] = PdSeriesEx.concat_along_rows(gened_fore_diffs) 
        return treatment_leads

    def _get_outcome_leads(self, outcome_panels): 
        if self._outcome_model_type == FeatureGenerator.LEVEL_MODEL:
            outcome_leads = PdSeriesEx.concat_along_rows(PdGroupByEx.gen_leads(outcome_panels, self.options.leads))
        else: # FeatureGenerator.DIFF_MODEL:
            outcome_leads = PdSeriesEx.concat_along_rows(PdGroupByEx.gen_fore_diffs(outcome_panels, self.options.leads))

        return outcome_leads

    def _fg_fit_by_lead_lead(self, estimation_dataset, lead):
        if isinstance(self._feature_generator, dict):
            return {varname: fg.fit_by_lead(estimation_dataset, outcome_lead=lead) 
                    for varname, fg in self._feature_generator.items()}
        else:
            features_by_lead = self._feature_generator.fit_by_lead(estimation_dataset, outcome_lead=lead) 
            feat_by_lead_dict = {type: features_by_lead for type in self._varnames + [Model.ERROR_VAR_NAME]}
            return feat_by_lead_dict

    def _fg_fit_by_lead_all(self, estimation_dataset):
        return {lead: self._fg_fit_by_lead_lead(estimation_dataset, lead) for lead in self.options.leads}

    def get_design_matrices(self, dataset):
        '''
        Gets all the design (and related) matrices from all the stages
        :param dataset: Needs to have same schema as estimation dataset but can be much smaller
        :return: Tuple of baseline_variables, baseline_features, train_fold, causal_outcomes, causal_treatments.
            The first two are nested dictionaries of lead->varname->data
            The inner datasets of the first two, and train_fold all have the same row index so can be concatted.
            The final two datasets are the causal regression.
            The causal variables will be the original values (possibly scaled) rather than residuals.
            For the error model, query the first two with Model.ERROR_VAR_NAME (Note: folds are meaningless here).
        '''
        #simplified encoder setup
        encoders = dataset.gen_encoders()
        self._fg_set_encoders(encoders)
        self._treatment_generator.encoder = self._encoders
        dataset.fit_encoders(encoders)

        usable_data, common_features, lead_features, outcome_lead, treatments_lead, folds = \
            self._gen_baseline_matrices(dataset)
        baseline_features = SeqDoubleML.concat_common_lead(common_features, lead_features, self.options.leads)
        baseline_variables = treatments_lead
        for lead in self.options.leads:
            baseline_variables[lead][self._oname] = outcome_lead[lead]
        ex_idx = outcome_lead[self.options.leads[0]].index
        train_fold = EstimationDataSet._convert_folds_to_series(folds, ex_idx, do_test=False) #pylint: disable=protected-access

        treatment_residuals = {lead: dataset.get_all_cols_by_coltype(ColType.TREATMENT) for lead in self.options.leads}
        outcome_residuals = {lead: dataset.get_all_cols_by_coltype(ColType.OUTCOME) for lead in self.options.leads}
        causal_treatments, causal_outcomes, _ = self._get_causal_matrices(dataset, usable_data, encoders, 
                                                                          treatment_residuals, outcome_residuals)

        return baseline_variables, baseline_features, train_fold, causal_outcomes, causal_treatments

    def _fit_baseline_models(self, estimation_dataset):
        if self._encoders is None:
            self._set_encoders(estimation_dataset)
        #verify.istype(estimation_dataset, EstimationDataSet)

        self.__usable_data, common_features, lead_features, outcome_lead, treatments_lead, folds = \
            self._gen_baseline_matrices(estimation_dataset)
        self._treatment_residuals, self._outcome_residuals, self._features_error = \
            self._base_and_error_models.fit_baseline_models_featurized(common_features, lead_features, outcome_lead, 
                                                                       treatments_lead, folds)

        estimation_dataset.set_folds_from_other_index(folds, self.__usable_data.data.index)

        for lead in self.options.leads:
            self._outcome_residuals[lead].name = DoubleMLLikeModel._OUTCOME_RESID_NAME + " " + \
                DynamicDML.LEAD_LEVEL_NAME + str(lead)

    def _gen_baseline_matrices(self, estimation_dataset):
        outcome_panels = DynamicDML._compute_outcome_leads(estimation_dataset)
        treatment_panels = DynamicDML._compute_treatment_leads(estimation_dataset)

        treatments = self._get_treat_leads_to_model(treatment_panels)
        outcomes = self._get_outcome_leads(outcome_panels)

        common_features = self._fg_fit_common_dict(estimation_dataset)

        usable_data, common_features, treatments, outcomes = \
            self._apply_training_filter(estimation_dataset, common_features,
                                        treatments, outcomes)

        common_features_index = common_features[self._oname].index
        num_idx = [[j] for j in range(len(common_features_index))]
        if isinstance(self._sample_splitter, StratifiedKFold):
            folds = list(self._sample_splitter.split(X=num_idx, y=self._cv_structure_fn(common_features_index)))
        elif isinstance(self._sample_splitter, GroupKFold):
            folds = list(self._sample_splitter.split(X=num_idx, groups=self._cv_structure_fn(common_features_index)))
        else:
            folds = list(self._sample_splitter.split(X=num_idx))


        #Generate the feature sets
        lead_features = self._fg_fit_by_lead_all(estimation_dataset)
        
        outcome_lead = {}
        treatments_lead = {}
        for lead in self.options.leads:
            outcome_lead[lead] = outcomes[self.outcome_lead_colname(lead)]
            treatments_lead[lead] = {treatment_name : \
                treatments[treatment_name][self.treatment_lead_colname(treatment_name, lead)] 
                                     for treatment_name in treatments}

        return usable_data, common_features, lead_features, outcome_lead, treatments_lead, folds

    @staticmethod
    def _map_unique_to_integer(values):
        dic = {ni: indi for indi, ni in enumerate(set(values))}
        return [dic[ni] for ni in values]


    def _fit_causal_model(self, estimation_dataset, rm_baseline_interm_info=False, subst_treatment_builders=None):
        verify.not_none(self._treatment_residuals, "Call fit_baseline_models() before fit_causal_model()")
        if subst_treatment_builders is not None:
            self._treatment_generator = TreatmentGenerator(self._schema, subst_treatment_builders)
            #self._base_and_error_models.set_treatment_generator(self._treatment_generator) #don't need
        
        self._verify_unique_signatures()
        self._aux_dataframe = self._get_auxiliary_dataframe(estimation_dataset)

        all_lead_treatments, all_lead_outcomes, all_obs_index = \
            self._get_causal_matrices(estimation_dataset, self.__usable_data, self._encoders, 
                                      self._treatment_residuals, self._outcome_residuals)
        
        self._causal_model.fit(all_lead_treatments, all_lead_outcomes, cluster_groups=all_obs_index)

        all_lead_error = all_lead_outcomes - self._causal_model.predict(all_lead_treatments)
        err = {}
        for lead in self.options.leads:
            with warnings.catch_warnings():
                warnings.simplefilter(action='ignore', category=PerformanceWarning)
                err[lead] = all_lead_error.xs(lead, level=DynamicDML.LEAD_LEVEL_NAME, drop_level=True)
            err[lead].name = FeatureGenerator.error_colname() + " " + DynamicDML.LEAD_LEVEL_NAME + str(lead)
        self._base_and_error_models.fit_error_model(self._features_error, err)


        if rm_baseline_interm_info:
            self.__usable_data = None
            self._treatment_residuals = None
            self._outcome_residuals = None
            self._features_error = None

    def _get_causal_matrices(self, estimation_dataset, usable_data, encoders, treatment_residuals, 
                             outcome_residuals):
        #Mostly static function
        leads = self.options.leads
        all_treatment_names = estimation_dataset.schema.get_colnames_bycoltype(ColType.TREATMENT)

        all_lead_treatments = pd.DataFrame()
        all_lead_outcomes = pd.Series()
        all_lead_index = []
        all_obs_index = []
        treatment_residuals_refdate = {}
        for lead in reversed(leads):  
            treatment_residuals_refdate[lead] = {}
            for treatment in all_treatment_names:
                treatment_residuals_refdate[lead][treatment] = {lead - impacting_lead : \
                    treatment_residuals[impacting_lead][treatment] 
                                                                for impacting_lead in leads}
                
        treatments_tmp = {lead: self._treatment_generator.get_technical_treatment(treatment_residuals_refdate[lead], 
                                                                                  usable_data, encoders) 
                          for lead in leads}
            
        for lead in reversed(leads):  
            #Cluster by outcome date
            obs_index = PdMultiIndexEx.to_frame(treatments_tmp[lead].index)
            obs_index[estimation_dataset.schema.get_time_col_name()] += estimation_dataset.data_interval * lead
            if self._cluster_date:
                obs_index = obs_index[estimation_dataset.schema.get_time_col_name()]
                obs_index = obs_index.values
            else:
                obs_index = [tuple(x) for x in obs_index.values]

            lead_o_resid = pd.concat([outcome_residuals[lead]], keys=[lead], names=[DynamicDML.LEAD_LEVEL_NAME])
            if len(all_lead_outcomes) == 0:
                all_lead_outcomes = lead_o_resid #using series.append here would squash the multiindex
            else:
                all_lead_outcomes = all_lead_outcomes.append(lead_o_resid)
            lead_ts_resid = pd.concat([treatments_tmp[lead]], keys=[lead], names=[DynamicDML.LEAD_LEVEL_NAME])
            all_lead_treatments = all_lead_treatments.append(lead_ts_resid)

            all_lead_index.extend([lead]*len(treatments_tmp[lead]))
            all_obs_index.extend(obs_index)
        
        all_obs_index = DynamicDML._map_unique_to_integer(all_obs_index)            
        all_lead_index = np.array(all_lead_index)
        all_obs_index = np.array(all_obs_index)
        
        all_lead_outcomes.name = DoubleMLLikeModel._OUTCOME_RESID_NAME
        return all_lead_treatments, all_lead_outcomes, all_obs_index
      
    #Individual baseline prediction function used by optimizer. Could get rid of
    def base_pred_treat_frame(self, features, features_by_lead, treatment_name, leads=None):
        '''
        Get a dataframe of baseline predicted treatments for each specified lead period

        :param features:
        :param features_by_lead:
        :param treatment_name:
        :param leads: The default is first lead
        '''
        
        if leads is None:
            leads = [self.options.leads[0]]
        
        ret = self._base_and_error_models.base_pred_treat_frame(features, features_by_lead, treatment_name, leads)

        return pd.DataFrame(ret, index=pd.Index(leads, name=DynamicDML.LEAD_LEVEL_NAME), \
            columns=features.index).transpose()
    
    #Individual baseline prediction function used by optimizer. Could get rid of
    def base_pred_outcome_frame(self, common_features, features_by_lead, leads=None):
        '''
        Get a dataframe of baseline predicted outcomes for each specified lead period

        :param common_features:
        :param features_by_lead:
        :param leads: The default is first lead
        '''
        
        if leads is None:
            leads = [self.options.leads[0]]
        ret = self._base_and_error_models.base_pred_outcome_frame(common_features, features_by_lead, leads)
        return pd.DataFrame(ret, index=pd.Index(leads, name=DynamicDML.LEAD_LEVEL_NAME), 
                            columns=common_features.index).transpose()

    def get_diffed_vars(self):
        diffed_vars = self._treatment_diff_models
        if self._outcome_model_type == FeatureGenerator.DIFF_MODEL:
            diffed_vars.append(self._oname)
        return diffed_vars


    def _predict(self, estimation_dataset, ret_pred=None):
        #Eventually put in the fit_union stuff (from fit)

        #outcome_panels = DynamicDML._compute_outcome_leads(estimation_dataset)
        treatment_panels = DynamicDML._compute_treatment_leads(estimation_dataset)
        
        common_features = self._fg_fit_common_dict(estimation_dataset)
        treatment_leads = self._get_treat_leads_to_model(treatment_panels)

        lead_features = self._fg_fit_by_lead_all(estimation_dataset)
        
        folds = estimation_dataset.fold_fit_info
        outcome_predicted_base, treatment_prediction, features_error = \
            self._base_and_error_models.predict_baseline(common_features, lead_features, folds)


        if ret_pred is not None:
            base_predictions_d = {}
            for outcome_lead in self.options.leads:
                pred_d = treatment_prediction[outcome_lead].copy()
                pred_d[self._oname] = outcome_predicted_base[outcome_lead]
                base_predictions_d[outcome_lead] = pd.concat(pred_d, names=[Model.VARIABLE_COLNAME])
            base_predictions = pd.concat(base_predictions_d, names=[DynamicDML.LEAD_LEVEL_NAME])
            PdDataframeEx.assign_inplace(ret_pred, base_predictions)

        treatment_residuals = {}
        #for lead in self.options.leads: #I think this doesn't matter
        #    treatment_residuals[lead] = {treatment : pd.Series(index=features.index) for treatment in treatment_leads}
        for outcome_lead in self.options.leads:
            #turn into residuals
            treatment_residuals[outcome_lead] = {}
            for treatment_name in treatment_leads:
                t_colname = self.treatment_lead_colname(treatment_name, outcome_lead)
                treatment_values = treatment_leads[treatment_name][t_colname]
                treatment_residuals[outcome_lead][treatment_name] = treatment_values - \
                    treatment_prediction[outcome_lead][treatment_name]


        trt_features = {}
        for outcome_lead in self.options.leads:
            recentered_treatment_residuals = {}
            for treatment_name in treatment_leads:
                recentered_treatment_residuals[treatment_name] = {outcome_lead - impacting_lead : \
                    treatment_residuals[impacting_lead][treatment_name] for impacting_lead in self.options.leads}
            
            treatment_features_list = [x.build(estimation_dataset, self._encoders, recentered_treatment_residuals) 
                                       for x in self.treatment_generator.feature_builders]
            all_columns = []
            for x in treatment_features_list:
                all_columns.extend([name for name in x.columns.names if not name is None])
            all_columns = np.unique(all_columns)
            trt_features[outcome_lead] = PdDataframeEx.concat_along_rows([ \
                pd.DataFrame(x.values, index=x.index, columns=PdMultiIndexEx.align_index(x.columns, all_columns)) 
                for x in treatment_features_list])
            
        outcome_predicted_impact = {lead: self._causal_model.predict(trt_features[lead]) 
                                    for lead in self.options.leads}
            
        predictions = []
        for outcome_lead in self.options.leads:
            if self._outcome_model_type == FeatureGenerator.LEVEL_MODEL:
                predictions.append(outcome_predicted_base[outcome_lead] + outcome_predicted_impact[outcome_lead])
            else: # FeatureGenerator.DIFF_MODEL:
                predictions.append(outcome_predicted_base[outcome_lead] + outcome_predicted_impact[outcome_lead] + \
                    estimation_dataset.data[self._oname].tolist())
                
        err_pred = self._base_and_error_models.error_model_predict(features_error)

        avg_log_error = []
        for outcome_lead in self.options.leads:
            avg_log_error.append(err_pred[outcome_lead])

        predictions_df = PdSeriesEx.concat_along_rows(predictions, levels=self.options.leads, 
                                                      name=DynamicDML.LEAD_LEVEL_NAME)
        predictions_df = predictions_df.T.set_index(np.repeat(Model.PREDICTION_COL_NAME, 
                                                              predictions_df.shape[1]), append=True).T

        avg_log_error_df = PdSeriesEx.concat_along_rows(avg_log_error, levels=self.options.leads, 
                                                        name=DynamicDML.LEAD_LEVEL_NAME)
        avg_log_error_df = avg_log_error_df.T.set_index(np.repeat(Model.AVG_ERROR_COL_NAME, 
                                                                  avg_log_error_df.shape[1]), append=True).T
        
        pred = pd.concat([predictions_df, avg_log_error_df], axis=1)
        pred.columns = pred.columns.droplevel(1)
        pred.columns = pred.columns.rename([self.LEAD_LEVEL_NAME, DoubleMLLikeModel.TYPE_COL_NAME])
        return pred
    
    #Eventually merge with baseline_models_feat_info()
    def outcome_coefficients(self, lead):
        '''
        Get first stage coefficients (averaged over splits) from outcome regression corresponding to the given lead.
        Will account for baseline feature scaling

        :param lead: integer corresponding to preferred lead
        '''
        return self._base_and_error_models.outcome_coefficients(lead)
    
    #Eventually merge with baseline_models_feat_info()
    def treatment_coefficients(self, lead, treatment_name):
        '''
        Get first stage coefficients (averaged over splits) from treatment regression corresponding to the given
        lead and treatment_name.
        Will account for baseline feature scaling

        :param str treatment_name: name of treatment variable
        :param int lead: preferred lead
        '''
        return self._base_and_error_models.treatment_coefficients(lead, treatment_name)

    def _baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        leads = self.options.leads

        feature_info_d = self._base_and_error_models.baseline_models_feat_info(avg_splits, combine_vars)
        if combine_vars:
            return pd.concat(feature_info_d, names=[DynamicDML.LEAD_LEVEL_NAME])
        else:
            #Don't want to retun nest list, so aggregate across leads per varname (but nested dict is in other order)
            varnames = feature_info_d[leads[0]].keys()
            feature_info = {}
            for varname in varnames:
                feature_info[varname] = pd.concat({lead:feature_info_d[lead][varname] for lead in leads}, 
                                                  names=[DynamicDML.LEAD_LEVEL_NAME])
                if avg_splits: #if combine_var, the below was already done in DoubleML
                    feature_info[varname].index = feature_info[varname].index.droplevel(1) #just 0s
            return feature_info

    def _baseline_fit_diagnostics(self):
        fit_diagnostics = pd.concat(self._base_and_error_models.baseline_fit_diagnostics(), 
                                    names=[DynamicDML.LEAD_LEVEL_NAME])
        return fit_diagnostics


    def get_marginal_effects(self, treatment_name, competition_col, leads=None, filter_dic=None):
        return DDMLMarginalEffects(self._schema, treatment_name, self, competition_col, leads, filter_dic)



#Bring back col names

    def outcome_lag_colname(self, lag):
        '''
        Return the column name of the lag outcome variable for the specified lag

        :param lag: The lag period for which to get the column name
        '''
        return PdGroupByEx.LAG_COL_NAME.format(DynamicDML.outcome_colname(), lag)

    def treatment_lagdiff_colname(self, treatment_name, lag):
        '''
        Return the column name of the lag treatment diff variable for the specified lag and treatment

        :param lag: The lag period for which to get the column name
        :param treatment_name: string corresponding to the name of a TREATMENT column
        '''
        return PdGroupByEx.LAG_DIFF_COL_NAME.format(treatment_name, lag)

    def treatment_lead_colname(self, treatment_name, lead):
        '''
        Return the column name of the lead treatment diff variable for the specified lead

        :param treatment_name:
        :param lead: The lead period for which to get the column name
        '''
        if self.treatment_model_type(treatment_name) == FeatureGenerator.LEVEL_MODEL:
            return PdGroupByEx.LEAD_COL_NAME.format(treatment_name, lead)
        else:
            return PdGroupByEx.LEAD_DIFF_COL_NAME.format(treatment_name, lead)

    def outcome_lead_colname(self, lead):
        '''
        Return the column name of the lead outcome variable for the specified lead

        :param lead: The lead period for which to get the column name
        '''
        if self._outcome_model_type == FeatureGenerator.LEVEL_MODEL:
            return PdGroupByEx.LEAD_COL_NAME.format(DynamicDML.outcome_colname(), lead)
        else: # FeatureGenerator.DIFF_MODEL:
            return PdGroupByEx.LEAD_DIFF_COL_NAME.format(DynamicDML.outcome_colname(), lead)



    def treatment_model_type(self, treatment_name):
        if treatment_name in self._treatment_diff_models:
            return FeatureGenerator.DIFF_MODEL
        else:
            return FeatureGenerator.LEVEL_MODEL

    @staticmethod
    def gen_prepredicted_baselines(df, base_error_class=None):
        '''
        Converts a DataFrame of recorded predictions in dictionary of PrePredicted models
        '''
        if base_error_class is None:
            base_error_class = SeqDoubleML
        return base_error_class.gen_prepredicted(df)
    
    #Tools dealing with translating (baseline) prediction recordings into true predictions
    @staticmethod
    def translate_rec_to_prediction(rec_df, leads, date_col):
        '''
        Advances the targets according to lead (in the fitting they were lagged to the information date)
        and then averages across the folds of the model.
        '''
        lead_df = {}
        for lead in leads:
            df = rec_df.xs((lead), level=DynamicDML.LEAD_LEVEL_NAME)
            df = df.pipe(PdDataframeEx.groupbynot, [date_col]).shift(lead)
            lead_df[lead] = df
        pred_df = pd.concat(lead_df, names=[DynamicDML.LEAD_LEVEL_NAME])
        
        return pred_df

    @staticmethod
    def translate_prediction_to_rec(pred_df, date_col, exp_ind=True):
        '''
        Takes back the targets according to lead (because in fitting they are lagged to the information date)
        '''
        leads = pred_df.index.levels[pred_df.index.names.index(DynamicDML.LEAD_LEVEL_NAME)]
        orig_ord = pred_df.index.names.copy()
        if exp_ind:
            old_idx = pred_df.index
            new_idx = pd.MultiIndex.from_product([pred_df.index.levels[i] 
                                                  for i in range(old_idx.nlevels)], names=old_idx.names)
            pred_df = pred_df.reindex(new_idx)
        lead_df = {lead: (pred_df.xs((lead), level=DynamicDML.LEAD_LEVEL_NAME)
                          .pipe(PdDataframeEx.groupbynot, [date_col]).shift(-lead))
                   for lead in leads}
        rec_df = pd.concat(lead_df, names=[DynamicDML.LEAD_LEVEL_NAME]).reorder_levels(orig_ord)
        
        return rec_df
    
    @staticmethod
    def get_rec_df_from_csv(fname, schema): 
        '''
        Reads a csv file with recordings from a DynamicDML prediction
        :param fname: filename of csv of recorded model predictions
        :param schema: Schema object
        :returns: DataFrame of prediction recordings
        '''
        return SSPrePredicted.get_rec_df_from_csv(fname, schema, [Model.VARIABLE_COLNAME, DynamicDML.LEAD_LEVEL_NAME])
