# ------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# ------------------------------------------------------------------------
import copy
import warnings
import pandas as pd
import numpy as np
from abc import ABCMeta, abstractmethod

import msecore.verify as verify
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdonehotencoder import PdOneHotEncoder
from msecoreml.sample_splitting import SingleFoldFullOverlap

from pricingengine.schema import Schema
from pricingengine.models.model import Model, SampleSplitModel
from pricingengine.models.ensemble import CrossFitContainer
from pricingengine.models.lasso import LassoCV
from pricingengine.models.linearmodel import LinearModel
from pricingengine.models.causalmodel import CausalModel
from pricingengine.models.ols import OLS
from pricingengine.models.prepredicted import PrePredicted, SSPrePredicted

from pricingengine.estimation.estimation_dataset import EstimationDataSet
from pricingengine.estimation.typed_dataset import ColType, DataType
from pricingengine.estimation.treatment_generator import TreatmentGenerator
from pricingengine.estimation.feature_generator import FeatureGenerator
from pricingengine.estimation.regression import Estimation
from pricingengine.variables.var_builder import VarBuilder
from pricingengine.variables.const_var import ConstVar

from sklearn.model_selection import GroupKFold, KFold


#pylint: disable=redefined-variable-type, too-many-instance-attributes, too-many-locals

class DoubleMLLikeModel(Estimation):
    '''
    An abstract baseclass for DoubleML-like models (DoubleML/DynamicDML, etc.)
    '''
    _TREATMENT_COLNAME = "treatment"
    _OUTCOME_RESID_NAME = "outcome_resid"
    NO_SPLIT = 'no split'
    TYPE_COL_NAME = 'type'
    def __init__(self, schema, causal_model, treatment_builders, feature_builders, sample_splitter,
                 cluster_date=True, no_constant=False):
        '''
        :param schema: The expected schema of datasets that will be fit
        :param CausalModel causal_model: Model to be used for computing treatment effects in second
            stage regression
        :param treatment_builders: List of VarBuilder objects used to create treatments for second stage regressions
        :param feature_builders: List of VarBuilder objects used to create features for first stage regressions
        :param sample_splitter: member of sklearn.model_selection used for sample splitting. Default is KFold.
        :param cluster_date: Bool (default True) input for whether or not to cluster standard erros at the level of the
            date column
        :param no_constant: Bool (default False) to force the construction of ConstVar treatments with all
            available interactions. If True, these constants are omitted.
        '''
        super().__init__(schema, cluster_date)
        if sample_splitter == DoubleMLLikeModel.NO_SPLIT:
            sample_splitter = SingleFoldFullOverlap()
        self._sample_splitter = sample_splitter
        if sample_splitter is not None:
            self.__num_splits = sample_splitter.n_splits
        else:
            self.__num_splits = None
        
        self._oname = self._schema.get_colname_bycoltype(ColType.OUTCOME)
        self._varnames = self._schema.get_colnames_bycoltype(ColType.TREATMENT) + [self._oname]
        
        if treatment_builders is None: 
            treatment_builders = []

        treatment_builders_dml = copy.deepcopy(treatment_builders)
        self._no_constant = no_constant
        if not no_constant and treatment_builders != []:
            all_ints = np.unique([int for treatment_builder in treatment_builders
                                  for int in treatment_builder.interactor.interaction_levels])
            treatment_builders_dml.append(ConstVar(interaction_levels=all_ints))


        builder_ct = 0
        for builder in treatment_builders_dml:
            builder.var_builder_sig = (str(builder_ct) + '. ') + builder.var_builder_sig
            builder_ct += 1


        if isinstance(feature_builders, dict):
            self._feature_generator = {type: FeatureGenerator(self._schema, feature_builders=feature_builders[type])
                                       for type in self._varnames + [Model.ERROR_VAR_NAME]}
        else:
            self._feature_generator = FeatureGenerator(self._schema, feature_builders=feature_builders)
        self._treatment_generator = TreatmentGenerator(self._schema, treatment_builders_dml)
        
        self._causal_model = causal_model

        #Intermediate info for the fit functions:
        self._features_error = None
        self._outcome_residuals = None
        self._treatment_residuals = None

    @property
    def num_splits(self):
        '''
        Number of splits for cross-fitting
        '''
        return self.__num_splits

    @property
    def treatment_generator(self):
        '''
        Return the treatment generator 
        '''
        return self._treatment_generator  

    @treatment_generator.setter
    def treatment_generator(self, treatment_generator):
        '''
        Set the treatment generator 
        '''
        self._treatment_generator = treatment_generator

    #Eventual delete. See who else uses this. Probably get rid of (and provide accessors since might be dictionary)
    #@property
    #def feature_generator(self):
    #    '''
    #    Return the feature generator or feature generator dictionary
    #    '''
    #    return self._feature_generator

    @property
    def causal_model(self):
        '''
        Return the causal model
        '''
        return self._causal_model 

    @causal_model.setter
    def causal_model(self, causal_model):
        self._causal_model = causal_model

    def baseline_fit_diagnostics(self):
        '''
        Get various prediction diagnostics for all baseline (first stage) regressions
        '''
        return self._baseline_fit_diagnostics()

    @abstractmethod
    def _baseline_fit_diagnostics(self):
        pass

    def baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        '''
        Return baseline model coefficients for all first stage models for the given lead

        :param bool avg_splits: If true avgs diagnostics acrss model splits (otherwise returns
            separately).
        :param combine_vars: Try to combine the different variable vectors into a df (works if same feature vector)
            If True, will return a single DF. If false, will return a dict:varname->DF (aggregated across leads)
        '''
        return self._baseline_models_feat_info(avg_splits, combine_vars)
    

    @abstractmethod
    def _baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        pass


    def _fit(self, estimation_dataset):
        self.fit_baseline_models(estimation_dataset) #stores intermediate info

        ##Residual on Residual Modeling##
        self.fit_causal_model(estimation_dataset, rm_baseline_interm_info=True)   

    def fit_baseline_models(self, estimation_dataset):
        '''
        Fit baseline (but not causal models) on DDML object

        :param estimation_dataset: EstimationDatset object on which baseline models are fit
        '''
        return self._fit_baseline_models(estimation_dataset)

    @abstractmethod
    def _fit_baseline_models(self, estimation_dataset):
        pass

    def fit_causal_model(self, estimation_dataset, rm_baseline_interm_info=False, subst_treatment_builders=None):
        '''
        Fit only the causal model of DDML. Requires that you have already fit baseline models.
        
        :param estimation_dataset:
        :param rm_baseline_interm_info: If you want to fit several different causal models,
            pass in rm_baseline_interm_info=False
        :param subst_treatment_builders: overwrites existing treatment_builders in case you want to try a 
            different model
        '''
        self._is_fit = True
        return self._fit_causal_model(estimation_dataset, rm_baseline_interm_info, subst_treatment_builders)

    @abstractmethod
    def _fit_causal_model(self, estimation_dataset, rm_baseline_interm_info=False, subst_treatment_builders=None):
        pass
    
        
    def _verify_unique_signatures(self):
        '''
        verify that all treatment builder signatures are unique
        '''
        signatures = [x.var_builder_sig for x in self.treatment_generator.feature_builders]
        if len(signatures) != len(np.unique(signatures)):
            raise Exception('Featurizer Signatures must be unique.')
    
    def _fg_set_encoders(self, encoders=None):
        if encoders is None:
            encoders = self._encoders
        if isinstance(self._feature_generator, dict):
            for feat_gen in self._feature_generator.itervalues():
                feat_gen.encoder = encoders
        else:
            self._feature_generator.encoder = encoders

    def _fg_for_type(self, name): #varname or Model.ERROR_VAR_NAME
        if isinstance(self._feature_generator, dict):
            return self._feature_generator[name]
        return self._feature_generator
        
    def _fg_fit_common_dict(self, dataset):
        if isinstance(self._feature_generator, dict):
            features_dict = {type: fg.fit_common(dataset) for type, fg in self._feature_generator.items()}
        else:
            features = self._feature_generator.fit_common(dataset)
            features_dict = {type: features for type in self._varnames + [Model.ERROR_VAR_NAME]}
        return features_dict
        
    def _init_encoders(self, dataset):
        #Need to do some extra things here
        super()._init_encoders(dataset)
        self._fg_set_encoders()
        self._treatment_generator.encoder = self._encoders

    def _treatment_scale(self):
        scales = [fb.scale_list for fb in self.treatment_generator.feature_builders]
        return np.array([x[0] for y in scales for x in y])


class DoubleML(DoubleMLLikeModel):
    #the r before the quote mark makes it a "raw string literal" so that backslashes are just those 
    # (so \n is two letters rather than a new line). This makes it easier for tex symbols
    r'''
    Generic Double ML Model. Estimates the coefficient :math:`\beta` from the following partially linear model

    :math:`Y = f(X) + \beta \cdot D + \epsilon`

    :math:`D = g(X) + \mu`

    Note that the base models are cross-fit across folds (so a model's predictions for its training data are not used).
    '''

    def __init__(self, schema,
                 baseline_model=LassoCV(),
                 causal_model=OLS(),
                 error_model=LassoCV(),
                 treatment_builders=None,
                 feature_builders=None,
                 #training_filter=None,
                 sample_splitter=KFold(n_splits=2, shuffle=True),
                 cluster_date=True):
        '''
        Initialize a new DoubleML instance.

        :param schema: The expected schema of datasets that will be fit
        :param baseline_model: Instance with subclass Model to be used for computing baseline
            treatment and outcome prediction models in first stage regressions.
            This object may also be a dict which points from each column name (all treatment and outcome variables)
            to a corresponding Model.
        :param CausalModel causal_model: Model to be used for computing treatment effects in second
            stage regression
        :param Model error_model: Model to be used for estimating average (absolute) error size as a 
            function of features (i.e. heteroskedasticity function)
        :param feature_builders: List of VarBuilder objects used to create features for first stage regressions
        :param treatment_builders: List of VarBuilder objects used to create treatments for second stage regressions
        :param sample_splitter: member of sklearn.model_selection used for sample splitting. Default is KFold.
        :param cluster_date: Bool (default True) input for whether or not to cluster standard erros at the level of the
            date column
        '''
        super().__init__(schema, causal_model, treatment_builders, feature_builders, sample_splitter, cluster_date)
        verify.istype(schema, Schema)
        
        #self.__training_filter = training_filter

        self._initialize_baseline_models(baseline_model)
        self._causal_model = causal_model
        self.__error_model = error_model
        
    def __repr__(self):
        '''
        Not quite usable as instantiation
        '''
        return "%s(%r, %r, %r, %r, %r, %r, %r, %r)" % \
            (self.__class__.__name__, self._schema, self._all_baseline_models, self._causal_model, self.__error_model,
             self._treatment_generator._builders, self._feature_generator._feature_builders, #pylint: disable=protected-access
             self._sample_splitter, self._cluster_date)


    @property
    def error_model(self):
        '''
        Return the model used to comptue predicted (absolute) error size
        '''
        return self.__error_model 


    @property
    def treatment_baseline_models(self):
        '''
        Return the treatment baseline models
        '''
        return self._baseline_treatment_models 

    @property
    def outcome_baseline_models(self):
        '''
        Return the outcome baseline models
        '''
        return self._baseline_outcome_models 

    def feature_scale(self, varname):
        scales = [fb.scale_list for fb in self._fg_for_type(varname).feature_builders]
        return np.array([x[0] for y in scales for x in y])


    def _initialize_baseline_models(self, baseline_model):
        '''
        Initialize all models
        '''
        all_treatments = self._schema.get_colnames_bycoltype(ColType.TREATMENT)
        self._baseline_treatment_models = {}
        if not isinstance(baseline_model, dict):
            self._baseline_outcome_models = CrossFitContainer.wrap_single_model_if_needed(baseline_model, 
                                                                                          self.num_splits)
            for treatment in all_treatments:
                from copy import deepcopy
                self._baseline_treatment_models[treatment] = deepcopy(self._baseline_outcome_models)
        else:
            try:
                mod = CrossFitContainer.wrap_generic_if_needed(baseline_model[self._oname], self.num_splits)
                self._baseline_outcome_models = mod
                for treatment in all_treatments:
                    mod = CrossFitContainer.wrap_generic_if_needed(baseline_model[treatment], self.num_splits)
                    self._baseline_treatment_models[treatment] = mod

            except:
                raise Exception('If baseline_model input is dictionary, it must specify an instance of model class ' +
                                'for all key values that correspond to column names of TREATMENT or OUTCOME variables')

        self._all_baseline_models = self._baseline_treatment_models.copy() #shallow copy is good
        self._all_baseline_models[self._oname] = self._baseline_outcome_models


    def _fit_baseline_models(self, estimation_dataset):
        if self._encoders is None:
            self._set_encoders(estimation_dataset)
            
        features = self._fg_fit_common_dict(estimation_dataset)

        features_index = features[self._oname].index
        num_idx = [[j] for j in range(len(features_index))]
        if isinstance(self._sample_splitter, GroupKFold):
            groups = features_index.get_level_values(self._schema.get_time_col_name()).values
            folds = list(self._sample_splitter.split(X=num_idx, groups=groups))
        else:
            folds = list(self._sample_splitter.split(X=num_idx))


        tr_colnames = estimation_dataset.schema.get_colnames_bycoltype(ColType.TREATMENT)
        tr_dict_value = {treatment : estimation_dataset.data[treatment] for treatment in tr_colnames}
        out_value = estimation_dataset.get_col_by_coltype(ColType.OUTCOME)
        treat_resid, out_resid = self.fit_baseline_models_featurized(features, out_value, tr_dict_value, folds)
        self._treatment_residuals = treat_resid
        self._outcome_residuals = out_resid
        estimation_dataset.set_fold_training_info(folds)

    def _predict(self, dataset, ret_pred=None):
        features_dict = self._fg_fit_common_dict(dataset)
        b_pred, treat_pred = self.predict_baseline(features_dict, folds=dataset.fold_fit_info)
        
            
        if ret_pred is not None:
            pred_d = treat_pred.copy()
            pred_d[self._oname] = b_pred
            PdDataframeEx.assign_inplace(ret_pred, pd.concat(pred_d, names=[Model.VARIABLE_COLNAME]))

        base_out_pred = pd.Series(b_pred, index=features_dict[self._oname].index)

        treat_res = {}
        for treatment_name in dataset.schema.get_colnames_bycoltype(ColType.TREATMENT):
            treat_res[treatment_name] = {0 : dataset.data[treatment_name] - treat_pred[treatment_name]} 
        

        tech_treatment = self._treatment_generator.get_technical_treatment(treat_res, dataset, self._encoders)
        bonus_out_pred = self.causal_model.predict(tech_treatment)

        pred = base_out_pred + bonus_out_pred
        pred = pred.reset_index().merge(dataset.get_all_cols_by_coltype(ColType.OUTCOME).reset_index(), 
                                        on=pred.index.names, how='left')
        pred = pred.rename(columns={0 : 'Prediction'})

        return pred
    
    def predict_baseline(self, features, folds=None):
        '''
        :param features: Either a single feature matrix or a dictionary:varname->feature matrix
        :param folds:
        '''
        if not isinstance(features, dict):
            features = {varname: features for varname in self._varnames}
        t_prediction_d = {}
        for t_name, t_model in self._baseline_treatment_models.items():
            t_prediction_d[t_name] = t_model.predict(features[t_name], folds)
            
        o_prediction = self._baseline_outcome_models.predict(features[self._oname], folds)

        return o_prediction, t_prediction_d


    def fit_baseline_models_featurized(self, features, outcome, treatments, folds):
        '''
        Fit first-stage baseline models (but not causal model) for predicting treatment and outcome.
        Sub-utility used by fit_baseline_models().

        :param features: dictionary of features used for prediction (expects one for error too)
        :param outcome: dictionary of leads mapping to series of outcome leads
        :param treatments: double dictionary mapping from lead and treatment_name to series of treatment leads
        :param folds: list of train test splits used for cross validation
        '''
        #Make sure DDML passes in error
        vec_ys = treatments.copy()
        vec_ys[self._oname] = outcome
        self._features_error = features.pop(Model.ERROR_VAR_NAME)
        preds_dict = SampleSplitModel.fit_and_predict_mult(self._all_baseline_models, features, 
                                                           vec_ys, folds)
        residuals = {varname: vec_ys[varname] - preds_dict[varname] for varname in vec_ys.keys()}

        outcome_residual = residuals.pop(self._oname)
        return residuals, outcome_residual

    def _fit_causal_model(self, estimation_dataset, rm_baseline_interm_info=True, 
                          subst_treatment_builders=None):
        if subst_treatment_builders is not None:
            self._treatment_generator = TreatmentGenerator(self._schema, subst_treatment_builders)
        
        treatment_residuals_refdate = {}
        for treatment in estimation_dataset.schema.get_colnames_bycoltype(ColType.TREATMENT):
            treatment_residuals_refdate[treatment] = {0 : self._treatment_residuals[treatment]}
        outcome_residual = self._outcome_residuals
        encoders = self._encoders

        #Eventually get rid of treatment_residuals_refdate (done so as to reuse get_technical_treatment)
        technical_treatment = self._treatment_generator.get_technical_treatment(treatment_residuals_refdate, 
                                                                                estimation_dataset, encoders)
        
        if self._cluster_date:
            time_col = estimation_dataset.schema.get_time_col_name()
            obs_index = PdMultiIndexEx.to_frame(technical_treatment.index)[time_col]
            cluster_groups = np.array(self._map_unique_to_integer(obs_index))
        else:
            cluster_groups = None

        self._causal_model.fit(technical_treatment, outcome_residual, cluster_groups=cluster_groups)

        error = outcome_residual - self._causal_model.predict(technical_treatment)
        abs_error = abs(error)
        abs_error.name = FeatureGenerator.error_colname()
        self.error_model.fit(abs_error, self._features_error)
        if rm_baseline_interm_info:
            self._features_error = None
            self._treatment_residuals = None
            self._outcome_residuals = None

    #Eventually merge with baseline_models_feat_info()
    def baseline_outcome_coefficients(self):
        '''
        Return coefficients (averaged over splits) from first stage outcome regression
        Will account for baseline feature scaling
        '''

        beta_raw = self.outcome_baseline_models.get_feature_info(avg_splits=True)
        scale = self.feature_scale(self._oname).T
        beta = (beta_raw / scale).T
        return beta
    
    #Eventually merge with baseline_models_feat_info()
    def baseline_treatment_coefficients(self, treatment_name):
        '''
        Get first stage coefficients (averaged over splits) from treatment regression corresponding to the given
        treatment_name.
        Will account for baseline feature scaling
        '''

        beta_raw = self.treatment_baseline_models[treatment_name].get_feature_info(avg_splits=True)
        scale = self.feature_scale(treatment_name).T
        beta = (beta_raw / scale).T
        return beta

    def _baseline_models_feat_info(self, avg_splits=False, combine_vars=False):
        feat_info_dict = {varname: ssmodel.get_feature_info(avg_splits)
                          for varname, ssmodel in self._all_baseline_models.items()}
        for feat_info in feat_info_dict.values():
            feat_info.index = Estimation._squash_int_ind_levels(feat_info.index) #pylint: disable=protected-access
        if combine_vars:
            feat_info_df = pd.concat(feat_info_dict, names=[Model.VARIABLE_COLNAME], axis=1).T
            #if avg_splits:
            #    feat_info_df.index = feat_info_df.index.droplevel(1) #just 0s
            return feat_info_df
        else:
            return feat_info_dict

    def _baseline_fit_diagnostics(self):
        pred_fit_diagnostics_dict = {varname: ssmodel.get_fit_diagnostics()
                                     for varname, ssmodel in self._all_baseline_models.items()}
        pred_fit_diagnostics = pd.concat(pred_fit_diagnostics_dict, names=[Model.VARIABLE_COLNAME])
        
        pred_fit_diagnostics.index = pred_fit_diagnostics.index.droplevel(1) #just 0s

        return pred_fit_diagnostics


    @staticmethod
    def gen_prepredicted(df):
        '''
        Converts a DataFrame of recorded predictions in dictionary of PrePredicted models
        '''
        model_dict = {}
        grouped = df.groupby(level=Model.VARIABLE_COLNAME)
        for varname, var_df in grouped:
            var_df.index = var_df.index.droplevel(Model.VARIABLE_COLNAME)
            var_df.columns = [Model.PREDICTION_COL_NAME]
            model_dict[varname] = SSPrePredicted(var_df)
        return model_dict
    
    @staticmethod
    def get_rec_df_from_csv(fname, schema): 
        '''
        Reads a csv file with recordings from a DoubleML prediction
        :param fname: filename of csv of recorded model predictions
        :param schema: Schema object
        :returns: DataFrame of prediction recordings
        '''
        return SSPrePredicted.get_rec_df_from_csv(fname, schema, [Model.VARIABLE_COLNAME])

