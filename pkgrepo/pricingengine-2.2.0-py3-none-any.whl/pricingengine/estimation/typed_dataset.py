#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from enum import Enum
import pandas as pd
from pricingengine.schema import DataType, SchemaValidationError, SchemaValidationException
from pricingengine.dataset import DataSet
import msecore.verify as verify

class ColType(Enum):
    """
    Input IDs for know pricing data column content
    """
    TREATMENT = 9
    OUTCOME = 10
    TREATMENT_RESIDUAL = 11
    OUTCOME_RESIDUAL = 12
    PREDETERMINED = 13

    """
    A description of the data contained in a single column

    - The column tagged as ColType.ITEM must have DataType.CATEGORICAL
    - The column tagged as ColType.OUTCOME must be have DataType.NUMERIC
    - The column tagged as ColType.TREATMENT must be have DataType.NUMERIC
    """

class TypedDataSet(DataSet):
    '''
    Dataset class
    '''
    __id_to_required_type = {
        ColType.OUTCOME: [DataType.NUMERIC],
        ColType.TREATMENT: [DataType.NUMERIC],
        ColType.TREATMENT_RESIDUAL : [DataType.NUMERIC],
        ColType.OUTCOME_RESIDUAL : [DataType.NUMERIC],
        ColType.PREDETERMINED : [DataType.NUMERIC, DataType.CATEGORICAL]
    }

    def __init__(self, data, schema, required_types):

        """
        Initializes a new instance of the DataSet class. The DataSet class combines time series data, a schema that
        specifies the column meta-data for the the given time series data.

        The given data-schema pair needs to adhere to the following expectations:
        
        - Each column defined in the given schema must be contained in the corresponding given time series data
        - Each column must have a data type corresponding to its schema DataType as follows:

            - DataType.NUMERIC: integer or floating-point
            - DataType.DATE_TIME: datetime
            - DataType.CATEGORICAL: string or integer

        - In the specified schema, the name of the column with id ITEM must also be included in the 
          list of panel column names

        :param data: The time series data to be used for computing effects
        :param schema: The schema specifying the meta-data for the time series
        """
        index_cols = schema.get_panel_col_names()
        if schema.get_time_col_name() is not None:
            index_cols.append(schema.get_time_col_name())
        super().__init__(data, schema, index_cols)

        # Verify that the required IDs are in the schema
        used_col_types = set(x.col_type for x in self._schema.get_col_defs() if x.col_type != None)
        missing_ids = [id for id in required_types if id not in used_col_types]
        verify.true(len(missing_ids) == 0, "the following required columns were not defined: {0}".format( \
            ",".join([str(x) for x in missing_ids])))

        #Verify the column type is correct for columns with a column id
        for col_type in used_col_types:
            required_datatypes = TypedDataSet.__id_to_required_type[col_type]
            if self._schema.get_coldef_bycoltype(col_type).data_type not in required_datatypes:
                raise SchemaValidationException(SchemaValidationError.IncorrectColumnType, 
                                                "{0} must be {1}".format(str(col_type), str(required_datatypes)))

        # Break into panels and save indexing data
        panel_vars = self.schema.get_panel_col_names()
        if len(panel_vars) == 0:   
            self._group_labels = [""] * self.num_rows
        else:
            series = pd.Series([None] * self.num_rows)
            for group_key, group_value in self._data.groupby(level=panel_vars).indices.items():
                # Pandas cannot re-group using a tuple (bug) so use a string as the label. 
                # We don't use the label except for debugging.
                series.iloc[group_value] = [str(group_key)] * len(group_value) 
            self._group_labels = list(series)

    @property
    def group_labels(self):
        '''
        A list parallel to the rows of the dataset with a label for each row.
        The labels can be passed to a Pandas groupby call to group data using known groups.
        '''
        return self._group_labels
