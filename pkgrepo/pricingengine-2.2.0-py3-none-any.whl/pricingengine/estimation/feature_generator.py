#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------

import functools
import itertools
import warnings


import numpy as np
import pandas as pd

from sklearn.preprocessing import MinMaxScaler
import msecore.verify as verify
from pricingengine.estimation.estimation_dataset import EstimationDataSet
from pricingengine.dataset import DataSet
from pricingengine.estimation.typed_dataset import ColType
from pricingengine.schema import DataType
from pricingengine.featurizers.default_dynamic_featurizer import get_featurizer
from pricingengine.variables.var_builder import VarBuilder
from pricingengine.variables.own_var import OwnVar
from pricingengine.variables.p_to_p_var import PToPVar
from pricingengine.variables.peer_agg_var import PeerAggVar
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdgroupbyex import PdGroupByEx
from msecoreml.pdonehotencoder import PdOneHotEncoder
from msecoreml.pdseriesex import PdSeriesEx
from msecoreml.pdscaler import PdScaler
from msecoreml.pdmultiindexex import PdMultiIndexEx


#pylint: disable=redefined-variable-type




#-----------------------------------------------------------------------------------------------------------------------
# Data
#-----------------------------------------------------------------------------------------------------------------------
class FeatureGenerator():
    '''
    Creates an FeatureGenerator object
    '''

    __OUTCOME_VAR_NAME = "outcome_var"
    __ERROR_VAR_NAME = "error"
    __OUTCOME_VAR_LAG_AVG_NAME = "lag avg outcome var"
    LEVEL_MODEL = 'level'
    DIFF_MODEL = 'diff'

    #-------------------------------------------------------------------------------------------------------------------
    # API
    #-------------------------------------------------------------------------------------------------------------------
    def __init__(self, schema, feature_builders=None):
        '''
        Create a new instance of a Feature generator.

        :param schema: The schema describing the input datase for which to compute features
        :param options: User-specified feature generation options
        '''
        predet_cols = schema.get_colnames_bycoltype(ColType.PREDETERMINED)
        self.__scaler_by_colname = None
        self._encoder_by_colname = None
        self._schema = schema

    
        if feature_builders is None:
            feature_builders = get_featurizer(schema)

        self._lead_feature_builders = []
        self._common_feature_builders = []
        #set the lag_feature_from_outcome properties
        for x in feature_builders:
            if isinstance(x, (OwnVar, PToPVar, PeerAggVar)) and \
                schema.get_coldef_byname(x.treatment_column).col_type == ColType.PREDETERMINED:
                x.lag_feature_from_outcome = True
        for x in feature_builders:
            tmp = np.intersect1d(predet_cols, x.interactor.get_unique_cols())
            if ((hasattr(x, '_lag_feature_from_outcome')) and (x.lag_feature_from_outcome)) or (len(tmp) > 0):
                self._lead_feature_builders.append(x)
            else:
                self._common_feature_builders.append(x)
                

        self._feature_builders = self._common_feature_builders + self._lead_feature_builders



    def fit_all(self, dataset):
        verify.istype(dataset, DataSet)

        if len(self._common_feature_builders) > 0:
            panel_cols = dataset.schema.get_panel_col_names()
            with warnings.catch_warnings():
                warnings.simplefilter(action='ignore', category=FutureWarning) #group by cols vs index
                panel = dataset.data.groupby(panel_cols)            
            feature_list = [x.build(dataset, self._encoder_by_colname, panel=panel)
                            for x in self.feature_builders]
            features = self._process_features(feature_list)
        else:
            features = pd.DataFrame(index=dataset.data.index)
        return features

    def fit_common(self, dataset):
        '''
        Build common features for the given dataset using previously fit encoders
        '''
        verify.istype(dataset, EstimationDataSet)
        if len(self._common_feature_builders) > 0:
            panel_cols = dataset.schema.get_panel_col_names()
            with warnings.catch_warnings():
                warnings.simplefilter(action='ignore', category=FutureWarning) #group by cols vs index
                panel = dataset.data.groupby(panel_cols)
            feature_list = [x.build(dataset, self._encoder_by_colname, panel=panel)
                            for x in self._common_feature_builders]
            features = self._process_features(feature_list)

        else:
            features = pd.DataFrame(index=dataset.data.index)
        return features

    def fit_by_lead(self, dataset, outcome_lead=0):
        '''
        Build lead based features for the given dataset using previously fit encoders
        '''
        verify.istype(dataset, EstimationDataSet)
        if len(self._lead_feature_builders) > 0:
            with warnings.catch_warnings():
                warnings.simplefilter(action='ignore', category=FutureWarning) #group by cols vs index
                panel = dataset.data.groupby(dataset.schema.get_panel_col_names())
            feature_list = [x.build(dataset, self._encoder_by_colname, panel=panel, outcome_lead=outcome_lead)
                            for x in self._lead_feature_builders]
            features = self._process_features(feature_list)
        else:
            features = pd.DataFrame(index=dataset.data.index)
        return features

    @staticmethod
    def _process_features(feature_list):
        all_columns = []
        for x in feature_list:
            all_columns.extend([name for name in x.columns.names if not name is None])
        all_columns = np.unique(all_columns)
        to_concat = [pd.DataFrame(x.values, index=x.index,
                                  columns=PdMultiIndexEx.align_index(x.columns, all_columns))
                     for x in feature_list]
        return PdDataframeEx.concat_along_rows(to_concat)

    @property
    def encoder(self):
        return self._encoder_by_colname

    @encoder.setter
    def encoder(self, enc):
        self._encoder_by_colname = enc

    @property
    def feature_builders(self):
        return self._feature_builders

    @staticmethod
    def outcome_colname():
        '''
        Return the column name of the outcome variable used to compute the exogenous features
        '''
        return FeatureGenerator.__OUTCOME_VAR_NAME

    @classmethod
    def error_colname(cls):
        '''
        Return the column name of the error variable used for inference
        '''
        return cls.__ERROR_VAR_NAME

    @property
    def outcome_lagavg_colname(self):
        '''
        Return the column name of the outcome lag average variable used for the features
        '''
        return FeatureGenerator.__OUTCOME_VAR_LAG_AVG_NAME

    def outcome_lag_colname(self, lag):
        '''
        Return the column name of the lag outcome variable for the specified lag

        :param lag: The lag period for which to get the column name
        '''
        return PdGroupByEx.LAG_COL_NAME.format(FeatureGenerator.outcome_colname(), lag)

    def treatment_lagdiff_colname(self, treatment_name, lag):
        '''
        Return the column name of the lag treatment diff variable for the specified lag and treatment

        :param lag: The lag period for which to get the column name
        :param treatment_name: string corresponding to the name of a TREATMENT column
        '''
        return PdGroupByEx.LAG_DIFF_COL_NAME.format(treatment_name, lag)


    @staticmethod
    def get_interaction_format_string(scale_col_name):
        '''
        Return the format string for genering interaction column names for interactions with the specified scale 
        column

        :param scale_col_name: The name of the scale column with which dummies will be interacted.
        '''
        return scale_col_name + " # {0}"


    #------------------------------------------------------------------------------------------------------------------
    # Utility methods
    #------------------------------------------------------------------------------------------------------------------
    def _align_index(self, df):
        
        panel_colnames = self._schema.get_panel_col_names() + [VarBuilder.CUSTOM_FEATURE_INDEX] + \
                         ['auxilary_interaction']
        columns = PdMultiIndexEx.align_index(df.columns, panel_colnames)
        ret = pd.DataFrame(df.values, index=df.index, columns=columns)
        return ret

    @staticmethod
    def _transform(transformer, col, do_fit):
        return  transformer.fit_transform(col) if do_fit else transformer.transform(col)


    #------------------------------------------------------------------------------------------------------------------
    # Public Featurization Methods
    #------------------------------------------------------------------------------------------------------------------

    @staticmethod
    def build_interactions(scalar_col, dummies):
        format_string = FeatureGenerator.get_interaction_format_string(scalar_col.name)
        generate_interaction = lambda x: PdDataframeEx.interact_series_with_dataframe(x, scalar_col, format_string)
        ret = [generate_interaction(x) for x in dummies]
        for col in ret:
            col.columns.rename(None, inplace=True)
        return ret

    def get_continuous_covariates(self, dataset, incl_non_seasonal=True, incl_seasonal=False):
        '''
        Get all numerical columns from the input features besides QUANTITY and PRICE, each individually normalized
        '''

        if self.schema != dataset.schema:
            raise Exception('Schema mismatch')

        allowable_coltype = []
        if incl_non_seasonal:
            allowable_coltype.append(None)
        if incl_seasonal:
            allowable_coltype.append(ColType.PREDETERMINED)

        col_defs = self.schema.get_col_defs()
        return [dataset.get_col_by_name(x.col_name) for x in col_defs 
                if (x.col_type in allowable_coltype) and x.data_type is DataType.NUMERIC]


    def get_dummy_covariates(self, dataset, do_fit, exclude=None, incl_non_seasonal=True, incl_seasonal=True):
        '''
        Return all dummy variables from CATEGORICAL columns
        '''
        if exclude is None:
            exclude = []
        if self.schema != dataset.schema:
            raise Exception('Schema mismatch')
        
        allowable_coltype = []
        if incl_non_seasonal:
            allowable_coltype.append(None)
        if incl_seasonal:
            allowable_coltype.append(ColType.PREDETERMINED)

        features_to_encode = [dataset.get_col_by_name(x) 
                              for x in self.schema.get_colnames_bydatatype(DataType.CATEGORICAL) 
                              if x not in exclude and 
                              self.schema.get_coldef_byname(x).col_type in allowable_coltype and
                              x != self._schema.get_time_col_name()]
        dummies = [self._transform(self._encoder_by_colname[x.name], x, do_fit) for x in features_to_encode]
        for dum in dummies:
            dum.columns.names = [None]

        return dummies

    def get_dummies_predet_lead(self, dataset, do_fit, groups, lead, exclude=None):
        if exclude is None:
            exclude = []
        if self.schema != dataset.schema:
            raise Exception('Schema mismatch')
        
        allowable_coltype = [ColType.PREDETERMINED]

        dummies = [self._transform(self._encoder_by_colname[x], PdGroupByEx.gen_leads(groups[x], [lead])[0], do_fit)
                   for x in self.schema.get_colnames_bydatatype(DataType.CATEGORICAL) 
                   if x not in exclude and self.schema.get_coldef_byname(x).col_type in allowable_coltype]
 
        for dum in dummies:
            dum.columns.names = [None]

        return dummies

    def get_treatment_lag_diffs(self, treatment_name, num_lag_periods):
        '''
        Get Treatment Lag Differences. For each panel series pv = [x₀, x₁, x₂], compute:
        col₀ = [NA, NA, x₂-x₀]
        col₁ = [NA, x₁-x₀, x₂-x₁]
        upto the specified number of lag periods (specified in the FeatureGenerator options).
        '''
        return PdGroupByEx.gen_lag_diffs(self._treatment_panels[treatment_name], num_lag_periods)

    def get_outcome_lag_diffs(self, num_lag_periods):
        '''
        Get Treatment Lag Differences. For each panel series pv = [x₀, x₁, x₂], compute:
        col₀ = [NA, NA, x₂-x₀]
        col₁ = [NA, x₁-x₀, x₂-x₁]
        upto the specified number of lag periods (specified in the FeatureGenerator options).
        '''
        return PdGroupByEx.gen_lag_diffs(self._outcome_panels, num_lag_periods)


    def get_outcome_lags(self, num_lag_periods):
        '''
        Get outcome lags. For each panel series qv = [x₀, x₁, x₂], compute:
        col₀ = [NA, NA, x₀]
        col₁ = [NA, x₀, x₁]
        upto the specified number of lag periods (specified in the FeatureGenerator options).
        '''
        return [self._outcome_panels.shift(0)] + PdGroupByEx.gen_lags(self._outcome_panels, num_lag_periods)

    def get_treatment_lags(self, treatment_name, num_lag_periods):
        '''
        Get outcome lags. For each panel series qv = [x₀, x₁, x₂], compute:
        col₀ = [NA, NA, x₀]
        col₁ = [NA, x₀, x₁]
        upto the specified number of lag periods (specified in the FeatureGenerator options).
        '''
        return [self._treatment_panels[treatment_name].shift(0)] + \
            PdGroupByEx.gen_lags(self._treatment_panels[treatment_name], num_lag_periods)



    def get_outcome_lagavg(self, num_lag_periods=4, half_life=1.375):
        '''
        Gets outcome Lag Average. This is the exponential weighted mean of the outcome variable qv withing a 
        rolling window across each panel, where the resulting column is normalized. The exponential weighted average
       for instance i is computed as below, where the halflife is specified in the FeatureGenerator options.
        wᵢ := (exp(log(0.5) / halflife))ⁱ
        xᵢ = (wₜ·xₜ + wₜ₋₁·xₜ₋₁ + .... w₀·x₀) / (wₜ + wₜ₋₁ + ... + w₀)
        '''
        return PdGroupByEx.exp_moving_avg(self._outcome_panels, half_life, 
                                          num_lag_periods + 1).rename(self.outcome_lagavg_colname)

    def apply_scaling(self, features_to_scale, do_fit):
        '''
        Scale generated features based on previously fit PdScaler
        '''
        features_scaled = PdSeriesEx.concat_along_rows([self._transform(self.__scaler_by_colname[x.name], x, do_fit) 
                                                        for x in features_to_scale])
        return features_scaled

    def set_scaling(self, features_to_scale, scale_type=MinMaxScaler):
        '''
        Set values of PdScaler for future scaling of features
        '''
        if self.__scaler_by_colname is None:
            self.__scaler_by_colname = {x.name : PdScaler(scale_type) for x in features_to_scale}
        else:
            self.__scaler_by_colname.update({x.name : PdScaler(scale_type) for x in features_to_scale})



