# ------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# ------------------------------------------------------------------------
import numpy as np

from pricingengine.estimation.typed_dataset import ColType, DataType
from pricingengine.variables.own_var import OwnVar
from pricingengine.variables.own_past_agg_var import OwnPastAggVar
from pricingengine.variables.const_var import ConstVar
#pylint: disable=too-many-locals

def get_featurizer(schema, max_lag=4, min_lag=0, geometric_weight=.8, exclude_dummies=None):
    '''
    Retruns a list of VarBuilders used to create features for a dynamic_dml application. Unlike default_panel_featurizer
    this function DOES create features from lagged values of TREATMENT and OUTCOME
    variables

    :param schema:
    :param max_lag: max number of lags to use to construct features (default=4)
    :param min_lag: min number of lags to use to construct features (default=0),
        this includes the current period)
    :param geometric_weight: decay value corresponding to lagged data that is applied to create
        an aggregate of past lags
    :param exclude_dummies: a list of categorical columns names that the user wishes to exclude from modeling

    :returns: list of VarBuilders
    '''
    if exclude_dummies is None:
        exclude_dummies = []
    outcome_name = schema.get_colname_bycoltype(ColType.OUTCOME)
    treatment_names = schema.get_colnames_bycoltype(ColType.TREATMENT)
    predetermined_vars = schema.get_colnames_bycoltype(ColType.PREDETERMINED)
        #panel_cols = schema.get_panel_col_names()
    categorical_cols = [col for col in schema.get_colnames_bydatatype(DataType.CATEGORICAL)
                        if col not in exclude_dummies]
    pred_disc_vars = np.intersect1d(categorical_cols, predetermined_vars)
    pred_con_vars = [j for j in predetermined_vars if j not in pred_disc_vars]

    features = [
        OwnPastAggVar(outcome_name, geometric_weight=geometric_weight, min_lag=min_lag, max_lag=max_lag,
                      interaction_levels=[[col] for col in categorical_cols]),
        ConstVar(interaction_levels=[[col] for col in categorical_cols]),
        #ConstVar(interaction_levels=[[col] for col in pred_disc_vars]) #included in the line above
        ]

    
    for pred_var in pred_con_vars:
        features.append(OwnVar(pred_var, lag=0))
    #    features.append(OwnVar(pred_var, lag=1))
    #    features.append(OwnVar(pred_var, lag=-1))

    for lag in range(min_lag, max_lag + 1):
        features.append(OwnVar(outcome_name, lag=lag))
        if lag > 0:
            features.append(OwnVar(outcome_name, lag=0, seasonal_diff=lag))
        for treat_name in treatment_names:
            features.append(OwnVar(treat_name, lag=0, seasonal_diff=lag))

    for treat_name in treatment_names:
        int_levels = [[col] for col in categorical_cols]
        features.append(OwnPastAggVar(treat_name, geometric_weight=geometric_weight, min_seasonal_diff=min_lag, 
                                      max_seasonal_diff=max_lag, interaction_levels=int_levels))
    return features
