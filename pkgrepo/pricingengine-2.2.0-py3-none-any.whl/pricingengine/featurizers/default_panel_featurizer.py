# ------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# ------------------------------------------------------------------------
import numpy as np

from pricingengine.estimation.typed_dataset import ColType, DataType
from pricingengine.variables.own_var import OwnVar
from pricingengine.variables.const_var import ConstVar

def get_featurizer(schema, panel_var_dummies=True, time_dummies=True, scale_features=False):
    '''
    Return a list of VarBuilders used to create features for a dynamic_dml application. 
    Unlike default_dynamic_featurizer this function DOES NOT create features from lagged values 
    of TREATMENT and OUTCOME variables

    :param schema:
    :param panel_var_dummies: Bool (default True) for whether we should create dummies from panel vars
    :param time_dummies: Bool (default True) for whether we should create dummies from time vars
    :param scale_features: Bool (default False) for whether numeric columns should be scaled before
        being featurized

    :returns: list of VarBuilders
    '''
    fbs = []
    cat_list = []
    for col_def in schema.get_col_defs():
        if col_def.col_name in schema.get_panel_col_names():
            if panel_var_dummies:
                cat_list.append(col_def.col_name)
        elif col_def.col_name == schema.get_time_col_name():
            if time_dummies:
                cat_list.append(col_def.col_name)
        elif col_def.col_type == ColType.PREDETERMINED or col_def.col_type is None: # gets rid of TREATMENT
            if col_def.data_type == DataType.CATEGORICAL:
                cat_list.append(col_def.col_name)
            else:
                fbs.append(OwnVar(col_def.col_name, scale_core=scale_features))

    fbs.append(ConstVar(interaction_levels=[[col] for col in cat_list]))
    return fbs
