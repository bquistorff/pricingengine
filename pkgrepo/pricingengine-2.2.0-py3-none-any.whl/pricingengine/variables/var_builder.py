# ------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# ------------------------------------------------------------------------
import numpy as np
import pandas as pd
from pricingengine.variables.interactor import Interactor

from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdscaler import PdScaler
from sklearn.preprocessing import StandardScaler, MinMaxScaler



#pylint: disable=too-many-locals, too-many-branches

class VarBuilder():
    '''
    Base class used for treatment construction
    '''
    PEER_TREATMENT_DELIMITER = " on "
    CUSTOM_FEATURE_INDEX = "custom feature"
    BASELINE_PEN_RATIO = .01
    AUX_COL_NAME = 'interaction'
    FEATURE_TYPE_COL_NAME = 'Feature Type'
    LEAD_COL_NAME = 'lead'
    NAN_STR = 'nan'
    IMPACTOR = 'impactor_'
    INTERACTION_SEP = '#'

    def __init__(self, treatment_column, interaction_levels=None, unpenalize_core_treatment=False, scale_core=True):
        '''
        Initialize a new FeatureBuilder for datasets with the specified schema

        :param core_treatment: Name of treatment variable to be used
        :param Interactor interactor: Instance of interactor class that specified how core pull forward feature is 
            interacted
        :param unpenalize_core_treatment: Boolean value. If true, the core_treatment feature will not be penalized 
            by any ML methods used for treatment effect estimation
        '''
        self._treatment_column = treatment_column
        self._interactor = Interactor(interaction_levels=interaction_levels)
        self._unpenalize_core_treatment = unpenalize_core_treatment
        self._scaler = PdScaler(StandardScaler)
        self._scaler_dic = None
        self._num_features = None
        self._num_features_dic = None
        self._core_col_order = None
        self._scale_core = scale_core
        self._var_builder_sig = None

    def __repr__(self):
        '''
        Not usable as instantiation
        '''
        return "%s: %s" % (self.__class__.__name__, self._var_builder_sig)
        
    @property
    def var_builder_sig(self):
        return self._var_builder_sig

    @var_builder_sig.setter
    def var_builder_sig(self, var_builder_sig):
        self._var_builder_sig = var_builder_sig

    def _turn_off_constant_scaling(self):
        if 'Const' in str(type(self)):
            self._scale_core = False

    def verify_sig_exists(self):
        '''
        Make sure that child class provides a treatment builder signature
        '''
        if not hasattr(self, '_var_builder_sig'):
            raise Exception('Child class must provide treatment signature')

    def build(self, estimation_dataset, encoders, treatments=None, panel=None, outcome_lead=0):       
        '''
        Build the feature(s) for the given dataset

        :param estimation_dataset: The estimation_dataset from which to build the features
        :param encoders: Encoders used to create dummies from categorical variables
        :param treatments: Raw treatment residuals used to create treatment features
        :param panel:
        :param outcome_lead:
        :return: A list of series with an index mathcing that of the input dataset and the computed feature values
        '''
        self.verify_sig_exists()
        self._turn_off_constant_scaling()
        

        if treatments is None:
            if 'OwnVar' in str(type(self)) or 'PToPVar' in str(type(self)) or 'PeerAgg' in str(type(self)):
                core_var = self._get_core_feature(panel, estimation_dataset, outcome_lead)
            else:
                core_var = self._get_core_feature(panel, estimation_dataset)
        else:
            core_var = self._get_core_treatment(treatments, estimation_dataset)

        if isinstance(core_var, pd.DataFrame):
            if self._scale_core:
                if self._scaler_dic is None:
                    self._scaler_dic = {}
                    self._num_features_dic = {}
                    self._core_col_order = []
                    for col in core_var:
                        self._scaler_dic[col] = PdScaler(StandardScaler)
                        core_var[col] = self._scaler_dic[col].fit_transform(core_var[col])
                        self._core_col_order.append(col)
                    
                else:
                    for col in core_var:
                        core_var[col] = self._scaler_dic[col].transform(core_var[col])

            to_concat = []
            for col in core_var:
                tmp = self._interactor.build_interactions(core_var[col],
                                                          encoders, 
                                                          estimation_dataset, 
                                                          levels_to_add=col, 
                                                          level_names=list(core_var.columns.names),
                                                          outcome_lead=outcome_lead)

                self._num_features_dic[col] = np.shape(tmp)[1]
                to_concat.extend([tmp])
            all_variables = PdDataframeEx.concat_along_rows(to_concat)
        else:
            if self._scale_core:
                if not self._scaler.is_fit:
                    core_var = self._scaler.fit_transform(core_var)
                else:
                    core_var = self._scaler.transform(core_var)

            all_variables = self._interactor.build_interactions(core_var, encoders, estimation_dataset, 
                                                                outcome_lead=outcome_lead)
            self._num_features = np.shape(all_variables)[1]

        if self._unpenalize_core_treatment:
            unpenalized_values = all_variables.iloc[:, 0] / VarBuilder.BASELINE_PEN_RATIO
            for i, _ in enumerate(unpenalized_values):
                all_variables.iloc[i, 0] = unpenalized_values[i]

        all_variables = all_variables.T.set_index(np.repeat(self._var_builder_sig,
                                                            all_variables.shape[1]), append=True).T
        all_variables.columns = all_variables.columns.rename(VarBuilder.FEATURE_TYPE_COL_NAME, level=-1)

        return all_variables

    @property
    def scale_list(self):
        if self._scaler_dic is None:
            scale = [self._scaler.scale.copy() if self._scale_core else [1.0]  for _ in range(self._num_features)]
            if self.unpenalize_core_treatment:
                scale[0] *= VarBuilder.BASELINE_PEN_RATIO
            return scale
        else:
            scales = []
            for col in self._core_col_order:
                scale = [self._scaler_dic[col].scale.copy()  if self._scale_core else [1.0] 
                         for _ in range(self._num_features_dic[col])]
                if self.unpenalize_core_treatment:
                    scale[0] *= VarBuilder.BASELINE_PEN_RATIO
                scales.extend(scale)
            return scales


    @property
    def interactor(self):
        return self._interactor

    @property
    def treatment_column(self):
        return self._treatment_column

    @property
    def unpenalize_core_treatment(self):
        return self._unpenalize_core_treatment

    def get_indices(self, index):
        return PdMultiIndexEx.get_1level_block_indicator(index, VarBuilder.FEATURE_TYPE_COL_NAME,
                                                         [self.var_builder_sig])
    
    @staticmethod
    def _index_containing_substring(the_list, substring):
        for i, string in enumerate(the_list):
            if substring in string:
                return i
        return -1

