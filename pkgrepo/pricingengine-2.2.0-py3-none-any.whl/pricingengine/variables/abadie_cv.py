#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np
from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx
from pricingengine.variables import sc_functions
from pricingengine.variables import joint_sc_functions

#pylint: disable=unused-argument
#pylint: disable=cell-var-from-loop, redefined-variable-type
#pylint: disable=too-many-locals,too-many-instance-attributes

class AbadieCV(VarBuilder):
    '''
    Construct a synthetic control variable based on abadie (2010). Chose a seperate v_mat
        for each treatment unit. Regularization not enabled.
    '''    
    
    def __init__(self,
                 #core inputs
                 treatment_column,
                 time_column=None,
                 matching_vars=None,
                 #specify pre/post, control/treatment
                 pre_periods=None,
                 post_periods=None,
                 control_filter_dic=None,
                 treatment_filter_dic=None,
                 #synth control options
                 non_neg_weights=True,
                 #standard var_builder options
                 interaction_levels=None,
                 unpenalize_core_treatment=False,
                 scale_core=True):
        '''
        :param treatment_column: Column for which we preform synthetic controls
        :param time_column: Dataframe column used to create the time index. Will default to the time col in the schema. 
        :param matching_vars: Dictionary mapping dataframe columns to a double list. Each element of outer list
            is a moment that will be created. Elements of the sub-list are time periods that will be averaged
            over to create that moment. Defaults to a global avg over the pre-periods of treatment_column

        :param pre_periods: Time periods on which synthetic control is trained.
        :param post_periods: Time periods on which synthetic control is validated.
        :param control_filter_dic: Filter dictionary used to select available control units.
        :param treatment_filter_dic: Filter dictionary used to select additional units for training (beyond controls).

        :param non_neg_weights: Bool which defaults to True to exclude non-negative weights. Setting this to False
            can help acheive a better fit for units which have higher/lower outcomes than all available controls.

        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be 
            collectively interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param unpenalize_core_treatment: Boolean value. If true, the core_treatment feature will not be penalized by 
            any ML methods used for treatment effect estimation
        :param Bool scale_core: Scale core feature to be normalized with variance 1 before creating interactions. 
            If false, do not scale.
        '''
        super().__init__(treatment_column, interaction_levels, unpenalize_core_treatment, scale_core)

        #These 2 get set by the final line
        self._var_builder_sig = "" #NB featurizer signature must be unique
        self._treatment_column = treatment_column
        if matching_vars is None:
            self._matching_vars = {treatment_column : [[]]}
        else:
            self._matching_vars = matching_vars

        self._time_column = time_column
        self._pre_periods = pre_periods
        self._post_periods = post_periods
        self._control_filter_dic = control_filter_dic
        self._treatment_filter_dic = treatment_filter_dic

        self._eligible_control_units = None
        self._eligible_treated_units = None
        self._weights = None
        self._non_neg_weights = non_neg_weights

        self._v_matrix_dic = {}


    def _compute_weights_one(self, moments, time_series):

        weights = []
        for treated_unit in moments.columns:
            control_units = [unit for unit in self._eligible_control_units if unit != treated_unit]
            treated_time_series = time_series.loc[:, [treated_unit]]
            control_time_series = time_series[control_units]
            control_moments = moments[control_units]
            treated_moments = moments.loc[:, [treated_unit]]
            if treated_unit not in self._v_matrix_dic:
                tmp, v_mat = sc_functions.get_weights(
                    treated_moments, control_moments, treated_time_series, control_time_series,
                    non_neg_weights=self._non_neg_weights)
                self._v_matrix_dic[treated_unit] = v_mat
            else:
                tmp, _ = sc_functions.get_weights(
                    treated_moments, control_moments, treated_time_series, control_time_series,
                    non_neg_weights=self._non_neg_weights,
                    V=self._v_matrix_dic[treated_unit])
            
            tmp = list(tmp)
            try:
                treated_loc = self._eligible_control_units.get_loc(treated_unit)
                tmp.insert(treated_loc, 0)
            except:
                pass
            weights.append(tmp)
        
        self._weights = pd.DataFrame(weights, columns=self._eligible_control_units, index=moments.columns)
        #self._weights.reindex_axis(sorted(self._weights.columns), axis=1) \
        #    .sort_index()
        
    def _compute_weights(self, panel):
        
        indx = panel.count().index
        if self._control_filter_dic is not None:
            con_filter = PdMultiIndexEx.get_some_levels_block_indicator(indx, self._control_filter_dic)
        else:
            con_filter = np.array([True] * len(indx))

        if self._treatment_filter_dic is not None:
            tr_filter = PdMultiIndexEx.get_some_levels_block_indicator(indx, self._treatment_filter_dic)
        else:
            tr_filter = np.array([True] * len(indx))

        self._eligible_control_units = indx[con_filter]
        self._eligible_treated_units = indx[con_filter | tr_filter]

        moments = pd.DataFrame(columns=panel.count().index)
        for key, val in self._matching_vars.items():
            for sub_val in val:
                if sub_val == []:
                    tmp = panel[key].mean().to_frame()
                else:
                    tmp = panel.apply(lambda g: g[g[self._time_column].isin(sub_val)][key].mean()).to_frame()
                moments = moments.append(tmp.T)


        time_series = pd.concat([panel.get_group(c)[[self._time_column, self._treatment_column]] \
            .set_index(self._time_column) for c in moments.columns.values], axis=1)
        time_series.columns = moments.columns

        if self._post_periods is not None:
            time_series_val = time_series.loc[self._post_periods]
        else:
            time_series_val = time_series_val

        if self._pre_periods is not None:
            time_series_con = time_series.loc[self._pre_periods]
        else:
            time_series_con = time_series_con


        keep_units = (time_series_con.isnull().sum(axis=0) == 0) * (time_series_val.isnull().sum(axis=0) == 0)
        time_series_con = time_series_con.loc[:, keep_units]
        time_series_val = time_series_val.loc[:, keep_units]
        moments = moments.loc[:, keep_units]

        total_controls = len(self._eligible_control_units)
        self._eligible_control_units = self._eligible_control_units[keep_units[self._eligible_control_units]]
        self._eligible_treated_units = self._eligible_treated_units[keep_units[self._eligible_treated_units]]
        rem_controls = len(self._eligible_control_units)

        moments = moments.loc[:, self._eligible_treated_units]
        time_series_con = time_series_con.loc[:, self._eligible_treated_units]
        time_series_val = time_series_val.loc[:, self._eligible_control_units]

        print('Units dropped due to missing observations: ' + str(total_controls - rem_controls))
        print('Units kept: ' + str(rem_controls))

   
        self._compute_weights_one(moments, time_series_con)#, time_series_val)

    def _get_core_feature(self, panel, dataset):

        if self._time_column is None:
            self._time_column = dataset.schema.get_time_col_name()

        if self._weights is None:
            self._compute_weights(panel)
        
        tmp = dataset.data.groupby(self._time_column).apply(lambda g: self._weights \
            .dot(g.set_index(dataset.schema.get_panel_col_names()) \
            .loc[self._weights.columns, self._treatment_column]))

        tmp = tmp.unstack().to_frame().reset_index()
        
        tmp.columns = dataset.schema.get_panel_col_names() \
            + [dataset.schema.get_time_col_name(), self.treatment_column + '_sc_cf']
        
        concat = dataset.data.merge(tmp, how='left', on=dataset.schema.get_panel_col_names() \
            + [dataset.schema.get_time_col_name()]).set_index(dataset.schema.get_panel_col_names() + \
            [self._time_column])

        return concat[self.treatment_column + '_sc_cf']

    def compute_weights(self, dataset):
        if self._time_column is None:
            self._time_column = dataset.schema.get_time_col_name()

        panel = dataset.data.groupby(dataset.schema.get_panel_col_names())
        return self._compute_weights(panel)

    def get_counterfactual(self, dataset):
        '''
        Get counterfactual prediction for all periods using existing weights.
        If weights are not present then they will first be trained by calling
        compute_weights
        '''
        panel = dataset.data.groupby(dataset.schema.get_panel_col_names())
        return self._get_core_feature(panel, dataset)
