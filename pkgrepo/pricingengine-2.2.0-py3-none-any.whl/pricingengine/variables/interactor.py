#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
import numpy as np

from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdmultiindexex import PdMultiIndexEx

from pricingengine.schema import Schema, ColDef, DataType
from pricingengine.estimation.typed_dataset import ColType
#pylint: disable=too-many-locals, dangerous-default-value

class Interactor():
    '''
    Class used to create interaction terms from core treatments
    '''
    
    def __init__(self, interaction_levels=None, fill_lower_order=True):
        '''
        Initialize a new Interactor object which can create the specified interactions from any core treatment and 
        estimation_dataset

        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be 
            collectively interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param Bool fill_lower_order: Ensure all corresponding lower order interactions are created if higher-order
            interactions are present (Default TRUE). 
        '''

        self._continuous_interaction_name = 'interaction'
        self._fill_lower_order = fill_lower_order
        if interaction_levels is None:
            self._interaction_levels = []
        else:
            self._interaction_levels = interaction_levels

        for x in self._interaction_levels:
            if not isinstance(x, list):
                raise Exception('All elements of interaction_levels must be lists')

        if self._fill_lower_order:
            self._fill_levels()

        self._unq_cols = self.get_unique_cols()
        self._discrete_cols = None
        self._cont_cols = None
        
    @property
    def unq_cols(self):
        return self._unq_cols

    @property
    def cont_inter_col(self):
        return self._cont_cols

    @property
    def disc_inter_col(self):
        return self._discrete_cols

    
    @property
    def interaction_levels(self):
        return self._interaction_levels

    @staticmethod
    def powerset(item_list):
        x = len(item_list)
        power_set = []
        for i in range(1 << x):
            power_set.append([item_list[j] for j in range(x) if i & (1 << j)])
        return power_set

    @staticmethod
    def union_all_powersets(list_list):
        all_ps = []
        for sub_list in list_list:
            all_ps.extend(Interactor.powerset(sub_list))
        return np.unique(all_ps).tolist()

    def get_unique_cols(self):
        u_cols = []
        for x in self._interaction_levels:
            for y in x:
                if y not in u_cols:
                    u_cols.append(y)
        return u_cols


    def _fill_levels(self):
        '''
        Ensure lower order interactions are created if higher-order interactions are present
        '''
        self._interaction_levels = Interactor.union_all_powersets(self._interaction_levels)


    def build_interactions(self, core_treatment, encoders, estimation_dataset, levels_to_add=(), 
                           level_names=(), outcome_lead=0):   
        '''
        Builds the specified interactions around the given core treatment and using the estimation_dataset object to
        construct the interactions.
        '''
        predet_cols = estimation_dataset.schema.get_colnames_bycoltype(ColType.PREDETERMINED)
        numerical_cols = estimation_dataset.schema.get_colnames_bydatatype(DataType.NUMERIC)
        indx = estimation_dataset.data.index
        unq_cols = self.get_unique_cols()

        self._discrete_cols = [col for col in unq_cols if col not in numerical_cols]
        self._cont_cols = [col for col in unq_cols if col in numerical_cols]
        interactors = {}
        for col in unq_cols:
            if (col in predet_cols) & (col in numerical_cols):
                interactors[col] = pd.DataFrame(estimation_dataset.data[col].shift(-outcome_lead).values, 
                                                columns=pd.Index([col], name=col), index=indx)
            if (col not in predet_cols) & (col in numerical_cols):
                interactors[col] = pd.DataFrame(estimation_dataset.data[col].values, 
                                                columns=pd.Index([col], name=col), index=indx)
            if (col in predet_cols) & (col not in numerical_cols):
                interactors[col] = encoders[col].transform(estimation_dataset.data[col].shift(-outcome_lead))
            if (col not in predet_cols) & (col not in numerical_cols):
                interactors[col] = encoders[col].transform(estimation_dataset.data[col])


        interactions = []
        for x in self._interaction_levels:
            if len(x) > 0:
                int_x = PdDataframeEx.interact_dataframes([interactors[y] for y in x])
                interactions.extend([PdDataframeEx.interact_series_with_dataframe(int_x, core_treatment)])
            
        features_list = [core_treatment.to_frame()] + interactions 
        col_names = [feature_list.columns.names for feature_list in features_list]
        all_names = np.unique([j for k in col_names for j in k if not j is None])
        if len(all_names) > 0:
            features_list = [pd.DataFrame(feature_list.values, index=feature_list.index, 
                                          columns=PdMultiIndexEx.align_index(feature_list.columns, all_names))
                             for feature_list in features_list]
                                      
                                                                  
                         

        interaction_features = PdDataframeEx.concat_along_rows([x for x in features_list])
        if levels_to_add != ():
            for lv_index, _ in enumerate(levels_to_add):
                lvl_to_add = np.repeat(levels_to_add[lv_index], interaction_features.shape[1])
                interaction_features = interaction_features.T.set_index(lvl_to_add, append=True).T
                names = list(interaction_features.columns.names)
                names[-1] = level_names[lv_index]
                interaction_features.columns = interaction_features.columns.rename(names)
        return interaction_features

    @staticmethod
    def _merge(tup_list_1, tup_list_2):
        for tup_1, tup_2 in zip(tup_list_1, tup_list_2):
            yield (tup_1,) + (tup_2,)
