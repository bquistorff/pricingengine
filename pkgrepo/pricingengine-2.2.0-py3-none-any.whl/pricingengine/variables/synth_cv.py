#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import concurrent.futures
import timeit
import pandas as pd
import numpy as np
from itertools import repeat

from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx
from pricingengine.variables import joint_sc_functions


#pylint: disable=unused-argument, too-many-statements
#pylint: disable=cell-var-from-loop, redefined-variable-type
#pylint: disable=too-many-locals,too-many-instance-attributes

class SynthCV(VarBuilder):
    '''
    Construct a synthetic control variable based on abadie (2010) but chose the v matrix
        jointly over all units and use cross-validation to penalize the L1 simplex norm
        of the penalty.
    '''    
    DIRECT_V_SOLVER = joint_sc_functions.DIRECT_V_SOLVER
    SIMPLEX_V_SOLVER = joint_sc_functions.SIMPLEX_V_SOLVER
    LARS_V_SOLVER = joint_sc_functions.LARS_V_SOLVER

    def __init__(self,
                 #core inputs
                 treatment_column,
                 time_column=None,
                 matching_vars=None,
                 #specify pre/post, control/treatment
                 pre_periods=None,
                 post_periods=None,
                 control_filter_dic=None,
                 treatment_filter_dic=None,
                 #synth control options
                 non_neg_weights=True,
                 v_pens=None,
                 fixed_v=None,
                 #standard var_builder options
                 interaction_levels=None,
                 unpenalize_core_treatment=False,
                 scale_core=True,
                 solver=joint_sc_functions.LARS_V_SOLVER,
                 print_path=False):
        '''
        :param treatment_column: Column for which we preform synthetic controls
        :param time_column: Dataframe column used to create the time index. Will default to the time col in the schema. 
        :param matching_vars: Dictionary mapping dataframe columns to a double list. Each element of outer list
            is a moment that will be created. Elements of the sub-list are time periods that will be averaged
            over to create that moment. Defaults to a global avg over the pre-periods of treatment_column

        :param pre_periods: Time periods on which synthetic control is trained.
        :param post_periods: Time periods on which synthetic control is validated.
        :param control_filter_dic: Filter dictionary used to select available control units.
        :param treatment_filter_dic: Filter dictionary used to select additional units for training (beyond controls).

        :param non_neg_weights: Bool which defaults to True to exclude non-negative weights. Setting this to False
            can help acheive a better fit for units which have higher/lower outcomes than all available controls.
        :param v_pens: List of penalty parameters to try. Defaults to [0]
        :param fixed_v: A list of same length as the number of moments. If present, the v_matrix is fixed by this
            diagonal and all cross-validation and optimization of v is forgone.

        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be 
            collectively interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param unpenalize_core_treatment: Boolean value. If true, the core_treatment feature will not be penalized by 
            any ML methods used for treatment effect estimation
        :param Bool scale_core: Scale core feature to be normalized with variance 1 before creating interactions. 
            If false, do not scale.
        '''
        super().__init__(treatment_column, interaction_levels, unpenalize_core_treatment, scale_core)

        #These 2 get set by the final line
        self._var_builder_sig = "" #NB featurizer signature must be unique
        self._treatment_column = treatment_column
        if matching_vars is None:
            self._matching_vars = {treatment_column : [[]]}
        else:
            self._matching_vars = matching_vars

        self._time_column = time_column
        self._pre_periods = pre_periods
        self._post_periods = post_periods
        self._control_filter_dic = control_filter_dic
        self._treatment_filter_dic = treatment_filter_dic
        self._eligible_control_units = None
        self._eligible_treated_units = None
        self._weights = None

        self._v_pens = v_pens
        self._non_neg_weights = non_neg_weights

        if fixed_v is None:
            self._v_mat = None
        else:
            self._v_mat = fixed_v

        self._val_scores = None
        self._sample_scores = None
        self._selected_penalty = None
        self._v_solver = solver
        self._moment_df = None
        self._loss = None
        self._print_path = print_path

    def _apply_filters(self, panel):
        '''
        Apply filter_dics to find eligible treated and control units. Required input is a groupby
            object which has been grouped by the panel columns
        '''

        indx = panel.count().index
        if self._control_filter_dic is not None:
            con_filter = PdMultiIndexEx.get_some_levels_block_indicator(indx, self._control_filter_dic)
        else:
            con_filter = np.array([True] * len(indx))

        if self._treatment_filter_dic is not None:
            tr_filter = PdMultiIndexEx.get_some_levels_block_indicator(indx, self._treatment_filter_dic)
        else:
            tr_filter = np.array([True] * len(indx))

        self._eligible_control_units = indx[con_filter]
        self._eligible_treated_units = indx[con_filter | tr_filter]
            
    def _solve(self, time_series_pre, time_series_post):
        '''
        Run parallelized computation of weights and validation scores for all values
            in self._v_pens
        '''
        if self._v_mat is not None:
            v_mat = self._v_mat
            weights, val_score, sample_scores = joint_sc_functions.compute_weights(
                self._moment_df,
                v_mat,
                time_series_pre,
                time_series_post,
                self._eligible_control_units,
                self._eligible_treated_units,
                self._non_neg_weights,
                )
            val_scores = [val_score]
        elif self._v_pens is None:
            log_v_pen_guess = np.log(np.std(time_series_pre.values)) - 3
            self._v_pens = []
            val_scores = []
            sample_scores = []
            self._loss = []
            all_weights = []
            all_vs = []
            cont = True

            while cont:
                v_pens = [np.exp(v_val) for v_val in np.linspace(log_v_pen_guess - 2, log_v_pen_guess + 2, 10)]

                with concurrent.futures.ProcessPoolExecutor() as executor:
                    tmp = list(executor.map(joint_sc_functions.solve_v_matrix,
                                            repeat(self._moment_df),
                                            repeat(time_series_pre),
                                            repeat(time_series_post),
                                            repeat(self._eligible_control_units),
                                            repeat(self._eligible_treated_units),
                                            repeat(self._non_neg_weights),
                                            repeat(self._v_solver),
                                            v_pens))

                val_scores.extend([j[2] for j in tmp])
                sample_scores.extend([j[3] for j in tmp])
                self._v_pens.extend([j[5] for j in tmp])
                self._loss.extend([j[4] for j in tmp])
                all_weights.extend([j[0] for j in tmp])
                all_vs.extend([j[1] for j in tmp])
                val_argmin = np.argmin(val_scores)
                vpen_argmin = np.argmin(self._v_pens)
                vpen_argmax = np.argmax(self._v_pens)

                if val_scores[val_argmin] < min(val_scores[vpen_argmax], val_scores[vpen_argmin]):
                    cont = False
                elif val_scores[val_argmin] >= val_scores[vpen_argmin]:
                    log_v_pen_guess -= 3
                    print(sorted(zip(self._v_pens, val_scores)))
                    print('Shifting Search window down for v_pen parameter. Now centered at: ' 
                          + str(np.exp(log_v_pen_guess)))
                else:
                    if max(np.diag(all_vs[val_argmin])) == 0:
                        cont = False
                    else:
                        print(sorted(zip(self._v_pens, val_scores)))
                        log_v_pen_guess += 3
                        print('Shifting Search window up for v_pen parameter. Now centered at: ' 
                              + str(np.exp(log_v_pen_guess)))



            arg_min = np.argmin(val_scores)
            self._selected_penalty = self._v_pens[arg_min]
            weights = all_weights[arg_min]
            v_mat = all_vs[arg_min]

        elif len(self._v_pens) > 1:
            #parallelize cross-validation procedure
            with concurrent.futures.ProcessPoolExecutor() as executor:
                tmp = list(executor.map(joint_sc_functions.solve_v_matrix,
                                        repeat(self._moment_df),
                                        repeat(time_series_pre),
                                        repeat(time_series_post),
                                        repeat(self._eligible_control_units),
                                        repeat(self._eligible_treated_units),
                                        repeat(self._non_neg_weights),
                                        repeat(self._v_solver),
                                        self._v_pens))
        
            val_scores = [j[2] for j in tmp]
            sample_scores = [j[3] for j in tmp]
            self._v_pens = [j[5] for j in tmp]
            self._loss = [j[4] for j in tmp]
            arg_min = np.argmin([j[2] for j in tmp])
            self._selected_penalty = tmp[arg_min][5]
            weights = tmp[arg_min][0]
            v_mat = tmp[arg_min][1]

        else:
            weights, v_mat, val_score, sample_scores, loss, _ = joint_sc_functions.solve_v_matrix(
                self._moment_df,
                time_series_pre,
                time_series_post,
                self._eligible_control_units,
                self._eligible_treated_units,
                self._non_neg_weights,
                self._v_solver,
                self._v_pens[0],
                print_path=self._print_path)
            val_scores = [val_score]
            self._selected_penalty = self._v_pens[0]

        self._sample_scores = sample_scores
        self._val_scores = val_scores
        self._weights = weights
        self._v_mat = pd.DataFrame(v_mat, index=self._moment_df.index.values)
        try:
            self._loss = loss
        except:
            pass #fixed v_matrix

    def _compute_moment_df(self, panel):
        '''
        Compute and set moment df
        '''
        moment_df = pd.DataFrame(columns=self._eligible_treated_units)
        index = []
        for key, val in self._matching_vars.items():
            for sub_val in val:
                index.append((key, sub_val))
                if sub_val == []:
                    tmp = panel[key].mean().to_frame()
                else:
                    tmp = panel.apply(lambda g: g[g[self._time_column].isin(sub_val)][key].mean()).to_frame()
                moment_df = moment_df.append(tmp.T)

        
        self._moment_df = pd.DataFrame(moment_df.values, columns=moment_df.columns,
                                       index=index)
        self._moment_df = self._moment_df.add(-self._moment_df.mean(axis=1), axis=0) \
            .div(self._moment_df.std(axis=1), axis=0)

    def _process_time_series(self, panel):
        
        time_series = pd.concat([panel.get_group(c)[[self._time_column, self._treatment_column]] \
            .set_index(self._time_column) for c in self._moment_df.columns.values], axis=1)
        time_series.columns = self._moment_df.columns

        if self._pre_periods is not None:
            time_series_con = time_series.loc[self._pre_periods]
        else:
            time_series_con = time_series

        if self._post_periods is not None:
            time_series_val = time_series.loc[self._post_periods]
        else:
            time_series_val = time_series

        return time_series_con, time_series_val

    def _filter_units(self, time_series_con, time_series_val):
        '''
        Filter out units with missing data in the control or validation periods
        '''
        keep_units = (time_series_con.isnull().sum(axis=0) == 0) * (time_series_val.isnull().sum(axis=0) == 0)

        total_controls = len(self._eligible_control_units)
        total_treated = len(self._eligible_treated_units)
        self._eligible_control_units = self._eligible_control_units[keep_units[self._eligible_control_units]]
        self._eligible_treated_units = self._eligible_treated_units[keep_units[self._eligible_treated_units]]
        rem_controls = len(self._eligible_control_units)
        rem_treated = len(self._eligible_treated_units)

        self._moment_df = self._moment_df.loc[:, self._eligible_treated_units]
        time_series_con = time_series_con.loc[:, self._eligible_treated_units]
        time_series_val = time_series_val.loc[:, self._eligible_control_units]

        if total_controls > rem_controls:
            print('Control Units dropped due to missing observations: ' + str(total_controls - rem_controls))
            print('Control Units kept: ' + str(rem_controls))

        if total_treated > rem_treated:
            print('Treated Units dropped due to missing observations: ' + str(total_treated - rem_treated))
            print('Treated Units kept: ' + str(rem_treated))

        return time_series_con, time_series_val

    @staticmethod
    def _to_list(x):
        if isinstance(x, list):
            return x
        else:
            return [x]

    def _compute_weights(self, dataset):
        
        if self._treatment_filter_dic is not None and self._control_filter_dic is not None:
            keys = set(self._treatment_filter_dic.keys()) & set(self._control_filter_dic.keys())
            combo_dic = {k : list(np.unique(self._to_list(self._treatment_filter_dic[k]) +
                                            self._to_list(self._control_filter_dic[k]))) for k in keys}
            dataset = dataset.filter(filter_dic=combo_dic)

        panel = dataset.data.groupby(dataset.schema.get_panel_col_names())

        if self._time_column is None:
            #if no time_column is specified then get it from the schema inside dataset
            self._time_column = dataset.schema.get_time_col_name()
        self._apply_filters(panel)
        self._compute_moment_df(panel)
        
        time_series_con, time_series_val = self._process_time_series(panel)
        time_series_con, time_series_val = self._filter_units(time_series_con, time_series_val)
        
        self._solve(time_series_con, time_series_val)

    def _get_core_feature(self, panel, dataset):


        if self._weights is None:
            self._compute_weights(dataset)
        
        tmp = dataset.data.groupby(self._time_column).apply(lambda g: self._weights \
            .dot(g.set_index(dataset.schema.get_panel_col_names()) \
            .loc[self._weights.columns, self._treatment_column]))

        tmp = tmp.unstack().to_frame().reset_index()
        
        tmp.columns = dataset.schema.get_panel_col_names() \
            + [dataset.schema.get_time_col_name(), self.treatment_column + '_sc_cf']
        
        concat = dataset.data.merge(tmp, how='left', on=dataset.schema.get_panel_col_names() \
            + [dataset.schema.get_time_col_name()]).set_index(dataset.schema.get_panel_col_names() + \
            [self._time_column])

        return concat[self.treatment_column + '_sc_cf']

    def compute_weights(self, dataset):
        '''
        Solve for optimal penalty, v_matrix, and corresponding weight matrix
        '''
        self._compute_weights(dataset)

    def get_counterfactual(self, dataset):
        '''
        Get counterfactual prediction for all periods using existing weights.
        If weights are not present then they will first be trained by calling
        compute_weights
        '''
        panel = dataset.data.groupby(dataset.schema.get_panel_col_names())
        return self._get_core_feature(panel, dataset)

    @property
    def moment_weights(self):
        try:
            return pd.DataFrame(np.diag(self._v_mat), index=self._v_mat.index.values)
        except:
            return self._v_mat

    @property
    def weights(self):
        return self._weights

    @property
    def selected_penalty(self):
        return self._selected_penalty


    @property
    def scores(self):
        try:
            return pd.DataFrame(np.vstack((self._v_pens, self._val_scores, self._sample_scores, self._loss)),
                                index=['Pen Value', 'Post RMSE', 'Pre RMSE', 'Pre Loss']).T.set_index('Pen Value') \
                                    .sort_index()
        except:
            return pd.DataFrame(np.vstack((self._v_pens, self._val_scores, self._sample_scores)),
                                index=['Pen Value', 'Post RMSE', 'Pre RMSE']).T.set_index('Pen Value').sort_index()
