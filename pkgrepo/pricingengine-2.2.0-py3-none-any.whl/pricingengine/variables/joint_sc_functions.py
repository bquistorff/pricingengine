#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pdb
import pandas as pd
import numpy as np
import timeit
from numpy import diag, zeros, ones, dot, hstack, concatenate, cumprod
from numpy.linalg import inv
from cvxopt import matrix, solvers
from scipy.optimize import minimize

from msecoreml.pdmultiindexex import PdMultiIndexEx



#pylint: disable=invalid-name, too-many-locals, mixed-line-endings

DIRECT_V_SOLVER = 'direct v solver'
SIMPLEX_V_SOLVER = 'simplex v solver'
LARS_V_SOLVER = 'lars v solver'

#### w optimizers ############
def default_w_optimizer(inputs):
    '''
    :param inputs: list containing two arguments (moments and tretaed units)
        * moments: PxN dataframe of moments to match
        * treated_units: list of units (must match to dataframe col values) to train on 
        * eligible_control_units: MultiIndex of eligible control units
        * non_neg_weights: Bool for excluding neg weights

    :Returns: Dataframe of weights where eligible_control_units are the columns and
        treated units are the rows (all rows of the df will sum to 1)
    '''

    moments, treated_units, eligible_control_units, non_neg_weights = inputs
    if treated_units is None:
        treated_units = moments.columns
    #control_moments = moments.loc[:, eligible_control_units]
    opts = {}
    for treated_unit in treated_units:
        control_units = [unit for unit in eligible_control_units if unit != treated_unit]
        treated_moments = moments[treated_unit]
        control_moments = moments.loc[:, control_units]
        opts[treated_unit] = opt_one_w(treated_moments, control_moments,
                                       non_neg_weights=non_neg_weights)

    def optimize_w(v_mat):
        weights = []
        for treated_unit in treated_units:
            tmp = list(opts[treated_unit](v_mat))
            try:
                treated_loc = eligible_control_units.get_loc(treated_unit)
                tmp.insert(treated_loc, 0)
            except:
                pass
            weights.append(tmp)
        df = pd.DataFrame(weights, columns=eligible_control_units, index=treated_units)
        return df


    return optimize_w

def opt_one_w(treated_moments, control_moments, non_neg_weights=True):
    """
    For a given metric V, the optimal set of weights can be solved using
    quadratic programming, which is implemented in cvxopt.solvers.qp

    :param treated_moments: A (P x 1) dataframe with the data from the treated unit
    :param control_moments: A (P x N) dataframe with the data from the control units
    :param bool non_neg_weights: Force weights to be non-negative
    """

    solvers.options['show_progress'] = False # global options are stoopid
    num_donors = control_moments.shape[1]
    # Individual weights must be positive:
    G = matrix(diag(ones(num_donors) * -1))
    
    # The weights must sum to one:
    A = matrix(ones([1, num_donors]))
    b = matrix(ones([1, 1]))

    if non_neg_weights:
        h = matrix(zeros([num_donors, 1]))
    else:
        h = matrix(ones([num_donors, 1]))

    old_value = [None]
    def opt(v_mat,):
        #st = timeit.default_timer()
        out = solvers.qp(
            G=G, h=h,
            A=A, b=b,
            P=matrix(dot(dot(control_moments.T, diag(v_mat)), control_moments) + .1 * np.eye(control_moments.shape[1])),
            q=matrix(-1*dot(dot(treated_moments.T, diag(v_mat)), control_moments).T),
            #initvals=oldvalue[0] #uncomment to start search at prev solution (seems not to speed things up)
            )['x']
        old_value[0] = out
        return out

    
    return opt


####V optimizers factories###########

def lars_v_optimizer(loss_v, v_weight_tol=5e-3):

    def optimize_v(start):
        #start should be zeros

        current_score = loss_v(start)
        num_moments = len(start)
        update_size = 1
        curr_v_weights = start.copy()


        while update_size > v_weight_tol:
            cont = True
            while cont:
                update_up = [np.inf for _ in curr_v_weights]
                update_down = [np.inf for _ in curr_v_weights]

                for k in range(num_moments):
                    #Loop over moments and try incrementing weight on each one up or down
                    tmp_up = curr_v_weights.copy()
                    tmp_down = curr_v_weights.copy()
                    tmp_up[k] += update_size
                    tmp_down[k] -= update_size
                    
                    if tmp_down[k] > 0:
                        update_down[k] = loss_v(tmp_down)
                    if tmp_up[k] < 10:
                        update_up[k] = loss_v(tmp_up)
                dx_up = np.argmin(update_up)
                dx_down = np.argmin(update_down)
                if update_up[dx_up] < update_down[dx_down]:
                    if update_up[dx_up] < current_score:
                        current_score = update_up[dx_up]
                        curr_v_weights[dx_up] += update_size
                    else:
                        #No profitable updates remaining at current update size
                        cont = False
                else:
                    if update_down[dx_down] < current_score:
                        current_score = update_down[dx_down]
                        curr_v_weights[dx_down] -= update_size
                    else:
                        #No profitable updates remaining at current update size
                        cont = False
            #reduce update size and hunt for more improvements
            update_size /= 2

        return curr_v_weights, current_score
    return optimize_v

def direct_v_optimizer(loss_v, xatol=1e-2, fatol=1e-2):
    """ 
    Returns a wrapper for our chosen minimize() function, which optimizes V with respect to the
        given loss function for V. The body of this function is where options for the optimizer are
        set

        This is a effectively a transliteration of the R code from the Synth
        package.  Note that with N control regions, this W is restricted to a
        bounded N-1 dimensional space but minimize() operates over the
        unbounded N-dimensional real numbers. 

    """
    def optimize_v(start):
        V_res = minimize(
            # The loss function being minimized: 
            #  v need not sum to 1, but cannot be negative
            loss_v,  
            start,
            #method='L-BFGS-B',
            method='nelder-mead',
            #bounds=tuple((0,1) for j in range(len(start) - 1)),
            options={'xatol' : xatol,
                     'fatol' : fatol}
            )
        sol = V_res.x

        return sol, V_res.fun
    return optimize_v


def from_simplex(V):
    one = np.array((1.,)) 
    return (cumprod(concatenate((one, V))) * concatenate((1 - V, one))).clip(0, max=1)

def to_simplex(raw_V):
    simplex_V = zeros((len(raw_V) - 1,))
    simplex_V[0] = (1 - raw_V[0])

    for i in range(1, len(raw_V)-1):
        simplex_V[i] = 1 + ((simplex_V[i-1] - 1) / simplex_V[i-1]) * (raw_V[i] / raw_V[i-1])

    return simplex_V

def simplex_v_optimizer(loss_V, xtol=1e-4, ftol=1e-4):
    """
    This optimizer is has the advantage over the default (borrowed from R)
    in that it optimizes w over a bounded N-1 dimensional region (which
    identifies individual minima), but as written it doesn't sample the
    parameter space uniformly. 

    It can be made uniform by applying the transformation z = z^(1/N:1), which
    would likely be numerically unstable for large numbers of predictors. The
    numerical instability might be ameliorated in logit space, but then
    boundary solutions can't be found...

    The following R code illustrates these issues::

        untransformed = NULL
        transformed = NULL
        N = 4
        for(i in 1:100000){
            z = runif(N)
            untransformed = rbind(untransformed,
                                  cumprod(c(1,z))*c(1-z,1))
            z = z^(1/N:1)
            transformed = rbind(transformed,
                                cumprod(c(1,z))*c(1-z,1))
        }

        apply(transformed,2,mean)
        apply(transformed,2,sd)

        apply(untransformed,2,mean)
        apply(untransformed,2,sd)
        apply(untransformed,2,function(x)sd(x/(1-x)))

    Incidentally, the above map between the N-1 dimensional Unit cube and the set
    of N vectors with positive elements which Sum to 1 and was borrowed from
    this paper: https://arxiv.org/abs/1010.3436

    """
    # the start matrix has N elements with N-1 degrees of freedom, because
    # it must sum to 1.  We can project this down to the N-1 unit cube and then 
    def optimize_V(start):
        # project the trace(V) = 1 plane in R N start into the plane onto the (N-1) dimensional unit cube:
        simplex_start = to_simplex(start)

        # this is the R implementation -- a better way is to constrain the optimization...
        V_res = minimize(lambda simplex_weights: loss_V(from_simplex(simplex_weights)),
                         simplex_start,
                         method='L-BFGS-B',
                         # constrain the optimization to the N-1 dimensional unit cube
                         bounds=((0, 1),) * (len(start) - 1), 
                         options={'xtol' : xtol,
                                  'ftol' : ftol})

        return from_simplex(V_res.x), V_res.fun

    return optimize_V


####Core Solver######

def solve_v_matrix(moments,
                   time_series_pre,
                   time_series_post=None,
                   eligible_control_units=None,
                   treated_units=None,
                   non_neg_weights=True,
                   v_solver=LARS_V_SOLVER,
                   v_pen=0,
                   optim_w_factory=default_w_optimizer,
                   print_path=False):
    '''
    Computes and sets the optimal v_matrix for the given moments and 
        penalty parameter.

    :param moments: PxN dataframe of moments to match
    :param time_series_pre: TxN datframe of time series to match
    :param time_series_post:
    :param eligible_control_units: MultiIndex of eligible control units
    :param treated_units: list of units (must match to dataframe col values) to match 
    :param non_neg_weights: Bool for excluding neg weights
    :param v_solver:
    :param v_pen: penalty parameter used to shrink L1 norm of v/v.max() toward zero
    :param optim_w_factory:
    :param print_path:
    :Returns: DataFrame of weights, matrix of penalty parameters, and validation score
        computed on post-period of control units
    '''

    assert np.all(moments.columns.values == time_series_pre.columns.values), \
        "moments and time-series must have same cols"
    assert not np.any(np.isnan(moments.values)), "moments must not contain missing values"
    assert not np.any(np.isnan(time_series_pre.values)), "time_series must not contain missing values"

    optim_w = optim_w_factory([moments, treated_units, eligible_control_units, non_neg_weights])

    if v_solver == DIRECT_V_SOLVER:
        optim_v_factory = direct_v_optimizer
    elif v_solver == SIMPLEX_V_SOLVER:
        #raise Exception('Doesn\'t work well. Not enabled.')
        optim_v_factory = simplex_v_optimizer
    elif v_solver == LARS_V_SOLVER:
        optim_v_factory = lars_v_optimizer
    else:
        print(v_solver)
        raise Exception('Invlaid v_solver')

    if moments.shape[0] == 1: 
        # Trivial case
        v_mat = np.eye(1)
        v_diag = [1]
    else:
        #np.linalg.norm gives the Eucledian norm
        loss_fn = lambda v_weight: np.linalg.norm(time_series_pre - time_series_pre[eligible_control_units]
                                                  .dot(optim_w(v_weight.clip(0)).T)) + v_pen * (sum(abs(v_weight))) 
        
        def loss_fn_print(v_weight):
            print(v_weight)
            val = loss_fn(v_weight)
            print(val)
            return val

        if print_path:
            optim_v = optim_v_factory(loss_fn_print)
        else:
            optim_v = optim_v_factory(loss_fn)

        #random initial condition
        #v_guess = abs(np.random.normal(size=moments.shape[0]))
        #v_guess /= v_guess.sum()

        #default initial condition
        v_guess = zeros(moments.shape[0])
        v_diag, loss = optim_v(v_guess)
        
        #create diagonal matrix from diag
        v_diag = v_diag.clip(0) 


        #create diagonal matrix from diag
        v_mat = np.diag(v_diag)
    
    # optimize W conditional on the chosen V
    weights = optim_w(v_diag)

    if time_series_post is None:
        #no validation periods available
        validation_score = None
    else:
        #compute validation score on post periods of control units
        errors = time_series_post - time_series_post[eligible_control_units].dot(weights.T)[eligible_control_units]
        denom = np.sqrt(np.prod(np.shape(errors)))
        validation_score = np.linalg.norm(errors) / denom

        errors = time_series_pre - time_series_pre[eligible_control_units].dot(weights.T)[eligible_control_units]
        sample_score = np.linalg.norm(errors) / denom

        loss /= denom

    return weights, v_mat, validation_score, sample_score, loss, v_pen



def compute_weights(moments,
                    v_mat,
                    time_series_pre=None,
                    time_series_post=None,
                    eligible_control_units=None,
                    treated_units=None,
                    non_neg_weights=True,
                    optim_w_factory=default_w_optimizer):
    
    optim_w = optim_w_factory([moments, treated_units, eligible_control_units, non_neg_weights])
    weights = optim_w(v_mat)

    if time_series_post is None:
        #no validation periods available
        validation_score = None
        sample_score = None
    else:
        #compute validation score on post periods of control units
        errors = time_series_post - time_series_post[eligible_control_units].dot(weights.T)[eligible_control_units]
        validation_score = np.linalg.norm(errors) / np.sqrt(np.prod(np.shape(errors)))

        errors = time_series_pre - time_series_pre[eligible_control_units].dot(weights.T)
        sample_score = np.linalg.norm(errors) / np.sqrt(np.prod(np.shape(errors)))

    return weights, validation_score, sample_score
