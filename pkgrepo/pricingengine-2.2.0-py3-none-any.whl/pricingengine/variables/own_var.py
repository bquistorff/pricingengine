#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx

#pylint: disable=unused-argument

class OwnVar(VarBuilder):
    '''
    Measure impact of a unit's own treatment value
    '''    
    
    def __init__(self, treatment_column,
                 lag=0, seasonal_diff=0,
                 interaction_levels=None, unpenalize_core_treatment=False, scale_core=True):
        '''
        :param lag: 0 spcified contemporaneous treatment, positive values lagged treatments, negative values future
            treatments
        :param lag: lag of variable to use
        :param seasonal_difference: seasonal_difference to use in constructing variable. 
            If zero, do not use a seasonal difference.
        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be 
            collectively interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param unpenalize_core_treatment: Boolean value. If true, the core_treatment feature will not be penalized by 
            any ML methods used for treatment effect estimation
        :param Bool scale_core: Scale core feature to be normalized with variance 1 before creating interactions. 
            If false, do not scale.
        '''
        super().__init__(treatment_column, interaction_levels, unpenalize_core_treatment, scale_core)

        self._lag = lag
        self._seasonal_diff = seasonal_diff

        #These 2 get set by the final line
        self._lag_feature_from_outcome = False #Get's set later by FeatureGenerator
        self.lag_feature_from_outcome = False

        self._var_builder_sig = str(self.treatment_column)
        if self._lag > 0:
            if not self._lag_feature_from_outcome:
                self._var_builder_sig += " OL" + str(self._lag)
            else:
                self.var_builder_sig += " RL" + str(self._lag)
        if self._seasonal_diff > 0:
            self._var_builder_sig += " D" + str(self._seasonal_diff)


    @property
    def lag_feature_from_outcome(self):
        return self._lag_feature_from_outcome

    @lag_feature_from_outcome.setter
    def lag_feature_from_outcome(self, lag_feature_from_outcome):
        self._lag_feature_from_outcome = lag_feature_from_outcome


    def _get_core_treatment(self, treatments, estimation_dataset):
        #if not self._lag is None:
        #    raise Exception('Must use outcome_lag for treatment variables')
        if (self._lag in treatments[self.treatment_column]) and \
            (self._lag + self._seasonal_diff) in treatments[self.treatment_column]:
            if self._seasonal_diff == 0:
                return treatments[self._treatment_column][self._lag]
            else:
                return treatments[self._treatment_column][self._lag] - \
                    treatments[self._treatment_column][self._lag + self._seasonal_diff]
        else:
            return 0 * treatments[self._treatment_column][0]

    def _get_core_feature(self, panel, estimation_dataset, outcome_lead=0):

        if self._lag_feature_from_outcome:
            use_lag = self._lag - outcome_lead
        else:
            use_lag = self._lag
        if self._seasonal_diff == 0:
            return PdGroupByEx.gen_lags(panel[self.treatment_column], [use_lag])[0]
        else:
            return PdGroupByEx.gen_lags(panel[self.treatment_column], [use_lag])[0] - \
                PdGroupByEx.gen_lags(panel[self.treatment_column], [use_lag + self._seasonal_diff])[0]

    def get_effect_weights(self, marginal_effects):

        effect_weights = pd.DataFrame(0, columns=marginal_effects.mfx.columns, index=marginal_effects.mfx.index)
        for i in range(len(effect_weights.index)):
            impacting_lead, product = marginal_effects.mfx.index[i]
            own_treatment_cols = PdMultiIndexEx.get_1level_block_indicator(marginal_effects.mfx.columns, 
                                                                           marginal_effects.competition_col, [product])
            contemp_cols = PdMultiIndexEx.get_1level_block_indicator(marginal_effects.mfx.columns, 
                                                                     VarBuilder.LEAD_COL_NAME, 
                                                                     [impacting_lead + self._lag])
            relevant_cols = contemp_cols & own_treatment_cols

            effect_weights.iloc[i, :] = relevant_cols
        return effect_weights
