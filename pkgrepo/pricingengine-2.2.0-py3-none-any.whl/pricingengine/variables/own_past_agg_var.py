#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import numpy as np
import pandas as pd
from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx

#pylint: disable=unused-argument

class OwnPastAggVar(VarBuilder):
    '''
    Measure treatment impacts of a unit's own treatment aggregated across multiple time periods useing geometric decay
    '''
    
    def __init__(self, treatment_column, geometric_weight,
                 min_lag=None, max_lag=None,
                 min_seasonal_diff=None, max_seasonal_diff=None,
                 interaction_levels=None,
                 unpenalize_core_treatment=False, scale_core=True):
        '''
        Initialize a new FeatureBuilder for datasets with the specified schema

        :param treatment_column: The residualized treatment that will be used for treatment generation
        :param geometric_weight: multiplicative decay applied to periods with progressively greater lag
        :param min_lag: The smallest lag to use in generating the treatment
        :param max_lag: The largest lag to use in generating the treatment
        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be 
            collectively interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param unpenalize_core_treatment: Boolean value. If true, the core_treatment feature will not be penalized by 
            any ML methods used for treatment effect estimation
        :param Bool scale_core: Scale core feature to be normalized with variance 1 before creating interactions.
            If false, do not scale.
        '''

        super().__init__(treatment_column, interaction_levels, unpenalize_core_treatment, scale_core)

        

        self._geometric_weight = geometric_weight
        self._min_lag = min_lag
        self._max_lag = max_lag

        self._min_seasonal_diff = min_seasonal_diff
        self._max_seasonal_diff = max_seasonal_diff    
        if self._min_lag is None and self._min_seasonal_diff is None:
            raise Exception('Must specify lags or seasonal diffs')
        if self._min_lag is None:
            if self._max_seasonal_diff is None:
                self._max_seasonal_diff = 999
            if (self._min_seasonal_diff is None) or (self._max_seasonal_diff is None):
                raise Exception('Must specify either lags or seasonal diffs. Not Both')
        else:
            if self._max_lag is None:
                self._max_lag = 999
            if (not self._min_seasonal_diff is None) or (not self._max_seasonal_diff is None):
                raise Exception('Must specify either lags or seasonal diffs. Not Both')
        self._tr_decay_path = None

        if self._min_lag is not None:
            self._var_builder_sig = str(treatment_column) + ' L' + str(self._min_lag) \
            + '-' + str(self._max_lag) + ' geo_' + str(self._geometric_weight)
        else:
            self._var_builder_sig = str(treatment_column) + ' D' + str(self._min_seasonal_diff) \
            + '-' + str(self._max_seasonal_diff) + ' geo_' + str(self._geometric_weight)

    def _get_core_treatment(self, p_treatments, estimation_dataset):
        
        max_p_treatment = max([lead for lead in p_treatments[self._treatment_column]])
        max_treat_lag = min(max_p_treatment, self._max_lag)

        if not self._max_lag is None:
            self._tr_decay_path = [self._geometric_weight**(lag - self._min_lag) 
                                   for lag in range(self._min_lag, 1 + max_treat_lag)]
            return pd.Series(sum([p_treatments[self._treatment_column][lag] * \
                                  self._geometric_weight**(lag - self._min_lag) 
                                  for lag in range(self._min_lag, 1 + max_treat_lag)]), 
                             index=p_treatments[self._treatment_column][0].index)
        else:
            raise Exception('Seasonal differences not supported for treatment effect estiamtion')
            #return pd.Series(sum([(p_treatments[self._treatment_column][0] - 
            #                       p_treatments[self._treatment_column][lag]) * self._geometric_weight**(lag - 1) 
            #                      for lag in range(self._min_seasonal_diff, 
            #                        1 + min(max_p_treatment, self._max_seasonal_diff))]), 
            #                 index=p_treatments[self._treatment_column][0].index)

    def expand_coeff(self, coeff):
        idx = range(self._min_lag, self._min_lag + len(self._tr_decay_path))
        series = pd.Series(coeff*np.array(self._tr_decay_path), name="Week", index=idx)
        return series

    def _get_core_feature(self, panel, estimation_dataset):
        if self._max_seasonal_diff is None:
            lags = range(self._min_lag, 1 + self._max_lag)
            tmp = PdGroupByEx.gen_lags(panel[self.treatment_column], lags)
            return sum([tmp[lag - 1] * self._geometric_weight**(lag - min(lags)) for lag in lags])
        else:
            lags = range(self._min_seasonal_diff, 1 + self._max_seasonal_diff)
            tmp = PdGroupByEx.gen_lag_diffs(panel[self.treatment_column], lags)
            return sum([tmp[lag - 1] * self._geometric_weight**(lag - min(lags)) for lag in lags])

    def get_effect_weights(self, marginal_effects):

        effect_weights = pd.DataFrame(0, columns=marginal_effects.mfx.columns, index=marginal_effects.mfx.index)

        for i in range(len(effect_weights.index)):
            impacting_lead, product = marginal_effects.mfx.index[i]
            own_treatment_cols = PdMultiIndexEx.get_1level_block_indicator(marginal_effects.mfx.columns, 
                                                                           marginal_effects.competition_col, [product])
            lead_delta = np.array(effect_weights.iloc[i, own_treatment_cols].index.get_level_values('lead')) - \
                impacting_lead
            effect_weights.iloc[i, own_treatment_cols] = (self._geometric_weight**(lead_delta - self._min_lag)) * \
                                                         (((self._min_lag is None) or (lead_delta >= self._min_lag)) & 
                                                          ((self._max_lag is None) or (lead_delta <= self._max_lag)))

        return effect_weights
