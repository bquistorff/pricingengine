#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# Unit Testing Utilities
#
#------------------------------------------------------------------------
# pylint: disable=fixme, invalid-name, too-many-locals
import warnings
import numpy as np
import pandas as pd
from pricingengine.estimation.typed_dataset import ColType
from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx
#pylint: disable=too-many-instance-attributes

class PToPVar(VarBuilder):
    '''
    Class used to measure impact of the treatment value assigned to a particular peer for a particular self
    '''
    TREATMENT = 'treatment'
    TOSTRING = '_to_'

    def __init__(self, treatment_column, competition_var, impact_dict,
                 lag=0, seasonal_diff=0,
                 interaction_levels=None, unpenalize_core_treatment=False, scale_core=True):
        '''
        Initialize a new FeatureBuilder for datasets with the specified schema

        :param treatment_column: Name of treatment variable to be used.
        :param competition_var: A panel variable (usually item) along the dimension of which a 
            cross-instance competition is allowed
        :param impact_dict: Dictionary of impactor to impacted pairs where both the impactor and impacted are 
            values of the competition_var 
        :param lag: lag of variable to use
        :param seasonal_difference: seasonal_difference to use in constructing variable. 
            If zero, do not use a seasonal difference.
        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be 
            collectively interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param unpenalize_core_treatment: Boolean value. If true, the core_treatment feature will not be penalized by 
            any ML methods used for treatment effect estimation
        :param Bool scale_core: Scale core feature to be normalized with variance 1 before creating interactions.
            If false, do not scale.
        '''
        super().__init__(treatment_column, interaction_levels, unpenalize_core_treatment, scale_core)


        for k, vs in impact_dict.items():
            if not isinstance(vs, list):
                raise Exception('Each value in impact_dict must be a list.')
            if k in vs:
                raise Exception(k + ' is both key and element of corresponding value. Use OwnVar for such variables.')
        
        self._lag = lag
        self._seasonal_diff = seasonal_diff
        self._competition_var = competition_var
        self._impact_dict = impact_dict
        self._feature_weights = None
        self._lag_feature_from_outcome = False #Get's set later by FeatureGenerator
        self._var_builder_sig = str(treatment_column) + '_p2p'
        if self._lag > 0:
            if self._lag_feature_from_outcome:
                self._var_builder_sig += ' OL' + str(lag)
            else:
                self._var_builder_sig += ' RL' + str(lag)



    @property
    def lag_feature_from_outcome(self):
        return self._lag_feature_from_outcome

    @lag_feature_from_outcome.setter
    def lag_feature_from_outcome(self, lag_feature_from_outcome):
        self._lag_feature_from_outcome = lag_feature_from_outcome


    def _get_core_treatment(self, treatments, dataset):
        '''
        Compute value of core treatment

        :param treatments: double dictionary of treatment residuals indexed by treatment name and relative lead
        :param dataset: estimation_dataset object
        '''
        warnings.filterwarnings("ignore") #ignoring duplicate error on index/col duplicate in groupbys below
        data = dataset.data.copy()
        if self._lag in treatments[self.treatment_column]:
            data[PToPVar.TREATMENT] = treatments[self._treatment_column][self._lag].fillna(0) 
        else:
            data[PToPVar.TREATMENT] = treatments[self._treatment_column][0].fillna(0) 
        
        return self._compute_treatments(data)
   
    def _get_core_feature(self, panel, dataset, outcome_lead=0):
        if self._lag_feature_from_outcome:
            use_lag = self._lag - outcome_lead
        else:
            use_lag = self._lag

        warnings.filterwarnings("ignore") #ignoring duplicate error on index/col duplicate in groupbys below
        data = dataset.data.copy()
        data[PToPVar.TREATMENT] = PdGroupByEx.gen_lags(panel[self.treatment_column], [use_lag])[0]
        
        return self._compute_treatments(data)
    

    def _compute_treatments(self, data):
        '''
        Compute the value of the resulting treatment column if weights have NOT been precomputed and attempt to 
        store the weights
        '''
        levels = [x for x in data.index.names if x != self._competition_var] 
        df = data.pivot_table(index=levels, columns=[self._competition_var], values=PToPVar.TREATMENT)
        tmp = data.merge(df.reset_index(), how='left', on=levels)
        cpt_ind = []
        values = []
        impacted = []
        for k, vs in self._impact_dict.items():
            cpt_ind.extend([k + PToPVar.TOSTRING + v for v in vs])
            impacted.extend(vs)
            values.extend([tmp[k].values for v in vs])

        cp2 = tmp[[k for k, vs in self._impact_dict.items() for v in vs]]

        cp_treatment = pd.DataFrame(cp2.values, index=data.index, columns=cpt_ind)
        for count, col in enumerate(cp_treatment):
            cp_treatment[col] *= (cp_treatment.index.get_level_values(self._competition_var) == impacted[count])
        part1 = []
        part2 = []
        for k, vs in self._impact_dict.items():
            part1.extend([k for v in vs])
            part2.extend([v for v in vs])
        cp_treatment.columns = pd.MultiIndex.from_tuples(list(zip(part1, part2)), 
                                                         names=[PToPVar.IMPACTOR + self._competition_var, 
                                                                self._competition_var])
        
        return cp_treatment


    def get_effect_weights(self, marginal_effects):

        effect_weights = pd.DataFrame(0, columns=marginal_effects.mfx.columns, index=marginal_effects.mfx.index)
        for i in range(len(effect_weights.index)):
            impacting_lead, _ = marginal_effects.mfx.index[i]
            #own_treatment_cols = PdMultiIndexEx.get_1level_block_indicator(marginal_effects.mfx.columns, 
            #                                                             marginal_effects.competition_col, [product])
            contemp_cols = PdMultiIndexEx.get_1level_block_indicator(marginal_effects.mfx.columns, 
                                                                     VarBuilder.LEAD_COL_NAME, 
                                                                     [impacting_lead + self._lag])
            relevant_cols = contemp_cols #& own_treatment_cols

            effect_weights.iloc[i, :] = relevant_cols
        return effect_weights
