#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
# Unit Testing Utilities
#
#------------------------------------------------------------------------
# pylint: disable=fixme, invalid-name, too-many-locals, too-many-instance-attributes
import warnings
import numpy as np
import pandas as pd
from pricingengine.estimation.typed_dataset import ColType
from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx


class PeerAggVar(VarBuilder):
    '''
    Class used to measure weighted average impact of the treatment value assigned to one's peers
    '''
    INSTANCE_REV_WEIGHT = 'rev weight'
    INSTANCE_PTREATMENTxREV_WEIGHT = 'p_treat * rev weight'
    INSTANCE_REVENUE = 'rev'
    INSTANCE_PTREATMENT = 'p_treat'
    HIERARCHY = 'hier'
    WINDOW_SIZE = 2


    N_TO_1_UNWEIGHTED = "Nto1 Unweighted"
    N_TO_1_REV_WEIGHTED = "Nto1 Revenue Weighted"
    N_TO_1_REV_AUX_WEIGHTED = "Nto1 Revenue*Aux Weighted"

    def __init__(self, treatment_column, competition_var, hierarchy_col=None, 
                 lag=0, seasonal_diff=0,
                 aux_col_name=None, bandwidth=None, kernel=None,
                 interaction_levels=None,
                 unpenalize_core_treatment=False, store_weights=True, weighting_column=None, scale_core=True):
        '''
        Initialize a new FeatureBuilder for datasets with the specified schema

        :param core_treatment: Name of treatment variable to be used.
        :param competition_var: A panel variable (usually item) along the dimension of which a cross-instance 
            competition (or alternatively spill-over effects) is allowed
        :param hierarchy_var: A categorical variable that groups products and defines the structure of competition. 
            If omitted all instances with the same conditioning variables will be allowed to compete.
        :param aux_col_name: Name of a numerical column which is used to "weight" cross product effects. 
            I.E. Products closer to each other in this column are presumed to compete/complement more strongly.
        :param bandwidth: A positive float used to divide distance in the aux_column before applying the kernel.
            Larger values will allow for more disperese products to compete with each other.
        :param kernel: A lambda function that converts distance (in the aux col name) to a weighting. Default is
            a Gaussian PDF.
        :param interaction_levels: List of lists. Each sub-list is a list of columns that will be collectively
            interacted. If a sub-list is of length 2, this correspodns to a second-order interaction.
        :param unpenalize_core_treatment: Boolean value. If ture, the core_treatment feature will not be penalized by 
            any ML methods used for treatment effect estimation
        :param store_weights: If True, stores the needed cross-treatment weights inside this class. 
            This takes up space, but allows the build method to run faster on future computations.
        :param weighting_column: Additional column used to weight effects. May desire to use revenue-weighting
            if trying to approximate IIA structure of demand in estiamting cross-price effects.
        :param Bool scale_core: Scale core feature to be normalized with variance 1 before creating interactions. 
            If false, do not scale.
        '''
        super().__init__(treatment_column, interaction_levels, unpenalize_core_treatment, scale_core)

        self._var_builder_sig = str(treatment_column) + ' peer_agg '
        if lag > 0:
            self._var_builder_sig += ' OL' + str(lag)
        if hierarchy_col is not None:
            self._var_builder_sig += ' in_' + str(hierarchy_col)
        if isinstance(bandwidth, list):
            tmp = [a[0] + '_' + str(a[1]) for a in list(zip(aux_col_name, bandwidth))]
            self._var_builder_sig += ','.join(tmp)
        elif bandwidth is not None:
            self._var_builder_sig += aux_col_name + '_' + str(bandwidth)

        
        if isinstance(aux_col_name, list):
            if len(aux_col_name) != len(bandwidth):
                raise Exception('Aux col name and bandwidth must have same length')
        elif aux_col_name != None and (not isinstance(bandwidth, float) or bandwidth < 0):
            raise Exception('Bandwidth must be a positive float')
        elif aux_col_name is None and bandwidth is not None:
            raise Exception('No aux column is specified so bandwidth must be set to None')

        

        self._aux_col_name = aux_col_name
        self._bandwidth = bandwidth
        if kernel is None:
            self._kernel = PeerAggVar._exponential_kernel
        else:
            self._kernel = kernel

        self._competition_var = competition_var
        self._hierarchy_var = hierarchy_col

        self._store_weights = store_weights
        self._feature_weights = None
        self._feature_impacting_products = None
        self.__aux_weights = None
        self._lag = lag
        self._seasonal_diff = seasonal_diff
        self._weighting_column = weighting_column
        self._lag_feature_from_outcome = False #Get's set later by FeatureGenerator


    @property
    def lag_feature_from_outcome(self):
        return self._lag_feature_from_outcome

    @lag_feature_from_outcome.setter
    def lag_feature_from_outcome(self, lag_feature_from_outcome):
        self._lag_feature_from_outcome = lag_feature_from_outcome

    @staticmethod
    def _exponential_kernel(x):
        return np.exp(- (x)**2 / 2)

    def _store_aux_weights(self, data):
        '''
        Compute and store the aux_weights based on the aux_column and bandwidth selected

        :param data: dataframe (.data) object from an estimation_dataset
        '''
        #compute average aux value for each item
        if isinstance(self._aux_col_name, list):
            val = None
            for (aux, bandwidth) in zip(self._aux_col_name, self._bandwidth):
                aux_values = data.groupby([self._competition_var]).agg({aux : np.mean}) 
                tmp = self._kernel((aux_values.values - np.transpose(aux_values.values)) / bandwidth)
                if val is None:
                    val = tmp
                else:
                    val *= tmp
        else:
            aux_values = data.groupby([self._competition_var]).agg({self._aux_col_name : np.mean}) 
            val = self._kernel((aux_values.values - np.transpose(aux_values.values)) / self._bandwidth)

        np.fill_diagonal(val, 0) #rule out own treatment effects
        self.__aux_weights = pd.DataFrame(val, columns=aux_values.index, index=aux_values.index)

    def _get_core_feature(self, panel, dataset, outcome_lead=0):

        warnings.filterwarnings("ignore") #ignoring duplicate error on index/col duplicate in groupbys below
        if self._lag_feature_from_outcome:
            use_lag = self._lag - outcome_lead
        else:
            use_lag = self._lag
        data = dataset.data.copy()
        data[PeerAggVar.INSTANCE_PTREATMENT] = PdGroupByEx.gen_lags(panel[self.treatment_column], [use_lag])[0]
        
        data[PeerAggVar.INSTANCE_PTREATMENT] = data[PeerAggVar.INSTANCE_PTREATMENT].fillna(0.0)

        return self._compute_treatments(dataset, data)


    def _get_core_treatment(self, treatments, dataset):
        '''
        Compute value of core treatment

        :param treatments: double dictionary of treatment residuals indexed by treatment name and relative lead
        :param dataset: estimation_dataset object
        '''
        warnings.filterwarnings("ignore") #ignoring duplicate error on index/col duplicate in groupbys below
        #Use contemporaneous treatment residual (p_treatment[0]) as foundation for core treatment. 
        #Fill_na used here because missing products are probably not important (there effect can be set to zero)
        data = dataset.data.copy()
        data[PeerAggVar.INSTANCE_PTREATMENT] = treatments[self._treatment_column][self._lag].fillna(0) 

        return self._compute_treatments(dataset, data)

    def _compute_treatments(self, dataset, data):
        #Compute aux_weights if needed and not yet done
        if self.__aux_weights is None and self._aux_col_name != None:
            self._store_aux_weights(data)


        
        if self._feature_weights is not None: #Use stored feature_weights to quickly compute effects
            #take rows from saved weigths that match current estimation_dataset.
            data['weights'] = self._feature_weights.loc[data.index] 
            #If we have not yet made weights for any row of estimation_dataset, we will get a nan in this line
            if data['weights'].isnull().sum() == 0: 
                return self._compute_treatment_from_weights(data)
            else: #current weights are insufficient recompute them
                return self._compute_weights_and_treatment(dataset, data)
        else: #If current current weights are unavailable the compute them
            return self._compute_weights_and_treatment(dataset, data)
       
    def _compute_treatment_from_weights(self, data):
        '''
        Compute the value of the resulting treatment column if weights have been precomputed
        '''
        levels = [x for x in data.index.names if x != self._competition_var] 
        if self._hierarchy_var is None:
            hier_groups = data.groupby(levels)
        else:
            hier_groups = data.groupby(levels + [self._hierarchy_var])
        data = hier_groups.apply(PeerAggVar._get_aux_weighted_feature_from_precompute)
        cp_treatment = data[PeerAggVar.N_TO_1_REV_AUX_WEIGHTED]
        return cp_treatment

    def _compute_weights_and_treatment(self, dataset, data):
        '''
        Compute the value of the resulting treatment column if weights have NOT been precomputed and attempt to 
        store the weights
        '''
        # Compute per-instance revenue and hierarchy value
        if self._weighting_column is None:
            data[PeerAggVar.INSTANCE_REV_WEIGHT] = 1
        else:
            if self._weighting_column in dataset.data:
                data[PeerAggVar.INSTANCE_REVENUE] = dataset.data[self._weighting_column]
            else:
                raise Exception('weighting_column must be column name in dataset dataframe.')
       
            #GROUP BY INSTANCE AND DATE to get lagged revenues for each instance (needed for weighting below)
            if self._weighting_column:
                item_series = data.groupby(dataset.schema.get_panel_col_names())
                data = item_series.apply(PeerAggVar._lagavg_revenue)
            else:
                data[PeerAggVar.INSTANCE_REV_WEIGHT] = 1  

        #GROUP BY HIERARCHY + PANEL + DATE (not ITEM) to compute cross-treatment effects using revenue and 
        # aux weights computed above
        levels = [x for x in data.index.names if x != self._competition_var] 
        if self._hierarchy_var is None:
            hier_groups = data.groupby(levels)
        else:
            hier_groups = data.groupby(levels + [self._hierarchy_var])
        data = hier_groups.apply(PeerAggVar._get_aux_weighted_feature, aux_weights=self.__aux_weights, 
                                 competition_var=self._competition_var)
        cp_treatment = data[PeerAggVar.N_TO_1_REV_AUX_WEIGHTED]

        if self._store_weights: #store each observations weights if the user passes this option
            self._feature_weights = data['weights']
            self._feature_impacting_products = data['impacting_products']
        return cp_treatment

    @staticmethod
    def _get_aux_weighted_feature_from_precompute(group):
        '''
        Quickly compute cp feature from stored 'weights' vector and add it as a column to the group object
        '''
        group[PeerAggVar.N_TO_1_REV_AUX_WEIGHTED] = \
            np.dot(np.vstack(group['weights']), group[PeerAggVar.INSTANCE_PTREATMENT])  
     
        return group

    @staticmethod
    def _get_aux_weighted_feature(group, **kwargs):
        aux_weights = kwargs['aux_weights']
        competition_var = kwargs['competition_var']

        if aux_weights is not None:
            #This next line is the #1 speed bottleneck in aux_weighting: Testing on Surface data indicates ix 
            # is slightly faster than loc
            tmp = aux_weights.ix[group[competition_var], group[competition_var]].values
            #tmp.values[x,y] #contains the y_th revenue * aux_weight(x,y) 
            tmp = tmp * group[PeerAggVar.INSTANCE_REV_WEIGHT].values 
        else:
            tmp = np.repeat([group[PeerAggVar.INSTANCE_REV_WEIGHT].values], len(group), axis=0)
            np.fill_diagonal(tmp, 0)
            #tmp = np.ones((len(group), len(group)))
        tmp = np.nan_to_num(tmp)

        weight = tmp / np.transpose(tmp.sum(axis=1))[:, None]
        weight = np.nan_to_num(weight)
        group[PeerAggVar.N_TO_1_REV_AUX_WEIGHTED] = \
            np.dot(weight, group[PeerAggVar.INSTANCE_PTREATMENT])
        group['weights'] = [tuple(w) for w in weight]
        group['impacting_products'] = [tuple(group[competition_var]) for w in weight]
        

        return group

    @staticmethod
    def _lagavg_revenue(group):
        ser = group[PeerAggVar.INSTANCE_REVENUE]
        group[PeerAggVar.INSTANCE_REV_WEIGHT] = ser.shift(1).rolling(PeerAggVar.WINDOW_SIZE,
                                                                     min_periods=1).mean()
        return group

    def get_effect_weights(self, marginal_effects):

        int_names = list(np.intersect1d(self._feature_weights.index.names, marginal_effects.mfx.columns.names))


        #use the impactors and weights from the most recent observation to compute weights
        weights = self._feature_weights.groupby(int_names).agg(lambda x: x.iloc[-1])
        impactors = self._feature_impacting_products.groupby(int_names).agg(lambda x: x.iloc[-1]) 

        part1 = []
        for k in weights.values:
            part1.extend([j for j in k])
        part2 = []
        for k in impactors.values:
            part2.extend([j for j in k])
        part3 = []
        for i, impval in enumerate(impactors.values):
            part3.extend([i] * len(impval))
        tups = list(zip(part1, part2, part3))
        tmp = pd.DataFrame(tups)
        tmp = tmp.pivot(values=0, index=1, columns=2)
        tmp.columns = impactors.index
        tuples = []
        for col_index in range(len(marginal_effects.mfx.columns)):
            tuples.extend([tuple([marginal_effects.mfx.columns.get_level_values(name)[col_index] 
                                  for name in int_names])])
       
        #Create a column of zero weights in tmp for any missing instances
        missing_tuples = [tup for tup in tuples if tup not in tmp]
        for mt in missing_tuples:
            tmp[mt] = pd.Series([0] * len(tmp.index), index=tmp.index)

        effect_weights = tmp[tuples]
        effect_weights = effect_weights.loc[marginal_effects.mfx.index.get_level_values( \
            self._competition_var), :].fillna(0.0)

        for i in range(len(effect_weights.index)):
            impacting_lead, _ = marginal_effects.mfx.index[i]
            contemp_cols = PdMultiIndexEx.get_1level_block_indicator(marginal_effects.mfx.columns, 
                                                                     VarBuilder.LEAD_COL_NAME, 
                                                                     [impacting_lead + self._lag])
            effect_weights.iloc[i][~contemp_cols] *= 0
        return effect_weights












