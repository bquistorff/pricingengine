#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pandas as pd
from .var_builder import VarBuilder
from .interactor import Interactor
from msecoreml.pdmultiindexex import PdMultiIndexEx
from msecoreml.pdgroupbyex import PdGroupByEx

#pylint: disable=unused-argument

class ConstVar(VarBuilder):
    '''
    Measure impact of a unit's own treatment value
    '''    
    
    def __init__(self, interaction_levels=None):
        '''
        Creates a ConstVar class which can be used to create a constant variable and corresponding
        interactions

        :param interaction_levels: List of column names (CATEGORICAL OR NUMERIC) used to interact
            with the core_variable
        '''
        unpenalize_core_treatment = False
        super().__init__('', interaction_levels, unpenalize_core_treatment)


        #featurizer signature must contain treatment_column (treatment name)
        self._var_builder_sig = 'Constant'

    def _get_core_treatment(self, treatments, estimation_dataset):
        return pd.Series(1.0, index=estimation_dataset.data.index)

    def _get_core_feature(self, panel, estimation_dataset):
        return pd.Series(1.0, index=estimation_dataset.data.index)

    def get_effect_weights(self, marginal_effects):

        effect_weights = pd.DataFrame(0, columns=marginal_effects.mfx.columns, index=marginal_effects.mfx.index)
        return effect_weights
