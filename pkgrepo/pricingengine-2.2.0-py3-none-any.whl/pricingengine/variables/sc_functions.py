"""
Synthetic Control Naming Guide
                             
============= ======== ========== ============
Source        Controls Predictors PreT Outcome       
============= ======== ========== ============
Abadie 2010   Z        X          Y
Abadie 2014            X          Y
Synth (R)              X          Z
Synth (Stata)          X
============= ======== ========== ============
"""
#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
import pdb
import numpy as np
from numpy import diag, zeros, ones, dot, hstack
from numpy.linalg import inv
from cvxopt import matrix, solvers
from scipy.optimize import minimize
import pandas as pd

#pylint: disable=invalid-name
def default_w_optimizer(X1, X0, non_neg_weights=True):
    """
    For a given metric V, the optimal set of weights can be solved using
    quadratic programming, which is implemented in cvxopt.solvers.qp

    :param X1: A (P x 1) numpy matrix with the data from the treated unit
    :param X0: A (P x N) numpy matrix with the data from the control units
    :param non_neg_weights: Defaults to True to restrict weights to be non negative
    """

    solvers.options['show_progress'] = False # global options are stoopida

    # Individual weights must be positive:
    G = matrix(diag(ones(X0.shape[1])*-1))
    

    # The weights must sum to one:
    A = matrix(ones([1, X0.shape[1]]))
    b = matrix(ones([1, 1]))

    # The function which optimizes W conditional on V for fixed X1 and X0
    def optimize_W(V):
        """
        @param V an array with the diagonal elements of V; the off-diagonal elements are assumed to be zero.
        """
        if non_neg_weights:
            h = matrix(zeros([X0.shape[1], 1]))           
        else:
            h = matrix(ones([X0.shape[1], 1]))
        
        return solvers.qp(
            G=G, h=h,
            A=A, b=b,
            P=matrix(dot(dot(X0.T, diag(V)), X0)),
            q=-1*matrix(dot(dot(X1.T, diag(V)), X0).T))['x']

        
    return optimize_W

def default_v_optimizer(loss_v):
    """ 
    Returns a wrapper for our chosen minimize() function, which optimizes V
        with respect to the given loss function for V
        The body of this function is where options for the optimizer are set

        This is a effectively a transliteration of the R code from the Synth
        package.  Note that with N control regions, this W is restricted to a
        bounded N-1 dimensional space but minimize() operates over the
        unbounded N-dimensional real numbers. 

    """
    def optimize_v(start):
        return minimize(
            # The loss function being minimized: 
            #  negative values of v not allowed
            lambda v: loss_v(v.clip(0)),  
            start,
            method='nelder-mead',
            options={'xtol': 1e-4},
            )
    return optimize_v


def get_weights(treated_moments, control_moments, treated_time_series, control_time_series,
                V=None,
                optim_w_factory=default_w_optimizer, # optimize: w = argmim (f(w|V,X0,X1))
                optim_v_factory=default_v_optimizer, # argmin F(V|w*) conditional on  w* = argmim(f(w|V,X0,X1))
                non_neg_weights=True,
                v_pen=0):
    '''
    :param treated_moments: Px1 dataframe of moments for the treated unit
    :param control_moments: PxN dataframe of moments for all control units
    :param treated_time_series: Tx1 dataframe of outcomes for the treated unit
    :param control_time_series: TxN dataframe of outcomes for all control units
    :param V:
    :param optim_w_factory:
    :param optim_v_factory:
    :param non_neg_weights:
    :param v_pen:
    '''
    # Usual QC
    assert treated_moments.shape[1] == 1, "X1 should have exactly one column"
    assert treated_time_series.shape[1] == 1, "Z1 should have exactly one column"
    assert control_moments.shape[1] > 0, "X0 must not be empty"
    assert control_time_series.shape[1] > 0, "Z0 must not be empty"
    assert treated_moments.shape[0] == control_moments.shape[0], "X0 and X1 should have the same number of rows"
    assert control_time_series.shape[0] == treated_time_series.shape[0], "Z0 and Z1 should have the same number of rows"

    assert not np.any(np.isnan(control_moments)), "X0 must not contain missing values"
    assert not np.any(np.isnan(treated_moments)), "X1 must not contain missing values"
    assert not np.any(np.isnan(treated_time_series)), "Z0 must not contain missing values"
    assert not np.any(np.isnan(control_time_series)), "Z1 must not contain missing values"

    # Initialize the function that returns an optimal set of weights (w) 
    # conditional on V, X1, X0.  Note that X1, X0 are fixed so are passed
    # in here, whereas V may be varied when optimizing for V, and will
    # hence be passed when optim_w(V) is called.
    optim_w = optim_w_factory(treated_moments, control_moments, non_neg_weights)

    # DETERMINE WHAT V TO USE
    if V is not None:

        # Metric matrix (V) was supplied by the User
        assert V.shape[0] == V.shape[1] == treated_moments.shape[0], \
            "V must be a square matrix with the same number of rows as X1"
        assert np.isnan(V).sum() == 0, "V must not contain missing values"
        v_diag = np.diag(V)

    elif control_moments.shape[0] == 1: # Trivial case

        # Trivial case: only one predictor in the matrix of covariates
        V = np.eye(1)
        v_diag = [1]

    else:

        # Initialize the function that returns an Optimal V conditional on W*,
        # Z1, Z0 where w* is the optimal weights for fixed V, X1, and X0.
        optim_v = optim_v_factory(
            # The Euclidean norm between the pre-treatment outcomes 
            # is used to penalize V, and is the loss function over
            # which V is optimized
            lambda V: np.linalg.norm(treated_time_series - dot(control_time_series, optim_w(V))) \
                + v_pen * abs(sum(V) / V.max())
            )

        v_guess = ones(control_moments.shape[0]) / control_moments.shape[0]
        V_res = optim_v(v_guess)
        v_diag = V_res.x.clip(0)
        V = np.diag(v_diag)
    
    w = optim_w(v_diag)

    # optimize W conditional on the chosen V
    return w, V
