#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from abc import ABCMeta
from msecore import verify
from msecoreml.mlexception import MLException, MLErrorCode
from pricingengine.dataset import DataSet
from pricingengine.schema import SchemaValidationError, SchemaValidationException



class VariableGenerator(metaclass=ABCMeta):
    '''
    This class, given a specified schema, takes a given dataset and produces the target features and treatments
    required for a corresponding model
    '''

    def __init__(self, schema):
        '''
        Initializes a new instance of this class.

        :param schema: Target schema for incoming datasets
        '''
        self._schema = schema
        self._is_fit = False

    def fit(self, dataset):
        '''
        Build features for the given dataset

        :param dataset: The dataset for which to compute features
        :return: The computed features: A tuple of (dataframe, treatments, outcomes)
        :raises ValueError: If the schema of the given dataset does not match the schema given for initialization
        '''
        verify.istype(dataset, DataSet)

        if self._schema != dataset.schema:
            raise SchemaValidationException(SchemaValidationError.SchemaMismatch, "FeatureGenerator")

        self._is_fit = True

    def transform(self, dataset):
        '''
        Transform the given dataset using the transforms previously fit.

        :param dataset: The dataset for which to compute features
        :return: The computed features
        :raises ValueError: If the schema of the given dataset does not match the schema given for initialization
        :raises RuntimeError: If Features has not yet been fit
        '''
        verify.istype(dataset, DataSet)

        if not self._is_fit:
            raise MLException(MLErrorCode.ModelNotYetInitialized, "FeatureGenerator")

        if self._schema != dataset.schema:
            raise SchemaValidationException(SchemaValidationError.SchemaMismatch, "FeatureGenerator")

    @property
    def schema(self):
        return self._schema
