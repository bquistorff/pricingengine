#------------------------------------------------------------------------
#
# Copyright (c) Microsoft Corporation.  All rights reserved.
#
#------------------------------------------------------------------------
from collections import Counter
import msecore.verify as verify
from msecoreml.pddataframeex import PdDataframeEx
from msecoreml.pdonehotencoder import PdOneHotEncoder
from .schema import DataType, SchemaValidationError, SchemaValidationException

class DataSet(object):
    """
    The DataSet class combines un-schematized data with a schema that specifies column meta-data
    """

    @staticmethod
    def __verify_data(data, schema):

        # Iterate over the columns in the time series and verify requirements for individual columns
        # Each column must be present in the schema
        # Each column must have a data type supported by its column type
        # Each id column must be of the specified type for that id
        for col_name in data:
            col_def = schema.get_coldef_byname(col_name)

            # Verify the column is defined in the schema
            if col_def is None:
                raise SchemaValidationException(SchemaValidationError.NoSuchColumnDef, col_name)

            # Verify the column data type is supported for the column type
            data_type = col_def.data_type
            dtype = data[col_name].dtype
            DataType.verify_is_supported_dtype(data_type, dtype)

    @staticmethod
    def __verif_schema(data, schema):
        if len(data.columns) != len(schema.get_col_names()):
            raise SchemaValidationException(SchemaValidationError.SchemaMismatch) 
 
        # Verify ids are unique #Comment this outr so we can ahve multiple treatments
        #ids = Counter([x.col_type for x in schema.get_col_defs()])
        #duplicated_ids = [k for (k, v) in ids.items() if v > 1 and not k is None]
        #if len(duplicated_ids) > 0:
        #    raise SchemaValidationException(SchemaValidationError.DuplicateColType, ", ".join(duplicated_ids))

        names = Counter([x.col_name for x in schema.get_col_defs()])
        duplicated_names = [k for (k, v) in names.items() if v > 1 and not k is None]
        if len(duplicated_names) > 0:
            raise SchemaValidationException(SchemaValidationError.DuplicateColName, ", ".join(duplicated_names))

    def __init__(self, data, schema, index_colnames):
        """
        Initializes a new instance of the DataSet class. 

        The given data-schema pair needs to adhere to the following expectations:

        - Each column defined in the given schema must be contained in the corresponding given data
        - Each column must have a data type corresponding to its schema DataType as follows:

          - DataType.NUMERIC: integer or floating-point
          - DataType.DATE_TIME: datetime
          - DataType.CATEGORICAL: string or integer

        - The dataset owns the indexing for its dataframe (existing row indexes on the dataframe will be removed)
        - The dataset does not mutate the input data (it makes its own copy)

        :param data: The time series data to be used for computing effects
        :param schema: The schema specifying the meta-data for the time series
        :param index_colnames: A list of column names to be used to construct panels from the given data
        """
        verify.not_none(index_colnames, "index_colnames")
        self.__verify_data(data, schema)
        self.__verif_schema(data, schema)

        # Create an internal copy of the given data
        # All categorical data -> string
        # All numeric data -> floating point
        # All datetime -> datetime

        # Convert all categorical columns to string type internally prevent Pandas coercion of ints to floats, etc. 
        self._schema = schema
        categorical_cols = data[self._schema.get_colnames_bydatatype(DataType.CATEGORICAL)].astype(str)
        datetime_cols = data[self._schema.get_colnames_bydatatype(DataType.DATE_TIME)].copy()
        numeric_cols = data[self._schema.get_colnames_bydatatype(DataType.NUMERIC)].astype(float)
        col_order = data.columns
        self._data = PdDataframeEx.concat_along_rows([categorical_cols, datetime_cols, numeric_cols])[col_order]
        PdDataframeEx.reset_row_index(self._data, inplace=True)

        # Set the row index of the Pandas DataFrame to the panel columns specified in the schema
        # This removes any existing row indexing
        if len(index_colnames) > 0:
            self._data = PdDataframeEx.set_row_index(self._data, index_colnames)
            self._data.sort_index(inplace=True)
		#verify that the row and column indexes are unique
        assert self._data.index.is_unique
        assert self._data.columns.is_unique

    @property
    def num_rows(self):
        '''
        The number of rows in the underlying data
        '''
        return self._data.shape[0]

    @property
    def num_cols(self):
        '''
        The number of columns in the underlying data
        '''
        return self._data.shape[1]

    @property
    def data(self):
        """
        The time series data underlying this dataset. 
        :return:
        """
        return self._data

    @property
    def schema(self):
        """
        The user-defined schema for this dataset
        """
        return self._schema    

    def get_col_by_coltype(self, col_type):
        '''
        Return the column fron the dataset with the specified id
        '''
        name = self._schema.get_colname_bycoltype(col_type)
        return self.get_col_by_name(name)

    def get_all_cols_by_coltype(self, col_type):
        '''
        Return all columns fron the dataset with the specified id
        '''
        names = self._schema.get_colnames_bycoltype(col_type)
        return self.get_col_by_name(names)



    def get_col_by_name(self, col_name):
        '''
        Return the column fron the dataset with the specified name
        '''
        return self._data[col_name]
    
    def gen_encoders(self):
        '''
        Returns a dictionary colname:encoder for all CATEGORICAL cols plus the time col
        '''
        features_to_encode = [self.get_col_by_name(x)
                              for x in self.schema.get_colnames_bydatatype(DataType.CATEGORICAL)]
        features_to_encode.append(self.get_col_by_name(self.schema.get_time_col_name()))
        return {x.name : PdOneHotEncoder() for x in features_to_encode}

    def fit_encoders(self, enc_dict):
        '''
        Fits the encoders in a dictionary generated by gen_encoders()
        '''
        for colname, encoder in enc_dict.items():
            col = self.get_col_by_name(colname)
            encoder.fit(col)
